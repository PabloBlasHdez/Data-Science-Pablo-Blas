---
name: confluence-extractor
description: >
  Mapeo de páginas Confluence a FA-REQ y documentación funcional del proyecto.
  Activo cuando input/remote/confluence.yml tiene enabled: true o existen exports
  HTML en input/docs/. Distingue tipos de página por su contenido y estructura.
---

# confluence-extractor — Extracción de Confluence

> **Scope:** Extracción de contenido funcional de Confluence en WF1-FA
> **Cubre:** tipos-de-pagina-confluence, mapeo-a-fa-req, exports-html, espacios-y-paginas
> **No cubre:** documentación técnica de Confluence — se filtra o pasa a WF2

## Activación

Se activa cuando `input/remote/confluence.yml` tiene `enabled: true`.
Usa MCP nativo si disponible, o procesa el export HTML local.

## Tipos de Página Confluence y Mapeo

| Tipo de página Confluence         | FA-REQ producido | tipo-req  | Notas                              |
|-----------------------------------|------------------|-----------|------------------------------------|
| Especificación de requisitos      | DIRECTO          | DIRECTO   | BRD, PRD, specs funcionales        |
| Historia de usuario / HU          | DIRECTO          | DIRECTO   | Tratar como Jira Story             |
| Manual de usuario / How-to        | INFERIDO         | INFERIDO  | Extraer flujos y pantallas         |
| Acta de reunión / Decision log    | ASUMIDO          | ASUMIDO   | Extraer decisiones y acuerdos      |
| Documentación técnica             | —                | —         | Pasar a WF2 (no es FA)             |
| Glosario / Diccionario datos      | ENT candidatas   | INFERIDO  | Extraer entidades y campos         |
| Matriz de permisos / Roles        | ROL-NNN          | DIRECTO   | Alta fiabilidad para roles         |
| FAQ / Preguntas frecuentes        | ASUMIDO          | ASUMIDO   | Puede revelar reglas de negocio    |

## Detección del Tipo de Página

**Por título:**
- "Requisitos", "Especificación", "PRD", "BRD" → DIRECTO
- "Manual", "Guía de usuario", "Cómo..." → INFERIDO
- "Acta de reunión", "Decisiones", "Meeting notes" → ASUMIDO
- "Arquitectura", "Diseño técnico", "Infraestructura" → técnico, pasar a WF2

**Por labels/etiquetas de Confluence:**
- Buscar etiquetas: `requirements`, `spec`, `functional`, `user-story`
- Ignorar: `technical`, `architecture`, `devops`, `deployment`

**Por estructura interna:**
- Contiene secciones "Como usuario quiero..." → HU → DIRECTO
- Contiene tabla de campos con tipos → Glosario/Entidad
- Contiene tabla "Rol | Permiso" → Roles → DIRECTO
- Contiene lista de pasos numerados → Flujo de usuario → INFERIDO

## Procesamiento de Export HTML

Cuando existe `input/remote/confluence.yml` con `export-path` o hay HTMLs en `input/docs/`:
1. Leer cada fichero HTML como documento de texto
2. Extraer contenido relevante (ignorar cabeceras/pies de página Confluence)
3. Aplicar patrones de `fa-docs-extractor` según tipo de página detectado
4. Preservar enlaces entre páginas como referencias cruzadas

## Navegación con MCP Nativo

Con MCP Confluence disponible:
```
Queries útiles:
- Listar páginas de un espacio: GET /wiki/rest/api/space/{KEY}/content
- Obtener contenido de página: GET /wiki/rest/api/content/{ID}?expand=body.storage
- Búsqueda por título: GET /wiki/rest/api/content/search?cql=title~"requisitos"
- Obtener hijos de una página: GET /wiki/rest/api/content/{ID}/child/page
```

**Estrategia de exploración:**
1. Identificar el espacio del proyecto (configurado en `input/remote/confluence.yml`)
2. Encontrar la página raíz del proyecto
3. Navegar en anchura (BFS) por páginas hijas
4. Filtrar por tipo de página detectado
5. Priorizar: specs funcionales → manuales → actas

## Extracción de Macros Confluence

Confluence usa macros para formatear contenido. Tratar así:

| Macro Confluence       | Cómo tratar                                           |
|------------------------|-------------------------------------------------------|
| Tabla                  | Extraer como estructura de datos o tabla de permisos  |
| Info/Warning/Note      | Extraer como nota funcional o restricción             |
| Expand (colapsable)    | Expandir y extraer contenido interior                 |
| Code block             | Si es SQL → entidad candidata; si es JSON → contrato API |
| Image                  | Si es wireframe → pasar a fa-ui-extractor             |
| Jira Issues (macro)    | Extraer issue keys → buscar en export Jira si disponible |

## Páginas a Ignorar (no FA)

- Espacios de documentación técnica (API docs, deployment, infra)
- Páginas de proceso/metodología (sprints, retrospectivas)
- Páginas de equipo/organización
- Documentación de herramientas internas de desarrollo
