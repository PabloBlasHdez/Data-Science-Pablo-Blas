---
name: ft-backend-test-generator
description: >
  Skill 2A — Exclusiva para BACK. Recibe como input un .md con casos de test (generado por skill 1),
  el repositorio local del microservicio Java/Gluon, opcionalmente una colección Newman/Postman existente
  (.json) con helpers ya configurados (autenticación, token, etc.), y un repositorio destino.
  Analiza los controllers, endpoints, DTOs y OpenAPI/Swagger del back, cruza con los casos de test
  del .md, y genera los requests de test. Si se aporta colección existente, añade una carpeta nueva
  dentro de ella; si no, genera la colección desde cero. El resultado se escribe en el repo destino.
  NO ejecuta los tests — eso lo hace la skill 3B.
  Usa este skill cuando el orquestador o el usuario diga "genera los tests de API", "genera la colección
  Newman", "crea los tests del back", o cualquier variante de generación de tests de API REST.
metadata:
  author: "GitHub Copilot"
  version: "3.0"
  category: "testing"
  compatibility: "Java/Gluon back | Newman/Postman (colección .json existente)"
---

# FT Backend Test Generator — Skill 2A (Back / Newman)

Skill que recibe casos de test en `.md`, una **colección Newman existente** con helpers ya configurados
(autenticación, generación de token, etc.), y el código fuente del microservicio Java/Gluon.
**Añade una carpeta nueva** dentro de la colección existente con los requests de test generados.
Esta skill **no ejecuta** los tests — eso lo hace la skill 3B (`run-newman-tests`).

> **Para tests de front (Cilantrum)** usa la skill 2B `generate-front-test-scripts`.

---

## Cuándo usar este skill

- El orquestador invoca esta skill después de que la skill 1 haya generado el `.md` con casos de test
- El usuario quiere generar tests de **API/back** a partir de casos de test ya definidos
- El usuario menciona "genera la colección Newman", "genera los tests del back", "crea los tests de API"

**No uses este skill** si:
- El usuario quiere generar tests de **front** (usa skill 2B `ft-frontend-test-generator`)
- El usuario quiere *ejecutar* tests que ya existen (usa skill 3B `ft-backend-runner`)
- El usuario quiere *generar los casos de test* a partir de una historia de usuario (skill 1)

---

## Inputs requeridos

| Input | Descripción | Ejemplo |
|---|---|---|
| **`.md` con casos de test** | Archivo markdown generado por la skill 1 con los escenarios/casos de test a cubrir | `casos-test-PROJ-123.md` |
| **Repo fuente back** | Ruta local al repositorio Java/Gluon con el código del microservicio | `<ruta-local>/mi-app-back` |
| **Colección Newman existente** *(opcional)* | Si se aporta: añade una carpeta nueva con los tests a la colección existente (que ya tiene helpers de auth, token, etc.). Si no se aporta: genera la colección desde cero. **Cómo obtenerla**: abre la app del banco en el navegador, abre DevTools → pestaña Red (*Network*), ejecuta los flujos relevantes (login, obtención de token, llamadas a los endpoints), y exporta los pasos capturados como colección Postman/Newman (`.json`). ⚠️ **La colección debe incluir obligatoriamente la llamada de generación de token.** Si no la incluye, la skill lo indicará al usuario y le pedirá que la añada o que facilite el token directamente. | `<ruta-local>/coleccion-base.json` |
| **Repo destino** | Ruta local al repositorio donde se escribirá la colección resultante | `<ruta-local>/repo_destino` |

Si faltan inputs obligatorios, **pídelos explícitamente**:

```
Para generar los tests de API necesito:
1. Ruta al .md con los casos de test
2. Ruta al repo del back (código fuente Java/Gluon)
3. Ruta al repo destino donde escribir la colección

(Opcional) Si tienes una colección Newman existente, indícame la ruta.
  La forma más fácil de obtenerla: abre la app del banco en el navegador,
  ve a DevTools → Red (Network), ejecuta los flujos de auth y los endpoints
  relevantes, y exporta los pasos como colección Postman (.json).
  ⚠️ IMPORTANTE: la colección debe incluir la llamada de generación de token.
  Si no la tienes o no la incluye, indícame el token directamente y lo añado yo.
  Si no tienes colección, generaré la colección desde cero.

¿Cuáles son las rutas?
```

---

## Framework y archivos generados

| Framework | Input | Output |
|---|---|---|
| **Newman / Postman** | Colección existente `.json` + repo back + `.md` | Colección modificada `.json` (con carpeta nueva de tests) |

**Dos modos de operación:**
- **Con colección existente** (recomendado): recibe un `.json` con helpers ya configurados (auth, token, variables) y **añade una carpeta nueva** con los tests generados.
- **Sin colección existente**: genera la colección desde cero con los tests. En este caso no habrá helpers de autenticación preconfigurados — los tests que requieran auth necesitarán configuración manual posterior.

---

## Flujo completo

```
PASO 0: Establecer entorno → siempre PRE (no preguntar)
  ↓
PASO 1: Validar inputs (.md + repo back + colección existente + repo destino)
  ↓
PASO 2: Analizar la colección Newman existente (estructura, variables, auth)
  ↓
PASO 3: Analizar el código fuente del microservicio
  ↓
PASO 4: Cruzar análisis con los casos de test del .md
  ↓
PASO 5: Generar carpeta nueva dentro de la colección con los requests de test
  ↓
PASO 6: Auto-descubrir datos de prueba ejecutando requests de la colección
  ↓
PASO 7: OBLIGATORIO — Generar datos-prueba.md (pre-rellenados + vacíos)
  ↓
  👤 USUARIO revisa/completa el formulario .md
  ↓
PASO 8: Leer formulario completado y actualizar la colección con datos reales
  ↓
PASO 9: Presentar resumen final
```

---

## PASO 0 — Establecer entorno

El entorno de ejecución es siempre **PRE**.

Guardar internamente: `ENTORNO = PRE`.

El entorno determina:
- **Qué archivo de entorno usar** — `PRE.environment.json`
- **Qué URLs, IDs y datos de prueba** se extraerán
- **Qué endpoint de token** se usará para obtener el auth
- **Qué `baseUrl`** se configurará en los requests generados

---

## PASO 1 — Validar inputs

Verifica que los 4 inputs existen y son válidos:

1. **`.md` con casos de test** — léelo y extrae los escenarios/casos definidos
2. **Repo fuente back** — verifica que contiene un proyecto Java/Gluon (`pom.xml`, controllers)
3. **Colección Newman existente** *(opcional)* — si se aportó, verifica que es un JSON válido de Postman Collection v2.1
4. **Repo destino** — verifica que la ruta existe

```
file_search en repo fuente back: **/pom.xml, **/*Controller*.java
file_search en repo fuente back: **/openapi*.{yaml,yml,json}, **/swagger*.{yaml,yml,json}
```

Si algún input no es válido, informa al usuario y no continúes.

---

## PASO 2 — Analizar TODOS los inputs y extraer TODAS las variables (OBLIGATORIO)

**Este paso es OBLIGATORIO y exhaustivo.** La skill DEBE rastrear todos los inputs proporcionados
y extraer automáticamente cada variable, valor, URL, token, ID y dato que encuentre.
**NUNCA dejar vacío un valor que ya existe en alguno de los inputs.**

### 2.1 PRIORIDAD 1 — Los .json son la fuente principal de datos

**Los archivos `.json` (colección + environment) contienen casi todos los IDs, variables y datos
necesarios para las pruebas.** Son la fuente principal — rastrearlos PRIMERO y a fondo.

#### 2.1.1 Rastrear los archivos de entorno (.environment.json) — AQUÍ ESTÁN LOS DATOS

Busca **TODOS** los archivos de entorno en el repo destino, junto a la colección, y en cualquier
ruta de los inputs:

```
file_search: **/*.environment.json, **/*environment*.json, **/*.postman_environment.json
```

Lee cada archivo y extrae **TODOS** los `key`/`value` del array `values[]`.
Estos archivos típicamente contienen los datos reales de prueba ya configurados por el equipo:

| Tipo de dato que encontrarás | Ejemplos típicos de keys |
|---|---|
| URLs base y paths | `baseUrl`, `basePath`, `endpoint-TOKEN` |
| Credenciales de token | `user-token`, `pass-token` |
| Tokens (vacíos, se generan en runtime) | `token_jwt`, `token_Corp`, `token` |
| **IDs de prueba reales** | `customerId`, `portfolioId`, `investmentId`, `iban`, etc. |
| Canales y headers | `x-santander-channel`, `x-api-key`, etc. |
| IDs para casos negativos | claves que contengan "deceased", "invalid", "noAccounts", etc. |

**REGLA: si un valor está en el environment.json, ÚSALO.** No lo dejes vacío ni lo marques como
"pendiente de rellenar". Ya está rellenado por el equipo.

#### 2.1.2 Rastrear la colección Newman existente (.json)

Lee el JSON completo de la colección y extrae **TODO**:

1. **`auth` global** — identifica el tipo de auth y la variable del token (ej: `{{token_Corp}}`, `{{token_jwt}}`)
2. **`variable[]`** de colección — extrae cada `key` + `value` definido
3. **Request de autenticación** — busca la carpeta/request de token (suele llamarse "00 — Obtener Token", "Z-TOKEN", "Get Token", etc.)
   - Extrae el endpoint del token, el método, los headers y el body
   - Identifica qué variables guarda en el test script (ej: `pm.environment.set('token_jwt', jsonData.jwt)`)
4. **URLs de los requests** — extrae paths, query params de todos los requests existentes
5. **Headers de los requests** — extrae headers personalizados (ej: `x-santander-channel`, `Authorization`)
6. **Bodies de los requests** — extrae valores de ejemplo de los POST/PUT (aquí hay IDs, IBMs, etc.)
7. **Test scripts** — extrae variables guardadas con `pm.environment.set()` o `pm.collectionVariables.set()`
8. **Pre-request scripts** — extrae lógica de validación, generación de datos, etc.
9. **Estructura de carpetas** — identifica las carpetas/items que ya existen (NO tocarlas)

**Patrón típico de lo que encontrarás en la colección:**
```
auth.bearer.value = "{{token_variable}}"       ← variable del token global
request de auth .test → pm.environment.set('token_variable', jsonData.token)
```

### 2.2 PRIORIDAD 2 — Rastrear el código fuente del back

Después de los .json, extrae variables adicionales del código:
- `application.yml` / `application.properties` → `server.port`, `server.servlet.context-path`, URLs de servicios
- Constantes en controllers/services → URLs hardcodeadas, IDs de ejemplo
- Ficheros de test existentes (`src/test/`) → datos de prueba ya usados por el equipo
- OpenAPI/Swagger → schemas, examples

### 2.3 Construir el mapa completo de variables

Al terminar este paso, la skill DEBE tener un **mapa completo** de variables con sus valores,
indicando **de dónde se extrajo cada uno**:

```
Mapa de variables (ejemplo genérico):
  baseUrl          = "[valor del environment.json]"     ← environment.json
  basePath         = "[valor del environment.json]"     ← environment.json
  endpoint-TOKEN   = "[valor del environment.json]"     ← environment.json
  user-token       = "[valor del environment.json]"     ← environment.json
  pass-token       = "***"                              ← environment.json
  token_xxx        = ""  ← se obtendrá en PASO 6 (ejecutando request de auth de la colección)
  customerId       = "[valor del environment.json]"     ← environment.json (ID real del entorno)
  portfolioId      = "[valor del environment.json]"     ← environment.json (ID real del entorno)
  iban             = "[valor del environment.json]"     ← environment.json (IBAN real del entorno)
  campoVacioA      = ""  ← vacío en environment → se intentará en PASO 6
  campoVacioB      = ""  ← vacío en environment → usuario lo rellena en PASO 7
```

**REGLAS:**
- Si un valor existe en CUALQUIER `.json` (environment o colección), la skill DEBE usarlo. **NUNCA dejarlo vacío.**
- Las variables de token estarán vacías en el environment — se obtienen ejecutando el request de auth de la colección en PASO 6.
- Solo queda vacío lo que **realmente no tiene valor en ningún .json ni en el código fuente**.

---

## PASO 3 — Analizar el código fuente del microservicio

Lee el repo fuente back:

1. **Controllers/Resources** — extrae endpoints:
   - `@RequestMapping`, `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`
   - Path + método HTTP + parámetros esperados (`@PathVariable`, `@RequestParam`, `@RequestBody`)
   - Tipo de autenticación (`@PreAuthorize`, `@Secured`, cabeceras OAuth)
2. **OpenAPI/Swagger** — si existe, **priorízalo como fuente de verdad** sobre los controllers
3. **DTOs / Request bodies** — identifica la estructura de datos esperada por cada endpoint
4. **Configuración** — busca `application.yml`/`application.properties` para context path, puertos

```
file_search en repo back: **/*Controller*.java, **/*Resource*.java
file_search en repo back: **/openapi*.{yaml,yml,json}, **/swagger*.{yaml,yml,json}
file_search en repo back: **/*DTO*.java, **/*Request*.java, **/*Response*.java
file_search en repo back: **/application*.yml, **/application*.properties
```

---

## PASO 4 — Cruzar análisis con los casos de test del .md

Lee el `.md` con los casos de test y cruza cada caso con lo encontrado en el código:

- Para cada caso de test del `.md`, identifica qué **endpoint, método HTTP y datos** están involucrados
- Si un caso de test del `.md` no tiene correspondencia en ningún endpoint, **adviértelo** en el resumen (puede ser un test de front, no de API)
- Si hay endpoints no cubiertos por ningún caso de test, **adviértelo** también

---

## PASO 5 — Generar carpeta nueva dentro de la colección

### 5.1 Leer la colección existente

```javascript
// Pseudocódigo del proceso:
const coleccion = leerJSON(coleccionExistente);
// coleccion.item = [ carpetaAuth, carpetaHelper, ... ] ← NO TOCAR
```

### 5.2 Crear la carpeta nueva con los tests

Crea un item de tipo carpeta dentro del array `item` de la colección:

```json
{
  "name": "📋 Tests Generados — [nombre del flujo/historia]",
  "description": "Tests funcionales generados automáticamente por skill 2A a partir del .md de casos de test.",
  "item": [
    // Aquí van los requests generados, uno por caso de test del .md
  ]
}
```

### 5.3 Por cada caso de test del .md, generar un request

Cada request dentro de la carpeta nueva debe:
- Usar el **método HTTP + path reales** extraídos del código fuente
- Usar las **variables que ya existen** en la colección (`{{baseUrl}}`, `{{token}}`, etc.)
- Incluir el **Authorization header** referenciando `{{token}}` (ya generado por el request de auth existente)
- Incluir **tests Postman** (`pm.test`) para: status code, schema de respuesta, tiempo < 2000ms
- Usar **bodies basados en los DTOs** reales del código fuente

**REGLA CRÍTICA — Nombres de variables EXACTOS:**
Los nombres de las variables en los requests generados (`{{variable}}`) DEBEN ser **exactamente iguales**
a los nombres definidos en el environment.json y en la colección existente. No inventar nombres nuevos
ni renombrar variables.

- Si el environment tiene `customerId` → usar `{{customerId}}` (no `{{customer_id}}`, no `{{clientId}}`)
- Si el environment tiene `token_Corp` → usar `{{token_Corp}}` (no `{{token}}`, no `{{tokenCorp}}`)
- Si el environment tiene `baseUrl` → usar `{{baseUrl}}` (no `{{base_url}}`, no `{{BASE_URL}}`)

**Cómo garantizarlo:**
1. En PASO 2 se extrajo el mapa de variables con los nombres exactos de los `.json`
2. Al generar cada request, buscar la variable correspondiente **por nombre exacto** en el mapa
3. Si el nombre no coincide exactamente, el test **fallará en runtime** porque Newman no resolverá la variable

Ejemplo de request generado:

```json
{
  "name": "CT-API-001 — GET /api/v1/portfolios/:id — Happy path",
  "event": [
    {
      "listen": "test",
      "script": {
        "exec": [
          "pm.test('Status 200', () => pm.response.to.have.status(200));",
          "pm.test('Tiempo < 2000ms', () => pm.expect(pm.response.responseTime).to.be.below(2000));",
          "pm.test('Respuesta tiene id', () => {",
          "  const body = pm.response.json();",
          "  pm.expect(body.id).to.exist;",
          "});"
        ],
        "type": "text/javascript"
      }
    }
  ],
  "request": {
    "method": "GET",
    "header": [
      { "key": "Authorization", "value": "Bearer {{token}}" },
      { "key": "Accept", "value": "application/json" }
    ],
    "url": {
      "raw": "{{baseUrl}}/api/v1/portfolios/{{portfolioId}}",
      "host": ["{{baseUrl}}"],
      "path": ["api", "v1", "portfolios", "{{portfolioId}}"]
    }
  }
}
```

### 5.4 Escribir la colección modificada en el repo destino

Escribe la colección completa (original + carpeta nueva) en:

```
[repo-destino]/api-tests/[nombre]-collection.json
```

**REGLAS CRÍTICAS:**
- **NO modifiques** las carpetas/items que ya existían en la colección
- **NO dupliques** variables de colección — reutiliza las que ya existen
- **NO crees** un nuevo request de autenticación si ya existe uno
- **SÍ referencia** `{{token}}` y otras variables que el auth existente ya genera
- Usa `pm.collectionVariables.set()` para encadenar datos entre tus requests nuevos (ej: ID creado en POST → usado en GET)

---

## PASO 6 — Auto-completar datos de prueba ejecutando la colección (OBLIGATORIO)

**Este paso es OBLIGATORIO.** Después de generar la carpeta de tests (PASO 5), la skill DEBE
intentar rellenar **TODAS** las variables que quedaron vacías en el mapa del PASO 2, ejecutando
requests de la colección existente contra el entorno real.

**El token SIEMPRE está en la colección.** No pedir nunca el token al usuario.

### 6.0 Verificar que Newman está instalado y en el PATH (OBLIGATORIO)

**Ejecutar estos comandos en secuencia desde PowerShell** antes de ejecutar cualquier request:

**Paso A — Comprobar si npm está en el PATH:**
```powershell
$env:PATH -split ";" | Select-String "npm"
```

**Paso B — Si npm NO está en el PATH, añadirlo:**
```powershell
$env:PATH += ";$env:APPDATA\npm"
```

**Paso C — Verificar que Newman funciona:**
```powershell
newman --version
```
Debe devolver `6.2.2` (o superior).

**Paso D — Localizar la ruta del ejecutable:**
```powershell
Get-Command newman -ErrorAction SilentlyContinue | Select-Object Source
```

**Valores conocidos en este entorno:**
```
Versión: 6.2.2
Ruta:    $env:APPDATA\npm\newman.ps1
```

Si tras los pasos A-D `newman --version` sigue fallando, Newman no está instalado → **no continuar**:
```
⚠️ Newman no está instalado. Para instalarlo:
  npm install -g newman
```

### 6.1 Obtener token (SIEMPRE)

El token **siempre** se obtiene ejecutando el request de autenticación de la colección.
La skill DEBE buscar el request de auth en la colección (identificado en PASO 2.1) y ejecutarlo:

```powershell
newman run "[coleccion].json" --folder "[carpeta-auth]" --environment "[entorno].json" --export-environment "[entorno-actualizado].json"
```

Lee el environment exportado y extrae el `token` generado. Este token se usa en todos los
requests siguientes.

**Si la colección no tiene un request de auth identificable**, busca:
- Un request con `grant_type` en el body
- Un request cuyo test script haga `pm.collectionVariables.set('token', ...)`
- Un request cuyo nombre contenga "token", "auth", "login", "oauth"

### 6.2 Ejecutar TODOS los requests helpers de la colección

No ejecutar solo los que "parecen" útiles — **ejecutar TODOS los requests existentes** en la
colección (fuera de la carpeta nueva generada) en orden, porque muchos guardan variables
encadenadas que alimentan a otros:

```bash
newman run "[coleccion].json" --environment "[entorno].json" \
  --export-environment "[entorno-actualizado].json" \
  --ignore-redirects
```

Del environment exportado, extrae **TODOS** los valores que se hayan generado o actualizado.
Actualiza el mapa de variables del PASO 2.4 con estos valores reales.

### 6.3 Para variables que aún faltan: ejecutar GETs de descubrimiento

Si después de 6.2 aún quedan variables vacías, intenta obtenerlas con GETs específicos:

| Variable vacía | Estrategia |
|---|---|
| `customerId` | Buscar un GET de listado de customers en la colección o en los endpoints del PASO 3 → ejecutar → primer `.id` |
| `portfolioId` | Encadenar: usar `customerId` ya obtenido → GET portfolios del customer → primer `.id` |
| Cualquier ID | Buscar un GET de listado del recurso correspondiente → ejecutar → primer resultado |

### 6.4 Auto-renovación de token (TRANSPARENTE)

**Si cualquier request devuelve 401/403:**
1. Re-ejecutar automáticamente el request de auth de la colección
2. Actualizar `{{token}}` con el nuevo valor
3. Reintentar el request que falló
4. **NUNCA pedir intervención al usuario** — esto es 100% transparente

```
Pseudocódigo:
  respuesta = ejecutar(request)
  if respuesta.status == 401 || respuesta.status == 403:
    token = ejecutar(requestAuth)  // auto-renovar
    respuesta = ejecutar(request)  // reintentar con nuevo token
```

### 6.5 Resultado esperado

Al terminar este paso, el mapa de variables DEBE estar lo más completo posible:

```
Mapa de variables (actualizado tras PASO 6):
  baseUrl       = "http://localhost:8080"        ← PASO 2 (environment.json)
  token         = "eyJhbGciOi..."                ← PASO 6.1 (ejecutado auth)
  tokenUrl      = "https://auth.dev/oauth/token"  ← PASO 2 (colección)
  clientId      = "mi-app-client"                 ← PASO 2 (colección)
  customerId    = "CUST-00123456"                 ← PASO 6.2 (ejecutado helper)
  portfolioId   = "PORT-00789"                    ← PASO 6.2 (ejecutado helper)
  investmentId  = "INV-00456"                     ← PASO 6.3 (GET descubrimiento)
  accountIban   = ""                              ← NO encontrado → usuario lo rellena en PASO 7
```

**Solo queda vacío lo que NO se pudo obtener de ninguna forma automática.**

---

## PASO 7 — Generar formulario .md con datos de prueba (OBLIGATORIO)

**Este paso es OBLIGATORIO. SIEMPRE se debe generar el archivo `datos-prueba.md`**, incluso si
todos los datos se obtuvieron automáticamente en el PASO 6. El usuario SIEMPRE debe poder
revisar, modificar o completar los datos antes de que se apliquen a la colección.

Genera un archivo `.md` en el repo destino con **TODOS** los datos de prueba:
- **Pre-rellenados**: los que se obtuvieron en PASO 6 (el usuario puede modificarlos)
- **Vacíos**: los que no se pudieron obtener automáticamente (el usuario debe rellenarlos)

**Archivo**: `[repo-destino]/api-tests/datos-prueba.md`

```markdown
# Datos de prueba — [Nombre del proyecto]

> **Generado por**: skill 2A (generate-api-test-scripts)
> **Fecha**: [fecha]
> **Entorno**: DEV

## Variables de entorno

Estas variables ya están configuradas en la colección y el environment.json.
Revisa que sean correctas. Modifica lo que necesites.

| Variable | Valor actual | Origen | Acción |
|---|---|---|---|
| `baseUrl` | `http://localhost:8080` | environment.json | ✅ Verificar |
| `token` | `eyJhbGciOi...` | Auto-generado (auth) | 🔄 Se auto-renueva |
| `tokenUrl` | `https://auth.dev/oauth/token` | environment.json | ✅ Verificar |

## Datos de prueba para los tests

Estos datos se usan en los requests generados. Los marcados con ✅ se obtuvieron
automáticamente. Los marcados con ❌ necesitan que los rellenes.

| Variable | Valor | Origen | Acción |
|---|---|---|---|
| `customerId` | `CUST-00123456` | ✅ Auto-descubierto (GET /customers) | Verificar |
| `portfolioId` | `PORT-00789` | ✅ Auto-descubierto (GET /portfolios) | Verificar |
| `investmentId` | `` | ❌ No encontrado | **⚠️ RELLENAR** |
| `accountIban` | `` | ❌ No encontrado | **⚠️ RELLENAR** |

## Datos para request bodies

Estos son los valores usados en los POST/PUT. Modifica si necesitas otros datos.

### CT-API-002 — POST /api/v1/portfolios

| Campo | Valor | Tipo | Notas |
|---|---|---|---|
| `name` | `Cartera Test Auto` | String | Valor de ejemplo |
| `currency` | `EUR` | String | |
| `customerId` | `{{customerId}}` | Variable | Usa el valor de arriba |

---

**Instrucciones:**
1. Revisa los valores ✅ — pueden no ser los que necesitas para tu caso concreto
2. Rellena los valores ❌ marcados con **⚠️ RELLENAR**
3. Cuando hayas terminado, confirma y la skill actualizará la colección

**¿Datos revisados y completos?** → Confirmar para continuar
```

---

## PASO 8 — Leer formulario y actualizar colección

Cuando el usuario confirma que el formulario `.md` está completo:

1. **Lee el `.md`** y extrae los valores de las tablas
2. **Actualiza el `environment.json`** con las variables de entorno revisadas
3. **Actualiza los requests** de la colección con los datos de prueba reales:
   - Reemplaza `{{investmentId}}` con el valor concreto si el usuario lo proporcionó
   - Actualiza los bodies de los POST/PUT con los valores del formulario
4. **Escribe** la colección final y el environment actualizado en el repo destino

---

## PASO 9 — Presentar resumen final

```markdown
## Generación completada — API Tests (Newman)

### Colección modificada
- **Input**: [nombre colección original] (X carpetas, Y requests existentes)
- **Output**: [nombre colección modificada] (X+1 carpetas, Y+Z requests)
- **Carpeta añadida**: "Tests Generados — [nombre]" con Z requests nuevos

### Datos de prueba
- Variables auto-descubiertas: X/Y
- Variables proporcionadas por el usuario: Z
- Token: 🔄 auto-renovable (no requiere intervención)

### Cobertura
- Casos de test del .md cubiertos (API): X/Y
- Endpoints de API cubiertos: X/Y

### Archivos generados
- `api-tests/[nombre]-collection.json` — Colección con tests + datos reales
- `api-tests/DEV.environment.json` — Variables de entorno actualizadas
- `api-tests/datos-prueba.md` — Formulario de datos (referencia)

### Advertencias
- [Casos del .md sin endpoint API (probablemente tests de front)]
- [Endpoints no cubiertos por ningún caso de test]

La colección está lista. Para ejecutarla, usa la skill 3B `run-newman-tests`.
```

**Esta skill termina aquí. No ejecuta los tests.**

---

## Gotchas

- **NO crear colección desde cero**: esta skill recibe una colección existente y le AÑADE una carpeta. Nunca crear una colección nueva vacía.
- **NO tocar lo que ya existe**: las carpetas, requests y scripts que ya venían en la colección son intocables. Solo añadir.
- **Reutilizar variables**: si la colección ya tiene `{{baseUrl}}` y `{{token}}`, no crear `{{base_url}}` o `{{accessToken}}`. Usar las que existen.
- **Token SIEMPRE de la colección**: el token se obtiene ejecutando el request de auth que ya existe en la colección. **NUNCA pedir el token al usuario**. Si caduca (401/403), re-ejecutar el auth automáticamente y reintentar.
- **Extraer TODO de los inputs**: antes de dejar una variable vacía, la skill DEBE buscar el valor en: (1) colección JSON (variables, bodies, scripts), (2) environment.json, (3) código fuente (application.yml, tests existentes). Solo queda vacío lo que **realmente no existe en ningún sitio**.
- **Ejecutar la colección para obtener datos**: ejecutar TODOS los requests existentes de la colección para capturar variables generadas dinámicamente (tokens, IDs encadenados, etc.).
- **La URL base varía por entorno**: usa siempre `{{baseUrl}}` — no hardcodees URLs.
- **No toques tests existentes** en el repo destino sin preguntar.
- **El formulario .md es OBLIGATORIO y es la interfaz con el usuario**: SIEMPRE generar `datos-prueba.md`, incluso si todos los datos se auto-descubrieron. El usuario debe poder revisar, modificar o completar cualquier dato editando la tabla directamente en el `.md`. No le pidas datos por chat — todo va en el formulario.
- **OpenAPI es fuente de verdad**: si existe un fichero OpenAPI/Swagger en el repo, priorízalo sobre la lectura manual de controllers.
- **Esta skill NO ejecuta los tests finales**: si el usuario pide ejecutar, redirige a la skill 3B `run-newman-tests`.
- **Encadena requests**: usa `pm.collectionVariables.set()` para pasar datos entre requests nuevos.
- **Casos de front en el .md**: si el `.md` tiene casos de test que son claramente de front (modales, navegación UI, formularios), adviértelo pero no intentes generar requests de API para ellos.

---

## Árbol de resultado

```
[repo-destino]/
└── api-tests/
    ├── [nombre]-collection.json   ← colección original + carpeta nueva de tests
    ├── DEV.environment.json       ← variables de entorno actualizadas
    └── datos-prueba.md            ← formulario de datos (referencia)
```

**La colección modificada contiene:**
```
📁 [nombre]-collection.json
├── 🔐 Autenticación              ← YA EXISTÍA — no tocar
├── 📁 [Helpers existentes]        ← YA EXISTÍAN — no tocar
└── 📋 Tests Generados — [nombre]  ← NUEVA — generada por esta skill
    ├── CT-API-001 — GET /api/v1/...  (con datos reales del formulario)
    ├── CT-API-002 — POST /api/v1/... (con body del formulario)
    ├── CT-API-003 — GET /api/v1/... (404)
    └── CT-API-004 — POST /api/v1/... (400)
```
