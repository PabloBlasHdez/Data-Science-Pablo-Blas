---
name: vscode-launch-config
description: >
  Crear o editar .vscode/launch.json para configurar sesiones de depuración en
  VS Code (Node, Python, Java, .NET, Go, browser). Cubre tipos type/request,
  attach vs launch, preLaunchTask, compounds multi-target, breakpoints,
  variables y mapeo de fuentes. Activar cuando el usuario quiere depurar el
  proyecto, configurar F5, o conectar a un proceso en ejecución.
---

# vscode-launch-config — Configuración de Debug de VS Code

> **Scope:** Creación y edición de `.vscode/launch.json`
> **Cubre:** schema 0.2.0, type+request por stack, preLaunchTask, compounds, source maps, env vars, attach a procesos
> **No cubre:** definición de tareas previas (ver `vscode-tasks-config`); extensiones de debug (responsabilidad del marketplace)

## Cuándo activar

- "Configura el debug del backend Node" → launch.json con `type: node`
- "Quiero pulsar F5 y arrancar la API" → launch.json + `preLaunchTask` opcional
- "Conecta el debugger a Chrome" → `type: chrome`, `request: attach`
- "Debug de tests con Jest/PyTest" → configuración específica del runner

## Schema canónico

```jsonc
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Launch API",                       // único en el array
      "type": "node",                              // node | python | java | coreclr | go | chrome | firefox | ...
      "request": "launch",                         // launch | attach
      "program": "${workspaceFolder}/src/index.ts",
      "args": ["--port", "3000"],
      "env": { "NODE_ENV": "development" },
      "envFile": "${workspaceFolder}/.env",
      "cwd": "${workspaceFolder}",
      "console": "integratedTerminal",            // internalConsole | integratedTerminal | externalTerminal
      "preLaunchTask": "build",                   // referencia a label de tasks.json
      "postDebugTask": "stop-server",
      "sourceMaps": true,
      "outFiles": ["${workspaceFolder}/dist/**/*.js"],
      "skipFiles": ["<node_internals>/**"],
      "stopOnEntry": false,
      "smartStep": true
    }
  ],
  "compounds": [
    {
      "name": "Full Stack",
      "configurations": ["Launch API", "Launch Web"],
      "stopAll": true,                            // detener todos al matar uno
      "preLaunchTask": "build-all"
    }
  ]
}
```

## Configuraciones por stack

### Node (TypeScript)

```jsonc
{
  "name": "Debug Node (ts-node)",
  "type": "node",
  "request": "launch",
  "runtimeArgs": ["-r", "ts-node/register"],
  "args": ["${workspaceFolder}/src/index.ts"],
  "console": "integratedTerminal",
  "skipFiles": ["<node_internals>/**", "**/node_modules/**"]
}
```

### Node — Attach a proceso

```jsonc
{
  "name": "Attach to Node",
  "type": "node",
  "request": "attach",
  "port": 9229,
  "address": "localhost",
  "restart": true,
  "localRoot": "${workspaceFolder}",
  "remoteRoot": "."
}
```

### Python (requiere extensión Python de Microsoft)

```jsonc
{
  "name": "Debug Python",
  "type": "debugpy",
  "request": "launch",
  "program": "${file}",
  "console": "integratedTerminal",
  "justMyCode": true,
  "env": { "PYTHONPATH": "${workspaceFolder}/src" }
}
```

### PyTest

```jsonc
{
  "name": "Debug PyTest",
  "type": "debugpy",
  "request": "launch",
  "module": "pytest",
  "args": ["tests/", "-v", "-x"],
  "console": "integratedTerminal",
  "justMyCode": false
}
```

### Java (extensión "Debugger for Java")

```jsonc
{
  "name": "Debug Java App",
  "type": "java",
  "request": "launch",
  "mainClass": "com.example.Application",
  "projectName": "my-app",
  "args": "",
  "vmArgs": "-Dspring.profiles.active=dev"
}
```

### .NET Core / .NET 5+

```jsonc
{
  "name": "Debug .NET",
  "type": "coreclr",
  "request": "launch",
  "program": "${workspaceFolder}/bin/Debug/net8.0/MyApp.dll",
  "args": [],
  "cwd": "${workspaceFolder}",
  "stopAtEntry": false,
  "preLaunchTask": "build"
}
```

### Go

```jsonc
{
  "name": "Debug Go",
  "type": "go",
  "request": "launch",
  "mode": "auto",
  "program": "${workspaceFolder}",
  "env": {},
  "args": []
}
```

### Chrome (frontend)

```jsonc
{
  "name": "Debug Chrome",
  "type": "chrome",
  "request": "launch",
  "url": "http://localhost:3000",
  "webRoot": "${workspaceFolder}/src",
  "sourceMaps": true
}
```

## Variables predefinidas más usadas

- `${workspaceFolder}` — raíz del workspace
- `${file}` — fichero actualmente abierto
- `${env:VAR}` — variable de entorno
- `${command:pickProcess}` — invocar picker de proceso (para attach)
- `${input:varName}` — input declarado en `inputs[]`

## Compounds (debug multi-target)

Caso típico: frontend + backend depurados a la vez.

```jsonc
{
  "version": "0.2.0",
  "configurations": [
    { "name": "API", "type": "node", "request": "launch", "program": "${workspaceFolder}/api/src/index.ts" },
    { "name": "Web", "type": "chrome", "request": "launch", "url": "http://localhost:3000" }
  ],
  "compounds": [
    { "name": "Full Stack", "configurations": ["API", "Web"], "stopAll": true }
  ]
}
```

## Validaciones aplicables

- ✅ `version: "0.2.0"` obligatoria
- ✅ `name` único en `configurations[]`
- ✅ Cada config tiene `type` + `request` válidos
- ✅ Si `request: launch` → `program` o `module` (según type) presente
- ✅ Si `request: attach` → `port`/`processId`/`processName` presente
- ✅ `preLaunchTask` referencia un `label` real en tasks.json
- ✅ Rutas `program` y `outFiles` usan `${workspaceFolder}` (no absolutas)
- ⚠️  `justMyCode: false` y `skipFiles` vacío pueden ralentizar el debug

## Reglas de seguridad

- **NO escribir secrets en `env`** — usar `envFile: "${workspaceFolder}/.env"` y añadir `.env` a `.gitignore`
- **NO commitear `launch.json`** con `program` apuntando a paths absolutos de un dev concreto

## Procedimiento al editar

1. Si `.vscode/launch.json` no existe → crearlo con `version: "0.2.0"` y `configurations: []`
2. Si existe → leer, parsear JSONC, añadir/modificar configuración
3. Si la config depende de un build previo → declarar `preLaunchTask` y verificar que la tarea existe en tasks.json (si no, crearla via `vscode-tasks-config`)
4. Después de editar, mostrar al usuario: "Pulsa F5 con la config `{name}` seleccionada, o usa la paleta `Debug: Start Debugging`"
