# fa-generate-output — Ensamblado de Artefactos WF1-FA

Ensambla todos los artefactos finales del WF1-FA a partir de FA-SYNTHESIS-RESUMEN.md
y open-gaps.md. Genera la estructura output/ (para WF2) y operator/ (para el equipo humano).
Invocado por fa-run-workflow en FASE 3.

## Inputs Requeridos

Verificar que existen antes de proceder:
- `resources/FA-SYNTHESIS-RESUMEN.md` — síntesis consolidada de FASE 2
- `resources/open-gaps.md` — gaps activos (puede estar vacío)
- `fa-config.yml` → app-id, client-id, iteration, project.type

Si falta `FA-SYNTHESIS-RESUMEN.md` → ERROR: indicar que FASE 2 no ha completado.

## Proceso de Generación

### Paso 1: Leer el registro maestro de FA-REQ

Extraer de `FA-SYNTHESIS-RESUMEN.md` la sección "Registro maestro FA-REQ":
```
Lista de todos los FA-REQ-NNN con estado:
  CONFIRMADO → incluir en output/
  BLOQUEADO  → incluir en output/ con flag wf2-ready: false
  EXCLUIDO   → registrar solo en sección de exclusiones de requirements-registry.md
```

### Paso 2: Enriquecer output/requirements-registry.md

**Nota:** Este fichero fue generado en FASE 2 por `fa-generate-requirements-index`. En FASE 3, enriquecerlo con gaps finales resueltos.

Si no existe (ej: modo `reassemble`), generarlo desde cero. Usar plantilla de `Templates/fa-output-templates.md`.

```
Por cada FA-REQ-NNN del registro maestro (de FA-SYNTHESIS-RESUMEN.md):
  - Actualizar Estado: CONFIRMADO | BLOQUEADO | EXCLUIDO
  - Actualizar Gaps Vinculados: agregar todos los FA-GAP que se resolvieron
  - Campos completos: descripción, origen, tipo, confianza, pantallas, reglas, etc.
  - Criterios de aceptación de FA-REQ-RESUMEN
  - Gaps vinculados de open-gaps.md

Frontmatter:
  - coverage = cobertura de resources/coverage-report.md
  - wf2-ready = true si cobertura ≥ threshold Y gaps bloqueantes = 0
  - status = final (tras cierre WF1)
```

### Paso 3: Generar output/FA-REQ-NNN/ (por cada requisito confirmado)

```
⚠️  REGLAS DE INCLUSIÓN/EXCLUSIÓN — aplicar estrictamente:

  FICHEROS POR FA-REQ — exactamente 3 ficheros por carpeta (no más, no menos):
    1. functional-definition.md  ← definición funcional narrativa (ver Paso 6)
    2. business-rules.md         ← BRN vinculadas a este FA-REQ
    3. gaps.md                   ← gaps vinculados (todos los tipos)

  Los siguientes ficheros NO se generan por FA-REQ — solo existen en versión global:
    ✗ screen-inventory.md      → usar output/screen-inventory.md
    ✗ navigation-map.md        → usar output/navigation-map.md
    ✗ data-model.md            → usar output/data-model.md
    ✗ roles-permissions.md     → usar output/roles-permissions.md
    ✗ integrations-catalog.md  → usar output/integrations-catalog.md
    ✗ unit-test-cases.md       → NO se generan tests unitarios por requisito
    ✗ functional-test-cases.md → existe un único fichero global (ver Paso 8)

  INCLUSIÓN/EXCLUSIÓN de carpetas:
    → FA-REQ CONFIRMADO sin gaps BLOQUEANTES → carpeta completa (3 ficheros)
    → FA-REQ CONFIRMADO con gaps RECOMENDADOS/INFORMATIVOS → carpeta completa;
      gaps.md recoge esos gaps
    → FA-REQ con gaps BLOQUEANTES abiertos → solo gaps.md (los otros 2 NO
      se generan hasta que los gaps bloqueantes estén resueltos)
    → FA-REQ EXCLUIDO → no generar carpeta

  gaps.md — cuándo incluirlo:
    → SIEMPRE que el FA-REQ tenga al menos un gap vinculado
    → Si no tiene ningún gap, omitir gaps.md

  NUNCA recortar a una muestra — generar TODOS los FA-REQ elegibles.

Lanzar sub-agentes fa-req-output EN PARALELO, uno por FA-REQ elegible.
NO generar los ficheros en bucle secuencial — usar el Agent tool para paralelizar.

  PREPARACIÓN (ejecutar antes de lanzar sub-agentes):
    1. Leer FA-SYNTHESIS-RESUMEN.md una sola vez
    2. Leer open-gaps.md una sola vez
    3. Para cada FA-REQ elegible, extraer y preparar:
         - REQ_ID, descripción, actor/rol exacto, pantallas vinculadas
         - Lista de BRN vinculadas con descripción completa de cada una
         - Lista de gaps vinculados (de open-gaps.md), con estado
         - Estado del FA-REQ: CONFIRMADO | PENDIENTE | BLOQUEADO

  LANZAMIENTO EN PARALELO según APP_SIZE:
    small  (≤15 FA-REQ) → un único lote paralelo con todos
    medium (16-30)       → dos lotes de ~15, secuenciales entre sí
    large  (>30)         → tres lotes de ~15, secuenciales entre sí

    → Cada sub-agente fa-req-output recibe en su prompt SOLO los datos
      de UN FA-REQ (no el SYNTHESIS completo)
    → Los sub-agentes escriben directamente en output/FA-REQ-NNN/
    → Esperar a que todos los sub-agentes del lote completen antes del siguiente

  El sub-agente fa-req-output genera por FA-REQ:
    output/FA-REQ-NNN/functional-definition.md  (si no bloqueado — ver Paso 6)
    output/FA-REQ-NNN/business-rules.md         (si no bloqueado)
    output/FA-REQ-NNN/gaps.md                   (si tiene gaps vinculados)

  Frontmatter en cada fichero:
    app-id, client-id, artifact, req-id: FA-REQ-NNN, version, iteration, generated-at
```

### Paso 4: Generar artefactos globales output/ (agregación de todos FA-REQ-NNN/)

```
Agregar TODOS los FA-REQ-NNN/ en ficheros globales:

  output/screen-inventory.md     → TODAS las SCR de todos los requisitos
  output/navigation-map.md       → TODOS los NAV (con mermaid flowchart global)
  output/business-rules.md       → TODAS las BRN de todos los requisitos
  output/data-model.md           → TODAS las ENT (deduplicar si aparecen en múltiples req)
  output/roles-permissions.md    → TODOS los ROL con sus acciones consolidadas
  output/integrations-catalog.md → TODAS las INT (deduplicar si aparecen en múltiples req)

  Frontmatter global:
    artifact: screen-inventory | navigation-map | ...
    coverage: valor de coverage-report.md
    status: in-progress | final
    wf2-ready: true | false
```

### Paso 5: Actualizar operator/dashboard.html — sección Gaps por requisito

```
El dashboard ya existe (creado en Paso 1b del orquestador). En FASE 3,
enriquecerlo con los datos finales de síntesis.

Actualizar DASHBOARD_DATA con los datos de FA-SYNTHESIS-RESUMEN y open-gaps.md:
  - workflowStatus: "FASE3_DONE"
  - iterations[current].requirements: lista completa con IDs definitivos
  - iterations[current].screens: lista completa con fuentes confirmatorias
  - iterations[current].entities: lista completa de entidades
  - iterations[current].gaps: { bloqueantes, recomendados, informativos } completos
    → Para cada gap: incluir req vinculados, SCR afectadas, acción requerida,
      responsable sugerido, preguntas para el PO (usable en reuniones)
  - iterations[current].gates.coverage: resultado si se ejecutó
  - iterations[current].timeline: añadir paso "FASE 3 — Artefactos generados"
  - iterations[current].nextSteps: instrucciones actualizadas post-FASE 3

→ Sobreescribir operator/dashboard.html con los datos actualizados
```

### Paso 6: Generar Especificación Funcional Consolidada (FSD)

```
Este paso genera la definición funcional definitiva — el documento de referencia
único que consolida todo lo que el WF1 ha analizado: requisitos, reglas, pantallas,
actores y gaps resueltos. Sustituye la necesidad de consultar múltiples fuentes.

Se genera en TODAS las iteraciones (no solo en cierre final) y se actualiza
cada vez que se resuelven gaps o cambian los requisitos.

── POR FA-REQ: output/FA-REQ-NNN/functional-definition.md ──────────────────

Para cada FA-REQ elegible (CONFIRMADO sin gaps BLOQUEANTES), generar
`output/FA-REQ-NNN/functional-definition.md` con redacción funcional narrativa:

  Frontmatter:
    artifact: functional-definition
    req-id: FA-REQ-NNN
    status: complete | pending-gaps
    wf2-ready: true | false

  Estructura del documento (redacción narrativa, no lista de propiedades):

  # FA-REQ-NNN — {Nombre del requisito}

  ## Descripción funcional
  Texto narrativo completo de qué hace este requisito, en lenguaje funcional
  claro. Integrar las respuestas del PO a gaps ya resueltos directamente en
  el texto, tachando la formulación antigua si aplica:
    ~~texto antiguo ambiguo~~ → [RESUELTO {fecha}: texto corregido — {responsable}]

  ## Actor
  Término exacto del documento fuente.

  ## Pantalla(s) involucrada(s)
  Nombre de la pantalla + elementos UI directamente relevantes para este
  requisito (campos, botones, listboxes). No copiar toda la pantalla,
  solo lo que aplica a este FA-REQ.

  ## Reglas de negocio aplicables
  Para cada BRN vinculado: descripción completa + condición + consecuencia.
  Si una BRN tiene un gap resuelto, integrar la respuesta en la descripción.

  ## Criterios de aceptación
  Lista numerada verificable. Uno por condición del requisito.

  ## Estado de la especificación
  - ✅ Completo — si no hay gaps abiertos vinculados
  - ⚠️ Pendiente — si hay gaps RECOMENDADOS abiertos (implementable con limitaciones)
  - ❌ Bloqueado — si hay gaps BLOQUEANTES abiertos (no debe aparecer este estado
    porque los FA-REQ bloqueados no tienen functional-definition.md)

  ## Gaps pendientes (si los hay)
  Solo gaps aún abiertos vinculados a este FA-REQ. Para cada uno:
  - Qué falta saber / qué impacto tiene en la implementación
  - NO duplicar el detalle del gap — referencia a output/FA-REQ-NNN/gaps.md

── GLOBAL: output/functional-specification.md ──────────────────────────────

Documento global que agrega todas las functional-definition.md en una sola
especificación funcional del sistema completo, organizada por módulo/pantalla.

  Frontmatter:
    artifact: functional-specification
    total-req: N
    req-complete: N
    req-pending: N
    req-blocked: N
    wf2-ready: true | false

  Estructura:

  # Especificación Funcional — {APP_ID}
  > Generada por WF1-FA · Iteración {ITER-NNN} · {fecha}
  > Fuentes consolidadas: {lista de fuentes originales}

  ## Índice por módulo
  (una sección por pantalla / módulo funcional, con links a cada FA-REQ)

  ## {Módulo / Pantalla}

  ### FA-REQ-NNN — {Nombre}
  (contenido completo de functional-definition.md de ese FA-REQ)

  ### FA-REQ-NNN — {Nombre}
  ...

  ## Requisitos bloqueados (pendientes de resolución de gaps)
  Lista de FA-REQ no incluidos con los gaps que los bloquean.

── OPERATOR: operator/functional-specification.html ────────────────────────

Versión HTML auto-contenida del functional-specification.md, optimizada para
lectura y navegación humana. Es el documento de referencia para el operador
cuando necesita consultar cómo funciona algo concreto sin revisar fuentes.

  Características:
  - Sidebar con índice navegable por módulo/pantalla
  - Buscador en tiempo real sobre todos los FA-REQ (JavaScript puro)
  - Cada FA-REQ es una sección expandible/colapsable
  - Badges visuales: ✅ Completo / ⚠️ Pendiente gaps / 🔧 Resolvible operador
  - Gaps resueltos en verde con tachado del texto original
  - Gaps pendientes en amarillo con pregunta concreta para el PO
  - Enlace al dashboard desde la cabecera
  - Sin dependencias externas — funciona abriendo el fichero

  Datos embebidos como JSON inline igual que el dashboard:
    const FSD_DATA = { project, iteration, requirements: [...], screens: [...] };

  Actualizar operator/dashboard.html: añadir enlace a functional-specification.html
  en la sección Estado del dashboard.

  ⚠️ REGENERACIÓN OBLIGATORIA — operator/functional-specification.html se regenera
  SIEMPRE en cada ejecución de fa-generate-output, sin excepción:

  - Si hay gaps resueltos respecto a la iteración anterior: las pantallas que antes
    aparecían como ⛔ Bloqueadas deben mostrarse ahora como ✅ Completas.
  - Si hay nuevos FA-REQ generados (antes bloqueados, ahora elegibles): incluirlos.
  - Si cambió el estado del análisis (CLOSED, nuevo rol, nueva BRN): reflejarlo.

  Stats a actualizar en cada regeneración:
    - Título/subtitle: ITER-NNN actual y estado (CLOSED si procede)
    - Contadores: req-complete, req-blocked, BRN, gaps abiertos
    - Sidebar: badges de pantalla (✅/⛔) según estado real
    - Meta: fecha de generación y estado de cierre si aplica

  NO reutilizar el HTML anterior como base sin actualizar estas secciones —
  el HTML del operador debe reflejar siempre el estado real de la iteración actual.
```

### Paso 7: Artefactos globales operator/ — solo en cierre final

```
El dashboard (operator/dashboard.html) es el artefacto principal del operador
y se mantiene actualizado en cada fase. El único artefacto adicional en operator/
que se genera de forma separada es la traceability-matrix en el cierre.

Si status = final (cierre de WF1):
  operator/traceability-matrix.html
    → Matriz interactiva FA-REQ → SCR → BRN → ENT → ROL → INT
    → Generada SOLO en cierre final — complementa al dashboard
    → Incluir en el dashboard un enlace a este fichero

  Actualizar dashboard: workflowStatus: "CLOSED"
    → Sección Iteraciones: marcar ITER-NNN como cerrado
    → Añadir enlace a traceability-matrix.html en la sección Estado
```

### Paso 7: Actualizar iteration-tracker.md y dashboard

```
Actualizar resources/iteration-tracker.md:
  - Si la entrada ITER-NNN ya existe → actualizar columna de estado y añadir
    nota de reassemble si procede (ej: "+ reassemble {fecha}")
  - Si no existe → crear nueva entrada con los datos disponibles:
      pantallas-detectadas, cobertura-alcanzada, fingerprint

Actualizar operator/dashboard.html:
  - Añadir al timeline de la iteración actual el paso de FASE 3:
      { step: "FASE 3 — Artefactos generados", status: "done",
        result: "{N} FA-REQ elegibles · functional-specification generado" }
  - Si se ejecutó en modo reassemble: añadir nota al campo nota de la iteración
    indicando "Reassemble {fecha}: artefactos regenerados"
  - Actualizar workflowStatus si corresponde (ej: FASE3_DONE)
  - NO crear nueva entrada de iteración en el array — el reassemble opera
    sobre la iteración actual, no genera una nueva
```

### Paso 8: Generar casos de prueba funcionales (global) → WF5

```
NO se generan tests unitarios (ni por FA-REQ ni globales).
NO se generan functional-test-cases por FA-REQ individual.

Generar UN ÚNICO fichero global de casos de prueba funcionales:

  output/functional-test-cases.md  → WF5 (Pruebas Funcionales)

    Contenido organizado por pantalla (SCR), no por FA-REQ:

    ## SCR-NNN — {Nombre pantalla}

    Para cada FA-REQ de esta pantalla (solo los elegibles — sin gaps BLOQUEANTES):

      ### FA-REQ-NNN — {Nombre del requisito}
      **Criterios de aceptación verificables:**
        TC-NNN: {descripción del caso — happy-path o validación}
        TC-NNN: {caso alternativo o de error}
        TC-NNN: {verificación de flujo NAV si aplica}

    Indicar FA-REQ excluidos por gaps BLOQUEANTES:
      ⛔ FA-REQ-NNN — {nombre} [BLOQUEADO: FA-GAP-NNN pendiente]

    Frontmatter:
      artifact: functional-test-cases
      scope: global
      total-tc: N
      tc-blocked: N (por gaps bloqueantes)
      wf5-ready: true | false
```

## Frontmatter Canónico

Usar en TODOS los artefactos generados en output/:

```yaml
---
app-id: {app-id de fa-config.yml}
client-id: {client-id de fa-config.yml}
artifact: {nombre del artefacto}
version: "1.0"
iteration: {iteration de fa-config.yml}
generated-at: {timestamp actual ISO 8601}
generated-by: fa-generate-output
coverage: {valor de coverage-report.md}
status: in-progress | final
wf2-ready: true | false
---
```

## Reglas de Versioning

- Primera iteración (ITER-001): `version: "1.0"`
- Cambios menores (nuevas pantallas en misma iteración): `version: "1.1"`, `"1.2"`...
- Cambio de alcance significativo: `version: "2.0"`
- Si WF2 ya empezó con una versión anterior: mostrar WARNING antes de sobrescribir

## Comportamiento según Tipo de Ejecución

```
Iteración intermedia (status = in-progress):
  → Generar: output/ (con wf2-ready: false) + test-cases/
  → Actualizar: operator/dashboard.html (sección Requisitos + Gaps + Estado)
  → NO generar: traceability-matrix.html

Cierre final (status = final, invocado por fa-closure-gate tras firma):
  → Generar: output/ (con wf2-ready: true) + test-cases/
  → Actualizar: operator/dashboard.html (workflowStatus: CLOSED)
  → Generar: operator/traceability-matrix.html
  → NO sobrescribir fa-prerequisites.md (ese lo genera fa-closure-gate)
```
