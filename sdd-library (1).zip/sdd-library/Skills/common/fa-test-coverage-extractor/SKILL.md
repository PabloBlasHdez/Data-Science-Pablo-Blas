---
name: fa-test-coverage-extractor
description: >
  Extrae casos de prueba a nivel FA-REQ-NNN como punto de entrada principal.
  Por cada requisito genera dos artefactos separados: unit-test-cases.md
  (BRN + ENT → WF4) y functional-test-cases.md (E2E criterios + SCR + NAV → WF5).
  Trazabilidad completa: FA-REQ-NNN → Test Cases → Coverage %.
---

# fa-test-coverage-extractor — Extracción de Casos de Prueba por Requisito

## Propósito

Genera artefactos de entrada para los workflows de pruebas organizados **a nivel FA-REQ-NNN**:

- **`unit-test-cases.md`** (BRN + ENT vinculados) → entrada para **WF4** (Pruebas Unitarias)
- **`functional-test-cases.md`** (criterios E2E + SCR + NAV vinculados) → entrada para **WF5** (Pruebas Funcionales)

Punto único de trazabilidad: FA-REQ → sus componentes → casos de prueba → workflow destino.

## Inputs Requeridos

- `FA-SYNTHESIS-RESUMEN.md` — síntesis consolidada con FA-REQ, BRN, ENT, SCR, NAV
- `open-gaps.md` — para marcar dependencias bloqueantes en test cases

## Outputs Generados

### Estructura de directorios

```
output/
├── FA-REQ-001/
│   ├── unit-test-cases.md          ← BRN + ENT → WF4
│   └── functional-test-cases.md   ← E2E + SCR + NAV → WF5
├── FA-REQ-002/
│   ├── unit-test-cases.md
│   └── functional-test-cases.md
├── ...
└── test-cases/
    ├── unit-test-coverage-matrix.md      ← cobertura UT global → WF4
    └── functional-test-coverage-matrix.md ← cobertura FT global → WF5
```

---

### 1. `output/FA-REQ-NNN/unit-test-cases.md`

Entrada para **WF4 — Pruebas Unitarias**. Contiene casos derivados de las reglas de negocio
y entidades vinculadas al requisito.

Frontmatter:
```yaml
---
app-id: {app-id}
client-id: {client-id}
artifact: unit-test-cases
req-id: FA-REQ-NNN
version: "1.0"
iteration: ITER-NNN
generated-at: {timestamp ISO 8601}
generated-by: fa-test-coverage-extractor
wf-destino: WF4
status: in-progress | final
---
```

**Sección 1: Unit Tests de Reglas de Negocio (BRN)**

```yaml
## 1. Unit Tests — Reglas de Negocio

### Reglas de Negocio Vinculadas
[lista de BRN-NNN vinculados a este FA-REQ]

#### TC-UT-BRN-NNN — {nombre-BRN}
- brn-referencia: BRN-YYY
- categoria: validacion | transformacion | calculo
- precondicion: |
    [Estado previo del sistema]
- entrada: |
    [Datos de entrada, valores específicos o rangos]
- pasos:
  - [acción 1]
  - [acción 2]
- resultado-esperado: |
    [Qué debe ocurrir]
- criterio-aceptacion: |
    [Cómo verificar que pasa]
- casos-borde:
  - Caso 1: [descripción]
  - Caso 2: [descripción]
- bloqueado-por-gap: [FA-GAP-NNN] (si aplica)
```

**Sección 2: Unit Tests de Entidades (ENT)**

```yaml
## 2. Unit Tests — Entidades

### Entidades Vinculadas
[lista de ENT-NNN vinculados a este FA-REQ]

#### TC-UT-ENT-NNN — Validación {entidad-nombre}
- entidad: ENT-XXX
- campos-criticos: [campos con restricciones]
- test-constructor: [verificación creación]
- test-validaciones:
  - Campo {campo}: [restricción, caso happy-path, caso fallido, caso borde]
- test-transformaciones: [serialización, conversión]
- bloqueado-por-gap: [FA-GAP-NNN] (si aplica)
```

---

### 2. `output/FA-REQ-NNN/functional-test-cases.md`

Entrada para **WF5 — Pruebas Funcionales**. Contiene casos derivados de los criterios de
aceptación del requisito y de las pantallas y flujos de navegación vinculados.

Frontmatter:
```yaml
---
app-id: {app-id}
client-id: {client-id}
artifact: functional-test-cases
req-id: FA-REQ-NNN
version: "1.0"
iteration: ITER-NNN
generated-at: {timestamp ISO 8601}
generated-by: fa-test-coverage-extractor
wf-destino: WF5
status: in-progress | final
---
```

**Sección 1: Criterios de Aceptación (E2E)**

```yaml
## 1. Criterios de Aceptación (E2E)

Criterios del requisito:
- [criterio 1 literal del FA-REQ-NNN]
- [criterio 2 literal del FA-REQ-NNN]

#### TC-E2E-NNN — {criterio-nombre}
- fa-req-origen: FA-REQ-NNN
- descripcion: [mapeo literal del criterio]
- tipo: e2e | integracion
- precondicion: |
    [Estado del sistema, usuario autenticado, datos previos]
- pasos:
  - Paso 1: [acción]
  - Paso 2: [acción]
- resultado-esperado: |
    [Verificación del criterio cumplido]
- datos-prueba: [valores específicos]
- bloqueado-por-gap: [FA-GAP-NNN] (si aplica)
```

**Sección 2: Functional Tests de Pantallas (SCR)**

```yaml
## 2. Functional Tests — Pantallas

### Pantallas Vinculadas
[lista de SCR-NNN vinculados a este FA-REQ]

#### TC-FT-SCR-NNN — {nombre-pantalla}
- scr-referencia: SCR-YYY
- flujo: happy-path | alternativo | error
- descripcion: [propósito del caso]
- precondicion: |
    [Usuario con rol {ROL}, datos previos, pantalla anterior]
- pasos:
  - Rellenar campo {campo} con {valor}
  - Hacer clic en botón {botón}
  - Verificar que aparece {elemento}
- resultado-esperado: |
    [Pantalla final, estado, datos persistidos]
- datos-prueba:
  - Happy-path: [valores]
  - Borde: [valores]
- rol-requerido: [ADMIN | GESTOR | etc.]
- bloqueado-por-gap: [FA-GAP-NNN] (si aplica)
```

**Sección 3: Functional Tests de Flujos de Navegación (NAV)**

```yaml
## 3. Functional Tests — Flujos de Navegación

### Flujos Vinculados
[lista de NAV-NNN vinculados a este FA-REQ]

#### TC-FT-NAV-NNN — Navegación {origen} → {destino}
- nav-referencia: NAV-YYY
- desde: SCR-XXX
- hacia: SCR-YYY
- condicion-transicion: [acción del usuario]
- validaciones:
  - Elemento {X} es visible/clickeable
  - Transición ocurre cuando {acción}
  - Condición {Y} bloquea si no se cumple
- alternativas: [rutas no felices]
- bloqueado-por-gap: [FA-GAP-NNN] (si aplica)
```

---

### 3. `output/test-cases/unit-test-coverage-matrix.md`

**Matriz global de cobertura UT → WF4**

Frontmatter:
```yaml
---
app-id: {app-id}
client-id: {client-id}
artifact: unit-test-coverage-matrix
version: "1.0"
iteration: ITER-NNN
generated-at: {timestamp ISO 8601}
generated-by: fa-test-coverage-extractor
wf-destino: WF4
coverage-ut: 0.XX
status: in-progress | final
---
```

**Tabla de trazabilidad UT:**
```
| FA-REQ     | BRN | ENT | TC-UT-BRN | TC-UT-ENT | Total UT | Cobertura | Bloqueado    |
|------------|-----|-----|-----------|-----------|----------|-----------|--------------|
| FA-REQ-001 |  1  |  1  |     3     |     2     |    5     |   100%    | No           |
| FA-REQ-002 |  2  |  0  |     4     |     0     |    4     |    80%    | FA-GAP-015   |
| FA-REQ-003 |  0  |  0  |     0     |     0     |    0     |     0%    | FA-GAP-020   |
```

**Métricas Globales UT:**
- Total FA-REQ: N
- FA-REQ con ≥1 caso UT: N (X%)
- Total TC-UT generados: N (BRN: N, ENT: N)
- TC-UT bloqueados por gaps: [lista FA-GAP]
- FA-REQ sin cobertura UT: [lista FA-REQ]

---

### 4. `output/test-cases/functional-test-coverage-matrix.md`

**Matriz global de cobertura FT → WF5**

Frontmatter:
```yaml
---
app-id: {app-id}
client-id: {client-id}
artifact: functional-test-coverage-matrix
version: "1.0"
iteration: ITER-NNN
generated-at: {timestamp ISO 8601}
generated-by: fa-test-coverage-extractor
wf-destino: WF5
coverage-e2e: 0.XX
coverage-ft: 0.XX
status: in-progress | final
---
```

**Tabla de trazabilidad FT:**
```
| FA-REQ     | Criterios | SCR | NAV | TC-E2E | TC-FT-SCR | TC-FT-NAV | Total FT | Cobertura | Bloqueado |
|------------|-----------|-----|-----|--------|-----------|-----------|----------|-----------|-----------|
| FA-REQ-001 |     3     |  1  |  1  |   3    |     2     |     1     |    6     |   100%    | No        |
| FA-REQ-002 |     2     |  1  |  -  |   2    |     1     |     0     |    3     |    80%    | FA-GAP-015|
| FA-REQ-003 |     1     |  0  |  0  |   0    |     0     |     0     |    0     |     0%    | FA-GAP-020|
```

**Métricas Globales FT:**
- Total FA-REQ: N
- FA-REQ con ≥1 caso E2E: N (X%)
- FA-REQ con ≥1 caso FT: N (X%)
- Total TC-FT generados: N (E2E: N, SCR: N, NAV: N)
- TC-FT bloqueados por gaps: [lista FA-GAP]
- FA-REQ sin cobertura FT: [lista FA-REQ]

---

## Reglas de Generación

### Casos UT (BRN + ENT) → `unit-test-cases.md` → WF4

1. **Por cada BRN-NNN vinculado a FA-REQ:**
   - Mínimo 1 caso happy-path (valores válidos)
   - 1 caso por restricción violada (negative test)
   - 1 caso de borde por restricción (minLength, maxLength, range, pattern)

2. **Por cada ENT-NNN vinculado a FA-REQ:**
   - Tests de constructor (con/sin parámetros)
   - Tests de validación por cada campo restricto
   - Tests de transformación (serialización)

### Casos FT (E2E + SCR + NAV) → `functional-test-cases.md` → WF5

1. **Por cada criterio de aceptación en FA-REQ-NNN:**
   - Generar 1 caso E2E
   - Si criterio es acción → flujo happy-path
   - Si criterio es validación → caso error + caso borde
   - Criterios ASUMIDOS → marcar con `assumption: true`

2. **Por cada SCR-NNN vinculado a FA-REQ:**
   - Happy-path: flujo normal con datos válidos
   - Casos alternativos: roles diferentes, validaciones fallidas
   - Casos de error: campos obligatorios vacíos

3. **Por cada NAV-NNN vinculado a FA-REQ:**
   - Verificar transición bajo condición especificada
   - Verificar bloqueo si condición no se cumple
   - Incluir alternativas y flujos no felices

---

## Validación

Antes de emitir los artefactos, verificar:

1. ✅ Cada FA-REQ-NNN tiene `output/FA-REQ-NNN/unit-test-cases.md`
2. ✅ Cada FA-REQ-NNN tiene `output/FA-REQ-NNN/functional-test-cases.md`
3. ✅ Cada TC referencia correctamente su componente (BRN/ENT para UT, SCR/NAV/criterio para FT)
4. ✅ `unit-test-coverage-matrix.md` incluye TODOS los FA-REQ con sus conteos UT
5. ✅ `functional-test-coverage-matrix.md` incluye TODOS los FA-REQ con sus conteos FT
6. ✅ Gaps bloqueantes registrados en `bloqueado-por-gap`
7. ✅ Trazabilidad bidireccional: FA-REQ ↔ Test Cases ↔ open-gaps.md
8. ✅ Sin TC huérfanos (sin FA-REQ padre)
