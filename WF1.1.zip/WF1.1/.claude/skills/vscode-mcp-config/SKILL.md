---
name: vscode-mcp-config
description: >
  Crear o editar configuración de MCP servers para VS Code Copilot Chat en
  `.vscode/mcp.json` (workspace) o en la configuración de usuario. Cubre tipos
  stdio, sse y http; inputs interactivos para secrets; servers típicos (github,
  atlassian, figma, filesystem). Activar cuando el usuario quiere conectar
  Copilot/Claude a un MCP server o gestionar servers MCP ya configurados.
---

# vscode-mcp-config — Configuración de MCP Servers en VS Code

> **Scope:** Configuración de Model Context Protocol servers para VS Code
> **Cubre:** schema mcp.json, tipos stdio/sse/http, inputs para secrets, scope user vs workspace, servers oficiales más usados
> **No cubre:** implementación de MCP servers (responsabilidad del proveedor); MCP fuera de VS Code (Claude Desktop usa su propio claude_desktop_config.json)

## Cuándo activar

- "Conecta Copilot al MCP de GitHub"
- "Configura el MCP de Atlassian para que vea Jira"
- "Quiero un MCP de filesystem en el workspace"
- "¿Por qué Copilot no ve mi MCP server?" → revisar mcp.json

## Dos niveles de configuración

| Fichero                                  | Alcance                          | Cuándo usarlo                              |
|------------------------------------------|----------------------------------|--------------------------------------------|
| `.vscode/mcp.json`                       | Solo este workspace              | Servers específicos del proyecto           |
| `~/.config/Code/User/mcp.json` (Linux)   | Usuario, todos los workspaces    | Servers personales (GitHub PAT propio)     |
| `%APPDATA%\Code\User\mcp.json` (Windows) | Idem                             | Idem                                       |
| `~/Library/Application Support/Code/User/mcp.json` (Mac) | Idem | Idem |

## Schema canónico

```jsonc
{
  "inputs": [
    {
      "type": "promptString",
      "id": "github-pat",
      "description": "GitHub Personal Access Token",
      "password": true                              // oculta el valor al introducir
    }
  ],
  "servers": {
    "github": {
      "type": "stdio",                              // stdio | sse | http
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${input:github-pat}"
      }
    },
    "atlassian": {
      "type": "sse",
      "url": "https://mcp.atlassian.com/v1/sse",
      "headers": {
        "Authorization": "Bearer ${input:atlassian-token}"
      }
    }
  }
}
```

## Tipos de transport

| Tipo    | Cuándo usarlo                                              | Campos clave                |
|---------|------------------------------------------------------------|-----------------------------|
| `stdio` | Server arranca como proceso local (npm, python, binary)    | `command`, `args`, `env`    |
| `sse`   | Server remoto con Server-Sent Events                        | `url`, `headers`            |
| `http`  | Server remoto con HTTP request/response (streamable)        | `url`, `headers`            |

## Inputs interactivos para secrets

**Regla:** NUNCA poner el valor del secreto literal en `mcp.json`. Usar `inputs[]` con `password: true`.

```jsonc
{
  "inputs": [
    { "type": "promptString", "id": "jira-token", "description": "Jira API token", "password": true },
    { "type": "promptString", "id": "figma-pat",  "description": "Figma PAT",      "password": true }
  ],
  "servers": {
    "jira":  { "type": "sse",   "url": "...", "headers": { "Authorization": "Bearer ${input:jira-token}" } },
    "figma": { "type": "stdio", "command": "...", "env": { "FIGMA_PAT": "${input:figma-pat}" } }
  }
}
```

Alternativa: variables de entorno del sistema. VS Code expande `${env:VAR}`:

```jsonc
{
  "servers": {
    "github": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": { "GITHUB_PERSONAL_ACCESS_TOKEN": "${env:GITHUB_TOKEN}" }
    }
  }
}
```

## Servers oficiales más usados

### filesystem (acceso restringido a directorios)

```jsonc
"filesystem": {
  "type": "stdio",
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-filesystem", "${workspaceFolder}"]
}
```

### github

```jsonc
"github": {
  "type": "stdio",
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-github"],
  "env": { "GITHUB_PERSONAL_ACCESS_TOKEN": "${input:github-pat}" }
}
```

### postgres / sqlite / brave-search / fetch / git / memory

Patrón equivalente, cambiando el paquete `@modelcontextprotocol/server-{name}`.

### atlassian (remoto SSE)

```jsonc
"atlassian": {
  "type": "sse",
  "url": "https://mcp.atlassian.com/v1/sse",
  "headers": { "Authorization": "Bearer ${input:atlassian-token}" }
}
```

### figma

```jsonc
"figma": {
  "type": "stdio",
  "command": "npx",
  "args": ["-y", "figma-developer-mcp", "--stdio"],
  "env": { "FIGMA_PAT": "${input:figma-pat}" }
}
```

## Variables soportadas en mcp.json

- `${input:id}` — referencia a un input declarado
- `${env:VAR}` — variable de entorno del proceso de VS Code
- `${workspaceFolder}` — raíz del workspace (solo en `.vscode/mcp.json`)
- `${userHome}` — directorio home del usuario

## Validaciones aplicables

- ✅ JSON válido (parser admite comentarios JSONC)
- ✅ Cada server tiene `type` válido (stdio | sse | http)
- ✅ `stdio` → `command` obligatorio
- ✅ `sse`/`http` → `url` obligatorio y https://
- ✅ Inputs con `password: true` para tokens
- ✅ Sin valores literales que parezcan secrets (regex: cadena > 20 chars con mezcla letras/dígitos/símbolos)
- ✅ `command` no apunta a binarios destructivos (`rm`, `del`, etc.)
- ✅ Nombres de server únicos en el objeto `servers`

## Reglas de seguridad

1. **NUNCA** escribir tokens/keys literales en mcp.json → usar `${input:id}` o `${env:VAR}`
2. Si el usuario pega por error un valor que parece un token → rechazar y pedir el ID/nombre de variable en su lugar
3. `.vscode/mcp.json` NO debe ir al control de versiones si referencia `${env:}` con secrets específicos del usuario → añadir a `.gitignore` si aplica
4. Para servers compartidos por equipo, usar `.vscode/mcp.json.template` con placeholders y dejar `.vscode/mcp.json` en `.gitignore`

## Procedimiento al añadir un MCP server

1. Determinar el scope (workspace vs user)
2. Si el server requiere credencial → declarar primero el `input` en `inputs[]`
3. Añadir el server al objeto `servers`
4. Validar JSON
5. Indicar al usuario: "Reinicia la sesión de Copilot Chat (`Developer: Reload Window`) para que detecte el nuevo MCP"
6. Verificar en el log de Copilot que el server arranca sin errores

## Diagnóstico cuando un MCP no funciona

| Síntoma                              | Posible causa                                     |
|--------------------------------------|--------------------------------------------------|
| Server no aparece en Copilot         | Falta `Developer: Reload Window` o JSON inválido |
| `Authentication failed`              | Input no resuelto o token caducado               |
| `Command not found` (stdio)          | `npx` no en PATH o paquete no publicado          |
| Server arranca pero no responde      | Versión del MCP server incompatible con VS Code  |
| `CORS error` (sse/http)              | Endpoint no permite el origen de VS Code         |

Logs en VS Code: `Output` panel → dropdown `GitHub Copilot Chat` o `MCP`.
