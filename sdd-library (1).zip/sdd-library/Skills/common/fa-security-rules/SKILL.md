---
name: fa-security-rules
description: >
  Taxonomía de checks de seguridad (SEC-01..SEC-07) y heurísticas de detección
  para el modelo de roles y permisos de una aplicación. Aplicado por
  fa-security-gate tras Gate Coverage. Define cuándo emitir gaps granulares
  (por FA-REQ/pantalla) vs un gap global (SECURITY-PROFILE-INCOMPLETE).
---

# fa-security-rules — Taxonomía de Checks de Seguridad

> **Scope:** Reglas declarativas para verificar el modelo de seguridad de toda la aplicación
> **Cubre:** checks SEC-01..SEC-07, heurísticas de detección, umbrales, decisión granular vs global
> **No cubre:** ejecución — eso lo hace `fa-security-gate`

## Catálogo de Checks

### SEC-01 — Asignación completa de rol por FA-REQ

**Verifica:** cada FA-REQ tiene al menos un rol/permiso asignado de forma inequívoca.

**Heurísticas de fallo:**
- FA-REQ con campo `rol` vacío, "—", "N/A" o "pendiente"
- FA-REQ con rol "Usuario genérico" o "Cualquier usuario" sin discriminación de acceso
- FA-REQ con varios roles posibles sin condición de aplicabilidad

**Gap emitido:** `SECURITY-ROLE-UNDEFINED` (BLOQUEANTE)

---

### SEC-02 — Roles con descripción completa

**Verifica:** cada `ROL-NNN` tiene definidos:
- Qué pantallas puede ver
- Qué acciones puede ejecutar
- Bajo qué condiciones (si las hay)

**Heurísticas de fallo:**
- ROL sin lista de pantallas accesibles
- ROL sin verbos de acción (consultar, crear, modificar, borrar, exportar, imprimir)
- ROL mencionado en un FA-REQ pero no descrito en la sección "Roles" del RESUMEN

**Gap emitido:** `SECURITY-ROLE-AMBIGUOUS` (BLOQUEANTE)

---

### SEC-03 — Sin solapamientos contradictorios

**Verifica:** que no haya dos roles distintos asignados al mismo FA-REQ con permisos contradictorios.

**Heurísticas de fallo:**
- Dos roles con permisos opuestos sobre la misma acción (uno permite, otro deniega)
- Misma pantalla con roles excluyentes sin condición discriminante (ej: "horario laboral")

**Gap emitido:** `SECURITY-ROLE-OVERLAP` (BLOQUEANTE)

---

### SEC-04 — Acciones sensibles cubiertas

**Verifica:** que toda acción que modifica estado del sistema tenga rol asignado explícitamente.

**Acciones sensibles por defecto** (configurable por cliente):
- Insert / Create / Alta
- Update / Modify / Modificación
- Delete / Drop / Baja
- Export / Dump / Volcar
- Print / Imprimir
- Approve / Aprobar
- Sign / Firmar
- Configurar / Settings

**Heurísticas de fallo:**
- FA-REQ con acción sensible y rol "Cualquier usuario" o ausente
- FA-REQ con acción sensible donde el rol se infiere implícitamente (no está escrito)

**Gap emitido:** `SECURITY-ACTION-UNGUARDED` (BLOQUEANTE)

---

### SEC-05 — Lectura discriminada de escritura

**Verifica:** que el modelo distinga roles de consulta (read-only) de roles de mantenimiento (write).

**Heurísticas de fallo:**
- Existe un único rol "Usuario" para todas las acciones (lectura + escritura sin distinción)
- Acción de consulta y de modificación tienen la misma cobertura de rol pero los documentos sugieren que deberían diferir

**Gap emitido:** `SECURITY-ROLE-AMBIGUOUS` variante consulta (RECOMENDADO)

---

### SEC-06 — Auditoría coherente con seguridad

**Verifica:** que las acciones críticas tengan registro de quién/cuándo/qué.

**Heurísticas de fallo:**
- Acción sensible (SEC-04) sin política de auditoría documentada
- FA-REQ que modifica datos financieros/personales sin trazabilidad

**Gap emitido:** referencia cruzada con `NFR-MISSING` (auditoría) — no emite gap propio, enlaza al existente o solicita su creación.

---

### SEC-07 — Modelo de target resuelto

**Verifica:** que cada permiso del sistema origen tenga mapeo claro al stack target.

**Heurísticas de fallo:**
- Permiso del origen (ej: lectura de tabla, claim de JWT, rol de AD) sin equivalente declarado en target
- Documento de migración sugiere mapeo pero `fa-config.yml.project.target` no lo confirma
- Mecanismo de autorización del origen (ej: `T0COFOND`) sin mapeo a la tecnología target

**Gap emitido:** `SECURITY-PERMISSION-UNMAPPED` (BLOQUEANTE)

---

## Umbral de Cobertura de Seguridad

```yaml
security_threshold: 0.90      # default — 90% de FA-REQ con rol claro
security_threshold_incident: 0.70   # relajado para project.type=incident
security_threshold_discovery: 0.80  # relajado para discovery
```

El cliente puede sobrescribir en `{client}-fa-rules` (sección "Seguridad y Permisos").

## Política Granular vs Global

```
Definir N_problems = cantidad total de FA-REQ con algún fallo SEC-01..SEC-07

Caso granular (gaps individuales por FA-REQ/pantalla):
  - N_problems <= 3 Y
  - Pantallas afectadas <= 2 Y
  - No hay solapamientos (SEC-03 pasa) Y
  - No hay >50% de permisos sin mapear (SEC-07)

Caso global (gap SECURITY-PROFILE-INCOMPLETE):
  - N_problems > 3 O
  - Pantallas afectadas > 2 O
  - Hay solapamientos activos O
  - >50% de permisos sin mapear O
  - Operador solicita forzarlo

En caso global:
  - Emitir UN SOLO gap BLOQUEANTE con tipo SECURITY-PROFILE-INCOMPLETE
  - Listar dentro del gap todos los hallazgos granulares como evidencia
  - NO emitir los gaps granulares por separado en open-gaps.md
  - Acción requerida: "Solicitar al PO/Arquitecto matriz completa
    Rol × FA-REQ × Acción para toda la aplicación"
```

## Personalización por cliente

El Client Skill `{client}-fa-rules` puede declarar en su sección de seguridad:

```markdown
## Sección — Seguridad y Permisos del cliente

### Acciones sensibles adicionales (extiende la lista por defecto)
- Validar (proceso de aprobación interna)
- Exportar a impresora (compliance auditoría)

### Roles del cliente (mapeo a IDs estándar)
| Nombre cliente | ROL-ID estándar | Notas |
|----------------|-----------------|-------|
| ...

### Umbral propio
security_threshold: 0.95   # cliente con normativa estricta

### Política de consulta
require_explicit_read_permission: true   # toda consulta exige permiso explícito
```

## Integración con common/requirements-governance

La sección `security_requirements` del skill de gobernanza (`common/requirements-governance`) declara los checks **obligatorios**. Por defecto los 7 (SEC-01..SEC-07). El cliente puede pedir saltarse algunos en su `governance-overrides`:

```yaml
governance-overrides:
  security:
    skip_checks: [SEC-05]    # ej: aplicación read-only no necesita SEC-05
    threshold_override: 0.85
```

El skill aplica el merge y el `fa-security-gate` documenta la política efectiva en `resources/security-effective.md`.
