---
name: vscode-tasks-config
description: >
  Crear o editar .vscode/tasks.json para definir tareas de VS Code (build, test,
  lint, scripts personalizados). Cubre tipos shell, process, npm, gulp y typescript;
  problemMatchers, grupos, presentation, dependsOn, variables ${workspaceFolder}.
  Activar cuando el usuario pide configurar build/test runners, atajos de tareas,
  o automatizar comandos del proyecto desde la paleta de VS Code.
---

# vscode-tasks-config — Configuración de Tareas de VS Code

> **Scope:** Creación y edición de `.vscode/tasks.json`
> **Cubre:** schema 2.0.0, tipos de tarea, problemMatchers, grupos build/test, dependsOn, presentation, variables
> **No cubre:** ejecución de tareas (responsabilidad de VS Code); configuración de debug (ver `vscode-launch-config`)

## Cuándo activar

- "Configura un build con npm run build" → tasks.json con tipo `npm`
- "Añade una tarea para correr los tests" → tasks.json con `group: test`
- "Crea una tarea de lint con eslint" → tasks.json con problemMatcher `$eslint-stylish`
- "Quiero ejecutar X comando con Ctrl+Shift+B" → tasks.json con `group: { kind: build, isDefault: true }`

## Schema canónico

```jsonc
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "build",                        // único en el array
      "type": "shell",                          // shell | process | npm | gulp | typescript
      "command": "npm",
      "args": ["run", "build"],
      "group": {
        "kind": "build",                        // build | test | none
        "isDefault": true                       // un único default por kind
      },
      "problemMatcher": ["$tsc"],              // matcher para parsear errores
      "presentation": {
        "reveal": "always",                    // always | silent | never
        "panel": "shared",                     // shared | dedicated | new
        "clear": false,
        "echo": true,
        "focus": false,
        "showReuseMessage": true
      },
      "dependsOn": ["clean"],                 // ejecuta otras tareas antes
      "dependsOrder": "sequence",             // sequence | parallel
      "options": {
        "cwd": "${workspaceFolder}/packages/api",
        "env": { "NODE_ENV": "development" }
      }
    }
  ]
}
```

## Tipos de tarea

| Tipo         | Cuándo usarlo                                            | Campos clave             |
|--------------|----------------------------------------------------------|--------------------------|
| `shell`      | Comando ejecutado por el shell del sistema (con quoting)  | `command`, `args`        |
| `process`    | Ejecución directa del binario (sin shell)                 | `command`, `args`        |
| `npm`        | Scripts de package.json                                   | `script`, `path`         |
| `gulp`       | Tareas Gulp                                              | `task`                   |
| `typescript` | tsc con tsconfig                                          | `tsconfig`, `option`     |

## ProblemMatchers comunes (built-in)

| Matcher              | Para qué                          |
|----------------------|-----------------------------------|
| `$tsc`               | TypeScript compiler errors        |
| `$tsc-watch`         | tsc --watch                       |
| `$eslint-compact`    | ESLint en modo compact            |
| `$eslint-stylish`    | ESLint en modo stylish (default)  |
| `$go`                | Go build/test                     |
| `$gcc`               | GCC/Clang                         |
| `$msCompile`         | MSBuild / .NET                    |
| `$python`            | pyflakes / pylint                 |

Para un matcher custom, declarar `problemMatcher` como objeto con `owner`, `pattern`, `fileLocation`.

## Variables predefinidas más usadas

- `${workspaceFolder}` — raíz del workspace
- `${workspaceFolderBasename}` — solo el nombre de la carpeta raíz
- `${file}` — fichero abierto
- `${fileBasename}`, `${fileBasenameNoExtension}`, `${fileDirname}`, `${fileExtname}`
- `${cwd}` — directorio actual de la terminal
- `${env:VAR}` — variable de entorno
- `${input:varName}` — input interactivo (declarado en `inputs[]`)

## Ejemplos por stack

### Node + npm

```jsonc
{
  "version": "2.0.0",
  "tasks": [
    { "label": "install", "type": "npm", "script": "install", "problemMatcher": [] },
    { "label": "build",   "type": "npm", "script": "build",   "group": { "kind": "build", "isDefault": true }, "problemMatcher": ["$tsc"] },
    { "label": "test",    "type": "npm", "script": "test",    "group": { "kind": "test", "isDefault": true } }
  ]
}
```

### Python

```jsonc
{
  "version": "2.0.0",
  "tasks": [
    { "label": "lint",  "type": "shell", "command": "ruff", "args": ["check", "."], "problemMatcher": [] },
    { "label": "tests", "type": "shell", "command": "pytest", "args": ["-q"], "group": { "kind": "test", "isDefault": true } }
  ]
}
```

### Java/Maven

```jsonc
{
  "version": "2.0.0",
  "tasks": [
    { "label": "package", "type": "shell", "command": "mvn", "args": ["package"], "group": { "kind": "build", "isDefault": true } },
    { "label": "test",    "type": "shell", "command": "mvn", "args": ["test"],    "group": { "kind": "test",  "isDefault": true } }
  ]
}
```

### .NET

```jsonc
{
  "version": "2.0.0",
  "tasks": [
    { "label": "build", "type": "process", "command": "dotnet", "args": ["build"], "problemMatcher": ["$msCompile"], "group": { "kind": "build", "isDefault": true } },
    { "label": "test",  "type": "process", "command": "dotnet", "args": ["test"],  "problemMatcher": ["$msCompile"], "group": { "kind": "test",  "isDefault": true } }
  ]
}
```

## Inputs interactivos

```jsonc
{
  "version": "2.0.0",
  "inputs": [
    { "id": "env", "type": "pickString", "options": ["dev", "stg", "prod"], "default": "dev", "description": "Entorno" }
  ],
  "tasks": [
    { "label": "deploy", "type": "shell", "command": "deploy.sh", "args": ["--env", "${input:env}"] }
  ]
}
```

## Validaciones aplicables

- ✅ `version: "2.0.0"` obligatoria
- ✅ `label` único en el array `tasks[]`
- ✅ Solo un `isDefault: true` por `group.kind`
- ✅ `dependsOn` referencia labels existentes
- ✅ Si `dependsOrder: parallel` → no usar `dependsOn` como cadena lineal
- ✅ `command` ≠ vacío
- ❌ Evitar `"command": "rm -rf ..."` u operaciones destructivas sin confirmación

## Procedimiento al editar

1. Si `.vscode/tasks.json` no existe → crearlo con `version: "2.0.0"` y `tasks: []`
2. Si existe → leerlo, parsear el JSON (soporta comentarios JSONC), añadir/modificar
3. Mantener el orden alfabético por `label` cuando sea posible
4. Preservar comentarios JSONC existentes
5. Mostrar al usuario el comando paleta para lanzar: `Tasks: Run Task` → seleccionar `{label}`
