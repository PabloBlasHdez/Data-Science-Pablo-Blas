---
name: fa-source-scanner
description: >
  Inventaría las fuentes locales disponibles y valida los canales de acceso a
  fuentes remotas (MCP nativo y/o ficheros input/remote/*.yml). Detecta gaps
  REMOTE-CHANNEL-MISSING. Autogenera stubs .yml cuando solo existe canal MCP.
---

# fa-source-scanner — Validación de Fuentes y Canales

> **Scope:** Validación de fuentes y canales de acceso en PRE-CONDICIÓN WF1-FA
> **Cubre:** validacion-canales, matriz-resolucion-mcp-yml, stubs, seguridad-credenciales, dialogo-interactivo
> **No cubre:** extracción del contenido de las fuentes — eso es fa-*-extractor

## Matriz de Resolución de Canales

Para cada fuente con `enabled: true` en `fa-config.yml`, se evalúan dos canales:
- **Canal MCP nativo:** `mcp-server` registrado en la plataforma (acceso en tiempo real)
- **Canal fichero:** `input/remote/{tool}.yml` con export descargado o declaración

| Caso | MCP Nativo | `input/remote/*.yml` | Comportamiento en runtime                                      |
|------|-----------|----------------------|----------------------------------------------------------------|
| **1** | ✅ Existe | ✅ Existe           | MCP gana en runtime · `.yml` es documentación auditable y fallback offline |
| **2** | ✅ Existe | ❌ No existe        | MCP único · autogenerar stub `.yml` con `# autogenerado`       |
| **3** | ❌ No existe | ✅ Existe         | Solo `.yml` · usar export estático (modo offline)              |
| **4** | ❌ No existe | ❌ No existe       | **Diálogo interactivo** · solicitar al operador URL + nombre de variable de entorno para credencial (ver "Diálogo Interactivo de Configuración Remota"). Si el operador cancela → emitir FA-GAP `REMOTE-CHANNEL-MISSING` → abortar |

## Procedimiento de Validación

```
Para cada sources.{tool} con enabled: true en fa-config.yml:
  1. ¿Existe mcp-server en configuración de plataforma? → canal_mcp = true/false
  2. ¿Existe input/remote/{tool}.yml?                   → canal_yml = true/false
  3. Aplicar matriz → determinar caso (1/2/3/4)
  4. Caso 4 → ACTIVAR DIÁLOGO INTERACTIVO (ver sección dedicada):
              - Si el operador completa el diálogo → generar input/remote/{tool}.yml
                con los datos proporcionados y reevaluar (pasa a Caso 1 o 3)
              - Si el operador cancela → registrar FA-GAP REMOTE-CHANNEL-MISSING
                y abortar workflow
  5. Caso 2 → autogenerar stub input/remote/{tool}.yml
  6. Caso 1 → registrar precedencia: MCP gana en runtime
  7. Documentar resultado en log de pre-condición
```

## Diálogo Interactivo de Configuración Remota

Activado en **Caso 4** (ni MCP nativo ni `.yml` declarado) para evitar abortar el
workflow cuando el operador puede aportar los datos en ese momento. También se
invoca desde `fa-run-workflow` paso 0b al definir nuevas fuentes remotas (ver
ese skill para el flujo proactivo).

### Reglas básicas

- **Una herramienta por vez** — secuencial, no batch. El operador ve un diálogo por cada `{tool}` sin canal.
- **NUNCA solicitar el valor de la credencial.** Solo se pregunta el **nombre** de la variable de entorno que la contendrá (ej: `JIRA_TOKEN`). El valor real lo configura el operador fuera del workflow (perfil de shell, gestor de secretos, etc.).
- **Validación de la variable de entorno** — tras recibir el nombre, comprobar si está definida en el entorno actual. Si no lo está, emitir advertencia pero NO bloquear (el operador puede configurarla antes de la siguiente fase).
- **Cancelación segura** — si el operador cancela el diálogo, no escribir nada y devolver control al procedimiento (que registrará el FA-GAP).

### Especificación del diálogo (por herramienta)

Usar el mecanismo nativo de preguntas interactivas del agente (en Claude Code:
herramienta `AskUserQuestion` o equivalente). El diálogo presenta los siguientes
campos en orden, agrupados en una única ventana cuando el mecanismo lo permita:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Configurar canal para fuente remota: {tool}  ({type})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Por seguridad, NO se solicita el valor del token.
Solo el NOMBRE de la variable de entorno donde lo tienes guardado.

Campo 1 — URL del sistema:
  Ejemplo: https://empresa.atlassian.net  (Jira)
           https://www.figma.com         (Figma)
           https://empresa.atlassian.net/wiki  (Confluence)
  Valor: _

Campo 2 — Identificador del proyecto/espacio:
  Para Jira/ADO  → código del proyecto (ej: MYAPP)
  Para Figma     → file-key del proyecto (ej: AbCdEf123456)
  Para Confluence→ space-key (ej: PROJSPACE)
  Valor: _

Campo 3 — ¿Existe MCP nativo configurado para esta herramienta? (s/n):
  Si responde "s" →
    Campo 3a — Nombre del MCP server (ej: jira-mcp):
      Valor: _
  Si responde "n" → omitir 3a

Campo 4 — Esquema de autenticación:
  [a] Token único (PAT, API key)
  [b] Basic (usuario + clave/PAT)
  [c] OAuth client credentials (client_id + client_secret)
  Valor: _

  Si Campo 4 = a → Campo 4a:
    Nombre de la variable de entorno con el token:
      Convención: {TOOL}_TOKEN o {TOOL}_API_KEY (en mayúsculas)
      Ejemplos: JIRA_TOKEN, FIGMA_PAT, CONFLUENCE_API_KEY
      ⚠️ Solo el NOMBRE de la variable, NUNCA el valor.
      Valor: _

  Si Campo 4 = b → Campo 4b (dos variables):
    Nombre de la variable con el usuario:
      Convención: {TOOL}_USER
      Ejemplos: JIRA_USER, FIGMA_USER, CONFLUENCE_USER
      ⚠️ Solo el NOMBRE de la variable.
      Valor: _
    Nombre de la variable con la clave/PAT:
      Convención: {TOOL}_PASSWORD o {TOOL}_TOKEN
      Ejemplos: JIRA_PASSWORD, FIGMA_PASSWORD, CONFLUENCE_TOKEN
      ⚠️ Solo el NOMBRE de la variable.
      Valor: _

  Si Campo 4 = c → Campo 4c (dos variables):
    Nombre de la variable con el client_id:
      Convención: {TOOL}_CLIENT_ID
      Ejemplos: SHAREPOINT_CLIENT_ID, ADO_CLIENT_ID
      Valor: _
    Nombre de la variable con el client_secret:
      Convención: {TOOL}_CLIENT_SECRET
      Ejemplos: SHAREPOINT_CLIENT_SECRET, ADO_CLIENT_SECRET
      Valor: _

Campo 5 — Descripción breve del propósito (opcional):
  Ejemplo: "Backlog e HU del proyecto MYAPP"
  Valor: _ (puede dejarse vacío)

[Aceptar] [Cancelar]
```

### Sub-diálogo específico de Jira — Alcance (épica vs HDU)

Si `{tool} = jira`, tras los Campos 1–5 anteriores se abre un **segundo paso**
obligatorio para acotar el alcance del análisis. Sin esta acotación el extractor
trataría todo el proyecto Jira como entrada, lo que rara vez es lo deseado.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Configurar alcance de Jira: {project}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Campo J1 — Tipo de elemento de entrada:
  [a] Épica  — se extraerán todas las HDU vinculadas a la(s) épica(s)
  [b] HDU    — se extraerán solo las HDU indicadas (sin recorrer épicas)
  Valor: _

Campo J2 — ¿Es una o varias?
  [a] Una sola
  [b] Varias
  Valor: _

Campo J3 — Identificador(es):
  Si J2 = "Una sola" → introducir una clave (ej: MYAPP-EP-001 o MYAPP-123).
  Si J2 = "Varias"   → introducir lista separada por coma
                       (ej: MYAPP-EP-001, MYAPP-EP-002
                        o MYAPP-1, MYAPP-2, MYAPP-15).
  Valor: _

[Aceptar] [Cancelar]
```

### Validaciones del sub-diálogo de Jira

```
J1. Tipo de elemento — debe ser "a" (épica) o "b" (HDU). Otro valor → reabrir J1.

J2. Cardinalidad — debe ser "a" (una) o "b" (varias). Otro valor → reabrir J2.

J3. Identificadores — cada clave debe cumplir regex ^[A-Z][A-Z0-9]*-[A-Z0-9-]+$
    (código de proyecto en mayúsculas + guion + identificador del issue).
    - Si J2 = "Una sola" y se introducen ≥2 claves separadas por coma →
      avisar: "Has indicado varias claves pero el modo es 'Una sola'.
              ¿Cambiar a 'Varias'? (s/n)"
      Si s → reasignar J2=b y continuar
      Si n → reabrir J3 pidiendo una sola clave
    - Si J2 = "Varias" y se introduce una sola clave →
      no es error; aceptar como lista de un elemento.
    - Si alguna clave no cumple el regex → reabrir J3 con la clave problemática
      marcada y mensaje correctivo.
    - El prefijo de cada clave debe coincidir con el `project` del Campo 2.
      Si no coincide → advertencia (no bloquea): "La clave {KEY} no pertenece
      al proyecto {PROJECT}. ¿Continuar de todos modos? (s/n)"

Cancelación — si el operador cancela este sub-diálogo:
  → NO escribir input/remote/jira.yml
  → Excluir Jira de sources.* en fa-config.yml
  → Mostrar aviso: "Jira no configurada — se omitirá del análisis"
```

### Validaciones aplicadas tras el diálogo

```
1. URL — debe empezar por https:// (rechazar http:// con aviso de seguridad)

2. Esquema de autenticación (Campo 4) — debe ser "a" (token), "b" (basic) o
   "c" (oauth). Otro valor → reabrir Campo 4.

3. Nombre de variable de entorno — TODOS los campos de credenciales son
   nombres de variables (NUNCA valores). Verificar que cada nombre cumple
   regex ^[A-Z][A-Z0-9_]*$ (mayúsculas, dígitos y guiones bajos; empieza
   por letra). Aplica a:
     • scheme=token  → token_var
     • scheme=basic  → user_var, password_var (ambos)
     • scheme=oauth  → client_id_var, client_secret_var (ambos)
   Si alguno NO cumple → reabrir solo ese campo con mensaje correctivo.

4. Detección de secretos accidentales — aplica a TODOS los campos de
   credenciales (no solo al token). Reglas:
     • Si la cadena introducida contiene ":", "/", "@" o espacios → probable
       valor literal (ej: "usuario@empresa.com", "Pa$$w0rd!", "Bearer eyJ...")
       → REHUSAR.
     • Si la cadena tiene longitud > 20 y mezcla letras/dígitos/símbolos
       sin estructura de identificador → probable token literal → REHUSAR.
     • Si la cadena contiene minúsculas → no es un nombre de variable
       válido (regex del punto 3) → REHUSAR.
   Mensaje al rehusar:
   "Detectado posible valor de credencial en el campo {N}. Por seguridad
    SOLO se admite el NOMBRE de la variable de entorno, no su valor.
    Configura la variable fuera del workflow y reintroduce solo el nombre:
      Windows (PowerShell): $env:{NOMBRE_SUGERIDO} = '<valor>'
      Linux/Mac (bash):     export {NOMBRE_SUGERIDO}='<valor>'"

5. Verificación de existencia de cada variable en el entorno actual:
   - En Windows: comprobar $env:{VAR_NAME}
   - En Linux/Mac: comprobar $VAR_NAME
   - Si NO existe → advertencia (no bloquea):
     "⚠️  La variable {VAR_NAME} no está definida en el entorno actual.
      Configúrala antes de que el workflow intente consumir esta fuente."
   - Para scheme=basic y scheme=oauth, comprobar las DOS variables
     independientemente y avisar de cada una que falte.

6. Nombres redundantes — si para scheme=basic el operador introduce el
   mismo nombre de variable para user_var y password_var, o para
   scheme=oauth el mismo para client_id_var y client_secret_var
   → reabrir con error: "Las dos variables deben tener nombres distintos."
```

### Escritura del `.yml` tras diálogo exitoso

Generar `input/remote/{tool}.yml` con frontmatter `# generado por diálogo interactivo`:

```yaml
# input/remote/{tool}.yml
# Generado por diálogo interactivo de fa-source-scanner — {YYYY-MM-DD}
# Editable: puedes modificar URL, proyecto o nombre de variable de entorno.
# NUNCA escribas valores de credenciales aquí — solo referencias ${VAR_NAME}.
type: {jira|figma|confluence|ado|notion|sharepoint}
url: {URL del campo 1}
project: {identificador del campo 2}
enabled: true

# Canales de acceso:
{si campo 3 = s:}
mcp-server: {nombre del campo 3a}
{fin si}
# export-path: input/remote/exports/{tool}-export.json  # descomenta si dispones de export

# Credenciales — SIEMPRE por referencia a variables de entorno (NUNCA literales):
{si campo 4 = a (token):}
auth:
  scheme: token
  token: ${{NOMBRE del campo 4a}}
{si campo 4 = b (basic):}
auth:
  scheme: basic
  user: ${{NOMBRE del primer campo 4b}}
  password: ${{NOMBRE del segundo campo 4b}}
{si campo 4 = c (oauth):}
auth:
  scheme: oauth
  client_id: ${{NOMBRE del primer campo 4c}}
  client_secret: ${{NOMBRE del segundo campo 4c}}
{fin si}

description: "{campo 5 o cadena por defecto si vacío}"

{si tool = jira:}
# Alcance del análisis — definido en el sub-diálogo de Jira (campos J1, J2, J3):
scope:
  kind: {epic|story}        # epic = recorrer HDU vinculadas a cada épica
                            # story = procesar solo las HDU listadas
  keys:                     # lista (siempre array, incluso si es una sola clave)
    - {clave 1}
    {- ...resto de claves si J2 = varias}
{fin si}
```

> **Compatibilidad hacia atrás (legacy):** un `.yml` existente con
> `api-token: ${VAR}` al nivel raíz se sigue aceptando y se trata como
> equivalente a:
> ```yaml
> auth:
>   scheme: token
>   token: ${VAR}
> ```
> Los extractores deben normalizar internamente a la estructura `auth.*`
> antes de procesar. El diálogo interactivo SOLO genera la nueva forma.

> **Nota Jira:** `scope.kind` y `scope.keys` son obligatorios cuando `type: jira`.
> Si el operador edita el `.yml` manualmente y elimina la sección `scope`, el
> extractor emitirá `REMOTE-SCOPE-MISSING` y abortará el análisis Jira en esa
> iteración (las demás fuentes continúan).

Tras escribir el fichero, **reevaluar la matriz** para esa `{tool}`:
- Si el operador declaró MCP → ahora es Caso 1
- Si no → ahora es Caso 3

Continuar el procedimiento normal.

## Reglas de Seguridad — Credenciales

**NUNCA incluir credenciales (tokens, contraseñas, usuarios, client_id,
client_secret) en ficheros del repositorio, logs ni artefactos generados.**

Esta regla aplica a TODOS los esquemas de autenticación soportados:

```yaml
# ───────── Correcto (los tres esquemas) ─────────
# Esquema 1 — Token único:
auth:
  scheme: token
  token: ${JIRA_TOKEN}

# Esquema 2 — Basic (usuario + clave):
auth:
  scheme: basic
  user: ${FIGMA_USER}
  password: ${FIGMA_PASSWORD}

# Esquema 3 — OAuth client credentials:
auth:
  scheme: oauth
  client_id: ${SHAREPOINT_CLIENT_ID}
  client_secret: ${SHAREPOINT_CLIENT_SECRET}

# ───────── INCORRECTO — nunca así ─────────
auth:
  scheme: token
  token: "eyJhbGciOiJIUzI1NiJ9..."          # ❌ valor literal
auth:
  scheme: basic
  user: "lgasset@empresa.com"                # ❌ usuario literal
  password: "Pa$$w0rd!"                      # ❌ contraseña literal
```

**Reglas que aplican siempre, sin excepción:**

1. El `.yml` SOLO contiene la referencia `${NOMBRE_VARIABLE}`. El valor de
   cada credencial vive en el entorno del operador (variable de shell,
   gestor de secretos corporativo, Key Vault, etc.) y NUNCA es leído ni
   guardado por este workflow.
2. Los nombres de variable que aparecen en el `.yml` se consideran
   metadatos no sensibles (no son secretos). Aun así, deben cumplir el
   regex `^[A-Z][A-Z0-9_]*$` para evitar que un valor real se cuele.
3. El **diálogo interactivo** rehúsa cualquier entrada que parezca un
   valor real (ver "Validaciones aplicadas tras el diálogo", punto 4):
   no acepta caracteres `:`, `/`, `@`, espacios, ni cadenas mixtas largas.
4. Los **extractores** que consumen estos `.yml` resuelven `${VAR}` leyendo
   el entorno del proceso EN MEMORIA. Nunca deben:
     • escribir el valor resuelto en logs, RESUMENes ni artefactos
       (resources/, output/, operator/)
     • incluir el valor en mensajes de error o trazas de depuración
     • exponerlo en el dashboard del operador
   Cualquier traza que muestre la credencial debe enmascararla como
   `${VAR_NAME}=***` o `<redacted>`.
5. Si un `.yml` editado manualmente contiene un valor que NO empieza por
   `${` y `}` (es decir, parece un literal en cualquier campo de `auth.*`),
   el fa-source-scanner debe emitir FA-GAP `REMOTE-CREDENTIAL-LITERAL`
   (BLOQUEANTE), abortar el análisis de esa fuente y mostrar instrucciones
   para mover el valor al entorno y dejar solo la referencia.

El operador es responsable de configurar las variables fuera del workflow:
```
Windows (PowerShell):  $env:JIRA_TOKEN = '<valor>'
Linux/Mac (bash):      export JIRA_TOKEN='<valor>'
Gestores de secretos:  AWS Secrets Manager, Azure Key Vault, HashiCorp Vault, etc.
```

## Formato del Stub Autogenerado (Caso 2)

```yaml
# input/remote/{tool}.yml
# autogenerado por fa-source-scanner — editable
# Generado porque se detectó mcp-server pero no existía fichero de declaración
type: {jira|figma|confluence|ado|notion|sharepoint}
url: {url-extraída-de-configuración-MCP-si-disponible}
enabled: true
mcp-server: {nombre-del-mcp-registrado}

# Credenciales — descomenta el esquema que corresponda y configura los
# nombres de variable de entorno. NUNCA escribas valores literales.
# auth:
#   scheme: token
#   token: ${JIRA_TOKEN}
# auth:
#   scheme: basic
#   user: ${JIRA_USER}
#   password: ${JIRA_PASSWORD}
# auth:
#   scheme: oauth
#   client_id: ${JIRA_CLIENT_ID}
#   client_secret: ${JIRA_CLIENT_SECRET}

description: "Stub autogenerado — completar con URL y descripción del proyecto"
```

## Schema Completo de `input/remote/{tool}.yml`

```yaml
type: jira                          # jira | figma | confluence | ado | notion | sharepoint
url: https://empresa.atlassian.net
project: MYAPP                      # código de proyecto (Jira/ADO) o espacio (Confluence)
enabled: true

# Canales de acceso — al menos uno debe existir:
mcp-server: jira-mcp                # nombre del MCP nativo en la plataforma
export-path: input/remote/exports/jira-export.json  # export descargado (fallback)

# Credenciales — SIEMPRE por variables de entorno. Uno y solo uno de los
# tres esquemas siguientes:
auth:
  scheme: token                     # token | basic | oauth
  token: ${JIRA_TOKEN}
  # scheme: basic →
  #   user: ${JIRA_USER}
  #   password: ${JIRA_PASSWORD}
  # scheme: oauth →
  #   client_id: ${JIRA_CLIENT_ID}
  #   client_secret: ${JIRA_CLIENT_SECRET}

description: "Backlog e HU del proyecto MYAPP"

# Alcance — SOLO para type: jira (obligatorio):
#   kind = epic   → procesar las épicas listadas Y todas sus HDU vinculadas
#   kind = story  → procesar únicamente las HDU listadas
scope:
  kind: epic                        # epic | story
  keys:
    - MYAPP-EP-001
    - MYAPP-EP-002
```

### Compatibilidad hacia atrás (legacy)

Los `.yml` generados antes de esta versión usan `api-token: ${VAR}` al nivel
raíz. Esa forma sigue siendo válida en lectura: los extractores la normalizan
internamente a:

```yaml
auth:
  scheme: token
  token: ${VAR}
```

El diálogo interactivo SOLO genera la forma nueva (`auth.*`). Si fa-source-scanner
detecta un `.yml` legacy y `api-token` contiene un literal en lugar de `${...}`,
emite `REMOTE-CREDENTIAL-LITERAL` (BLOQUEANTE) y aborta esa fuente.

## Inventario de Fuentes Locales

Además de validar canales remotos, `fa-source-scanner` inventaría las fuentes locales:

```
Directorios a inventariar:
  input/docs/    → documentos de texto (PDF, DOCX, TXT, MD)
  input/screens/ → imágenes (PNG, JPG, GIF, SVG, PDF de diseño)
  input/specs/   → specs técnicas (YAML, JSON, RAML, SQL, .feature, .drawio)
```

**Inferencia de tipo por extensión:**

| Extensión             | Tipo inferido       | Agente que la procesa      |
|-----------------------|---------------------|----------------------------|
| .pdf, .docx, .txt, .md | Documentación      | fa-docs-analyzer           |
| .png, .jpg, .gif, .svg | Captura/Wireframe  | fa-ui-analyzer             |
| .pdf (en screens/)    | Exportación Figma   | fa-ui-analyzer             |
| .yaml, .json (OpenAPI)| Contrato API        | fa-requirements-analyzer   |
| .raml                 | Contrato API RAML   | fa-requirements-analyzer   |
| .sql                  | Schema BD           | fa-requirements-analyzer   |
| .feature              | Gherkin             | fa-requirements-analyzer   |
| .drawio, .xml (draw)  | Diagrama navegación | fa-ui-analyzer             |

## Salida: Log de Pre-condición

El fa-source-scanner produce un resumen en el log del orquestador con:
- Lista de todas las fuentes habilitadas y su canal resuelto
- Stubs generados (si aplica)
- Gaps REMOTE-CHANNEL-MISSING emitidos (si aplica)
- Inventario de ficheros locales por directorio
