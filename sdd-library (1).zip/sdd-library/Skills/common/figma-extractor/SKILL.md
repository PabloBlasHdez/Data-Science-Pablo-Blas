---
name: figma-extractor
description: >
  Mapeo de frames y componentes Figma a SCR-NNN del inventario de pantallas.
  Activo cuando input/remote/figma.yml tiene enabled: true o existen exportaciones
  en input/screens/. Usa capacidad multimodal para leer exportaciones PDF/PNG.
---

# figma-extractor — Extracción de Diseños Figma

> **Scope:** Extracción de pantallas y flujos desde diseños Figma en WF1-FA
> **Cubre:** mapeo-frames-scr, flujos-de-navegacion-figma, exportaciones-pdf, variantes
> **No cubre:** diseño visual/CSS — eso es WF2/WF3; componentes de diseño internos sin funcionalidad

## Activación

Se activa cuando:
- `input/remote/figma.yml` tiene `enabled: true`, O
- Existen ficheros en `input/screens/` con extensión `.pdf`, `.png`, `.jpg`, `.svg`

## Modalidades de Acceso

### Modalidad 1: MCP Nativo Figma
Si `mcp-server: figma-mcp` está disponible → acceso en tiempo real a los frames.

**Queries típicas con MCP Figma:**
```
- Listar páginas del fichero Figma
- Listar frames de una página
- Obtener nodos de un frame con sus propiedades
- Obtener conexiones de prototipo (origen → destino de cada conexión)
```

### Modalidad 2: Export descargado (PDF/PNG/imágenes)
Si solo existe el export → usar `fa-ui-extractor` para leer las imágenes con Read().

Aplicar las reglas de `fa-ui-extractor` para extracción multimodal.

## Nomenclatura Figma → SCR-NNN

### Mapeo directo por nombre de frame
```
Nombre frame Figma          → Nombre funcional SCR
"Búsqueda de Contratos"     → SCR-NNN: Búsqueda de Contratos
"01-Login"                  → SCR-NNN: Login (eliminar prefijo numérico)
"Detalle Contrato - Estado Error" → SCR-NNN: Detalle de Contrato (estado: Error)
"DEPRECATED - Pantalla Antigua"   → SCR-NNN: [CÓDIGO MUERTO] Pantalla Antigua
```

**Reglas de normalización del nombre:**
- Eliminar prefijos numéricos ("01-", "02-")
- Eliminar sufijos de estado ("- Mobile", "- Desktop", "- Empty State")
- Preservar el estado en el campo `estados` del SCR
- Eliminar variantes técnicas ("- Hover", "- Pressed", "- Disabled")

## Estructura de Páginas Figma

Figma organiza el contenido en Páginas → Frames → Capas.

| Nivel Figma | Mapeo funcional                                            |
|-------------|-------------------------------------------------------------|
| Página      | Módulo o dominio funcional (ej: "Módulo Contratos")        |
| Frame       | Pantalla (SCR-NNN)                                         |
| Sección     | Estado o variante de la misma pantalla                     |
| Componente  | Elemento reutilizable (no crear SCR separada)              |
| Prototipo   | Conexiones entre frames → NAV-NNN                          |

## Extracción de Flujos de Prototipo

Si el fichero Figma tiene prototipo configurado:
- Cada conexión de prototipo = transición NAV-NNN
- Origen: frame donde está el elemento con la conexión
- Destino: frame al que lleva la conexión
- Condición: tipo de interacción de la conexión (Click, Hover, On tap, After delay)

```
Conexión Figma:
  From: Frame "Búsqueda de Contratos" / Component "Fila de tabla"
  Trigger: On click
  To: Frame "Detalle de Contrato"
  
→ NAV-001: SCR-001 → SCR-002 / Condición: Click en fila de tabla
```

## Extracción de Variantes y Estados

Figma usa "Variant" para estados de un componente. Extraer estados relevantes:

| Variante Figma                  | Estado SCR a registrar     |
|---------------------------------|----------------------------|
| "State=Empty"                   | estado: vacío              |
| "State=Loading" / "State=Skeleton" | estado: cargando        |
| "State=Error"                   | estado: error              |
| "State=Default" / "State=Filled"| estado: con-datos          |
| "State=Disabled"                | estado: deshabilitado      |

Los mensajes de error visibles en el estado "Error" son candidatos a BRN.

## Exportación PDF Multi-Frame

Cuando el export es un PDF de Figma con múltiples páginas:
1. Cada página = posible frame/pantalla
2. Si el PDF tiene índice → usar nombres del índice como nombres SCR
3. Leer en lotes (respetando límite por APP_SIZE)
4. Mantener orden del PDF como orden sugerido de flujo de usuario

## Anotaciones de Diseño

Figma permite añadir notas (sticky notes, comentarios). Si son visibles en el export:
- Anotaciones de "TODO" o "POR DEFINIR" → FA-GAP SCOPE-UNCLEAR
- Anotaciones de permisos → añadir a roles del SCR
- Anotaciones de reglas de negocio → candidatos a BRN (confianza INFERRED)
