---
name: fa-generate-output
description: >
  Ensambla todos los artefactos finales del WF1-FA a partir del FA-SYNTHESIS-RESUMEN
  y open-gaps.md. Genera la estructura output/ (para WF2) y operator/ (para el
  equipo humano). Invocado por fa-run-workflow en FASE 3.
---

# fa-generate-output — Ensamblado de Artefactos WF1-FA

## Invocación

Este skill es invocado por el orquestador `fa-run-workflow` en FASE 3.
También puede invocarse directamente en modo `reassemble`:

```
/fa-generate-output {APP_ID} {ITER_ID}
```

## Inputs Requeridos

Verificar que existen antes de proceder:
- `resources/FA-SYNTHESIS-RESUMEN.md` — síntesis consolidada de FASE 2
- `resources/open-gaps.md` — gaps activos (puede estar vacío)
- `fa-config.yml` → app-id, client-id, iteration, project.type

Si falta `FA-SYNTHESIS-RESUMEN.md` → ERROR: indicar que FASE 2 no ha completado.

## Proceso de Generación

### Paso 1: Leer el registro maestro de FA-REQ

Extraer de `FA-SYNTHESIS-RESUMEN.md` la sección "Registro maestro FA-REQ":
```
Lista de todos los FA-REQ-NNN con estado:
  CONFIRMADO → incluir en output/
  BLOQUEADO  → incluir en output/ con flag wf2-ready: false
  EXCLUIDO   → registrar solo en sección de exclusiones de requirements-registry.md
```

### Paso 2: Enriquecer output/requirements-registry.md

**Nota:** Este fichero fue generado en FASE 2 por `fa-generate-requirements-index`. En FASE 3, enriquecerlo con gaps finales resueltos.

Si no existe (ej: modo `reassemble`), generarlo desde cero. Usar plantilla de `Templates/fa-output-templates.md`.

```
Por cada FA-REQ-NNN del registro maestro (de FA-SYNTHESIS-RESUMEN.md):
  - Actualizar Estado: CONFIRMADO | BLOQUEADO | EXCLUIDO
  - Actualizar Gaps Vinculados: agregar todos los FA-GAP que se resolvieron
  - Campos completos: descripción, origen, tipo, confianza, pantallas, reglas, etc.
  - Criterios de aceptación de FA-REQ-RESUMEN
  - Gaps vinculados de open-gaps.md

Frontmatter:
  - coverage = cobertura de resources/coverage-report.md
  - wf2-ready = true si cobertura ≥ threshold Y gaps bloqueantes = 0
  - status = final (tras cierre WF1)
```

### Paso 3: Generar output/FA-REQ-NNN/ (por cada requisito confirmado)

```
Para cada FA-REQ-NNN con estado CONFIRMADO o BLOQUEADO:
  Crear directorio output/FA-REQ-NNN/ con 7 ficheros:

  1. screen-inventory.md   → filtrar SCR de FA-SYNTHESIS-RESUMEN vinculadas a este FA-REQ
  2. navigation-map.md     → filtrar NAV de FA-SYNTHESIS-RESUMEN vinculados a este FA-REQ
  3. business-rules.md     → filtrar BRN de FA-SYNTHESIS-RESUMEN vinculadas a este FA-REQ
  4. data-model.md         → filtrar ENT de FA-SYNTHESIS-RESUMEN vinculadas a este FA-REQ
  5. roles-permissions.md  → filtrar ROL/permisos vinculados a este FA-REQ
  6. integrations-catalog.md → filtrar INT vinculadas a este FA-REQ
  7. gaps.md               → filtrar FA-GAP de open-gaps.md vinculados a este FA-REQ

  Frontmatter en cada fichero:
    app-id, client-id, artifact, req-id: FA-REQ-NNN, version, iteration, generated-at
```

### Paso 4: Generar artefactos globales output/ (agregación de todos FA-REQ-NNN/)

```
Agregar TODOS los FA-REQ-NNN/ en ficheros globales:

  output/screen-inventory.md     → TODAS las SCR de todos los requisitos
  output/navigation-map.md       → TODOS los NAV (con mermaid flowchart global)
  output/business-rules.md       → TODAS las BRN de todos los requisitos
  output/data-model.md           → TODAS las ENT (deduplicar si aparecen en múltiples req)
  output/roles-permissions.md    → TODOS los ROL con sus acciones consolidadas
  output/integrations-catalog.md → TODAS las INT (deduplicar si aparecen en múltiples req)

  Frontmatter global:
    artifact: screen-inventory | navigation-map | ...
    coverage: valor de coverage-report.md
    status: in-progress | final
    wf2-ready: true | false
```

### Paso 5: Actualizar operator/dashboard.html — sección Gaps por requisito

```
El dashboard ya existe (creado en Paso 1b del orquestador). En FASE 3,
enriquecerlo con los datos finales de síntesis.

Actualizar DASHBOARD_DATA con los datos de FA-SYNTHESIS-RESUMEN y open-gaps.md:
  - workflowStatus: "FASE3_DONE"
  - iterations[current].requirements: lista completa con IDs definitivos
  - iterations[current].screens: lista completa con fuentes confirmatorias
  - iterations[current].entities: lista completa de entidades
  - iterations[current].gaps: { bloqueantes, recomendados, informativos } completos
    → Para cada gap: incluir req vinculados, SCR afectadas, acción requerida,
      responsable sugerido, preguntas para el PO (usable en reuniones)
  - iterations[current].gates.coverage: resultado si se ejecutó
  - iterations[current].timeline: añadir paso "FASE 3 — Artefactos generados"
  - iterations[current].nextSteps: instrucciones actualizadas post-FASE 3

→ Sobreescribir operator/dashboard.html con los datos actualizados
```

### Paso 6: Artefactos globales operator/ — solo en cierre final

```
El dashboard (operator/dashboard.html) es el artefacto principal del operador
y se mantiene actualizado en cada fase. El único artefacto adicional en operator/
que se genera de forma separada es la traceability-matrix en el cierre.

Si status = final (cierre de WF1):
  operator/traceability-matrix.html
    → Matriz interactiva FA-REQ → SCR → BRN → ENT → ROL → INT
    → Generada SOLO en cierre final — complementa al dashboard
    → Incluir en el dashboard un enlace a este fichero

  Actualizar dashboard: workflowStatus: "CLOSED"
    → Sección Iteraciones: marcar ITER-NNN como cerrado
    → Añadir enlace a traceability-matrix.html en la sección Estado
```

### Paso 7: Actualizar iteration-tracker.md

```
Añadir o actualizar la entrada del ITER-NNN actual en resources/iteration-tracker.md:
  - pantallas-detectadas: total SCR en output/screen-inventory.md
  - cobertura-alcanzada: de coverage-report.md
  - fingerprint: del source-fingerprint.md actual
```

### Paso 8: Generar artefactos para WF4 (Pruebas Unitarias) y WF5 (Pruebas Funcionales)

```
Invocar fa-test-coverage-extractor:
  - Leer FA-SYNTHESIS-RESUMEN.md → extraer BRN, ENT, SCR, NAV por cada FA-REQ
  - Leer open-gaps.md → identificar gaps bloqueantes en test cases

  Por cada FA-REQ-NNN generar DOS ficheros separados:

  output/FA-REQ-NNN/unit-test-cases.md  → WF4 (Pruebas Unitarias)
    Contenido:
      1. Unit Tests de Reglas de Negocio (BRN-NNN vinculados)
         → Mínimo 1 happy-path + 1 por restricción violada
         → 1 caso de borde por restricción
      2. Unit Tests de Entidades (ENT-NNN vinculados)
         → Constructor, validadores, transformaciones

  output/FA-REQ-NNN/functional-test-cases.md  → WF5 (Pruebas Funcionales)
    Contenido:
      1. Criterios de Aceptación (E2E)
         → 1 caso por criterio del FA-REQ-NNN
         → Happy-path o validación según tipo de criterio
      2. Functional Tests de Pantallas (SCR-NNN vinculados)
         → Happy-path, alternativos, casos error, roles
      3. Functional Tests de Flujos de Navegación (NAV-NNN vinculados)
         → Verificación transiciones, condiciones, bloqueos

  Generar output/test-cases/unit-test-coverage-matrix.md → WF4:
    → Matriz FA-REQ → BRN/ENT → TC-UT
    → Cobertura UT: total TC, FA-REQ sin cobertura, TC bloqueados

  Generar output/test-cases/functional-test-coverage-matrix.md → WF5:
    → Matriz FA-REQ → Criterios/SCR/NAV → TC-E2E/TC-FT
    → Cobertura FT: total TC, FA-REQ sin cobertura, TC bloqueados
```

## Frontmatter Canónico

Usar en TODOS los artefactos generados en output/:

```yaml
---
app-id: {app-id de fa-config.yml}
client-id: {client-id de fa-config.yml}
artifact: {nombre del artefacto}
version: "1.0"
iteration: {iteration de fa-config.yml}
generated-at: {timestamp actual ISO 8601}
generated-by: fa-generate-output
coverage: {valor de coverage-report.md}
status: in-progress | final
wf2-ready: true | false
---
```

## Reglas de Versioning

- Primera iteración (ITER-001): `version: "1.0"`
- Cambios menores (nuevas pantallas en misma iteración): `version: "1.1"`, `"1.2"`...
- Cambio de alcance significativo: `version: "2.0"`
- Si WF2 ya empezó con una versión anterior: mostrar WARNING antes de sobrescribir

## Comportamiento según Tipo de Ejecución

```
Iteración intermedia (status = in-progress):
  → Generar: output/ (con wf2-ready: false) + test-cases/
  → Actualizar: operator/dashboard.html (sección Requisitos + Gaps + Estado)
  → NO generar: traceability-matrix.html

Cierre final (status = final, invocado por fa-closure-gate tras firma):
  → Generar: output/ (con wf2-ready: true) + test-cases/
  → Actualizar: operator/dashboard.html (workflowStatus: CLOSED)
  → Generar: operator/traceability-matrix.html
  → NO sobrescribir fa-prerequisites.md (ese lo genera fa-closure-gate)
```
