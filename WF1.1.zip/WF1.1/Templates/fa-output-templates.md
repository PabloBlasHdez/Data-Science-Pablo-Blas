# Plantillas Canónicas de Artefactos de Salida — WF1 Functional Analysis

Plantillas de todos los ficheros generados en `output/` y `operator/` por `fa-generate-output`.
Todos los artefactos incluyen frontmatter canónico con metadatos de trazabilidad.

---

## Frontmatter canónico (todos los artefactos output/)

```yaml
---
app-id: {APP_ID}
client-id: {CLIENT_ID}
artifact: {nombre-artifact}   # screen-inventory | navigation-map | business-rules | ...
version: "1.0"                # semver: 1.0 primera iteración, 1.1 cambios menores, 2.0 cambio de alcance
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
coverage: 0.87
status: in-progress | final
wf2-ready: true | false
---
```

---

## Plantilla 1 — requirements-registry.md ★ (EJE de trazabilidad)

Fichero maestro en `output/requirements-registry.md`. Toda trazabilidad parte de FA-REQ-NNN.

```markdown
---
app-id: MYAPP
client-id: acme
artifact: requirements-registry
version: "1.0"
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
coverage: 0.87
status: in-progress | final
wf2-ready: false | true
---

# Registro de Requisitos Funcionales — MYAPP

## Resumen
| Métrica                    | Valor |
|----------------------------|-------|
| Total FA-REQ               | N     |
| CONFIRMADOS                | N     |
| BLOQUEADOS (gaps abiertos) | N     |
| PENDIENTES (sin pantalla)  | N     |
| Cobertura funcional        | NN%   |

## Registro maestro

### FA-REQ-001 — Búsqueda de contratos por cliente y fecha
- **estado:** CONFIRMADO
- **tipo:** funcional
- **origen:** HU-001 (Jira MYAPP-001), BRD sección 3.1
- **tipo-req:** DIRECTO
- **confianza:** CONFIRMED
- **pantallas:** SCR-001 (Búsqueda de Contratos)
- **reglas:** BRN-001, BRN-003
- **entidades:** ENT-001 (Contrato), ENT-002 (Cliente)
- **roles:** ROL-001 (GESTOR), ROL-002 (SUPERVISOR), ROL-003 (ADMIN)
- **integraciones:** —
- **gaps-abiertos:** —
- **criterios-aceptacion:**
  - Al menos un filtro obligatorio para ejecutar búsqueda
  - Resultados en tabla paginada (20 por página)
  - Resultados disponibles en < 3 segundos

---

### FA-REQ-002 — Exportar resultados a Excel
- **estado:** CONFIRMADO
- **tipo:** funcional
- **origen:** HU-023 (Jira MYAPP-023)
- **tipo-req:** DIRECTO
- **confianza:** CONFIRMED
- **pantallas:** SCR-001 (Búsqueda de Contratos)
- **reglas:** BRN-005
- **entidades:** ENT-001 (Contrato)
- **roles:** ROL-002 (SUPERVISOR), ROL-003 (ADMIN)
- **integraciones:** —
- **gaps-abiertos:** —
- **criterios-aceptacion:**
  - Solo visible para SUPERVISOR y ADMIN
  - Exporta todos los resultados de la búsqueda actual (no solo página visible)

---

### FA-REQ-003 — Validación importe mínimo en alta de contrato
- **estado:** BLOQUEADO
- **motivo-bloqueo:** FA-GAP-001 (RULE-AMBIGUOUS — importe 100€ vs 50€)
- **tipo:** funcional
- **origen:** HU-023, BRD sección 4.2 (CONFLICTO)
- **tipo-req:** DIRECTO (conflictivo)
- **confianza:** ASSUMED
- **pantallas:** SCR-003 (Formulario Alta)
- **reglas:** BRN-002 (BLOQUEADA)
- **entidades:** ENT-001 (Contrato)
- **roles:** ROL-001 (GESTOR), ROL-003 (ADMIN)
- **gaps-abiertos:** FA-GAP-001

---

## Exclusiones confirmadas
| Funcionalidad                    | Motivo                      | Decidido por | Fecha      |
|----------------------------------|-----------------------------|--------------|------------|
| Exportación CSV                  | Fuera de alcance v1         | PO — ITER-002| 2026-05-20 |
| Gestión de permisos admin (legacy)| Código muerto — no migrar  | Operador     | 2026-05-19 |
```

---

## Plantilla 2 — screen-inventory.md

Fichero en `output/screen-inventory.md` (global) y `output/FA-REQ-NNN/screen-inventory.md` (por requisito).

```markdown
---
app-id: MYAPP
client-id: acme
artifact: screen-inventory
version: "1.0"
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
status: in-progress | final
---

# Inventario de Pantallas — MYAPP

## SCR-001 — Búsqueda de Contratos
- **descripcion:** Pantalla principal de búsqueda. Permite filtrar contratos por cliente,
  fecha de inicio/fin, estado y tipo. Devuelve resultados en tabla paginada (20/página).
- **requisitos:** FA-REQ-001, FA-REQ-002
- **roles-con-acceso:** ROL-001 (GESTOR), ROL-002 (SUPERVISOR), ROL-003 (ADMIN)
- **acciones:**
  - `buscar` — ejecuta búsqueda con filtros activos (ROL: todos)
  - `exportar-excel` — exporta resultados completos a .xlsx (ROL: SUPERVISOR, ADMIN)
  - `ver-detalle` — navega a SCR-002 al click en fila (ROL: todos)
  - `nueva-solicitud` — navega a SCR-008 (ROL: GESTOR, ADMIN)
- **elementos-ui:**
  - input:cliente (obligatorio, autocompletar)
  - input:fecha-inicio (opcional, date-picker)
  - input:fecha-fin (opcional, date-picker)
  - select:estado (opcional, multiselect)
  - select:tipo (opcional, multiselect)
  - btn:buscar
  - btn:exportar-excel
  - tabla:resultados (columnas: id, cliente, fecha-inicio, estado, tipo, importe)
  - paginacion (20 por página)
- **entidades:** ENT-001 (Contrato), ENT-002 (Cliente)
- **reglas:** BRN-001, BRN-003, BRN-007
- **pantallas-origen:** SCR-000 (Login)
- **pantallas-destino:** SCR-002 (Detalle Contrato), SCR-008 (Nueva Solicitud)
- **fuentes:** HU-001 (Jira), figma-v2 frame 3, BRD sección 3.1, código busqueda.jsp
- **confianza:** CONFIRMED (3 fuentes confirmatorias)

---

## SCR-002 — Detalle de Contrato
- **descripcion:** Vista completa del contrato seleccionado. Muestra todos los campos del
  contrato con pestañas: Datos Generales, Documentos adjuntos, Histórico de cambios.
- **requisitos:** FA-REQ-001
- **roles-con-acceso:** ROL-001 (GESTOR), ROL-002 (SUPERVISOR), ROL-003 (ADMIN)
- **acciones:**
  - `editar` — habilita edición de campos (ROL: GESTOR, ADMIN)
  - `anular` — anula el contrato (ROL: ADMIN)
  - `volver` — navega de vuelta a SCR-001
- **elementos-ui:**
  - panel:datos-generales (todos los campos de ENT-001)
  - tabs: [datos-generales, documentos, historico]
  - btn:editar (visible solo ROL: GESTOR, ADMIN)
  - btn:anular (visible solo ROL: ADMIN)
  - btn:volver
- **entidades:** ENT-001 (Contrato), ENT-002 (Cliente)
- **reglas:** BRN-008, BRN-009
- **pantallas-origen:** SCR-001
- **pantallas-destino:** SCR-001 (volver)
- **fuentes:** Manual usuario sección 4, código detalle.jsp
- **confianza:** CONFIRMED (2 fuentes confirmatorias)
```

---

## Plantilla 3 — navigation-map.md

```markdown
---
app-id: MYAPP
client-id: acme
artifact: navigation-map
version: "1.0"
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
status: in-progress | final
---

# Mapa de Navegación — MYAPP

## Diagrama de flujo (Mermaid)
```mermaid
flowchart TD
    SCR000[SCR-000: Login] -->|autenticación OK| SCR001[SCR-001: Búsqueda Contratos]
    SCR001 -->|click fila| SCR002[SCR-002: Detalle Contrato]
    SCR001 -->|nueva solicitud - GESTOR+| SCR008[SCR-008: Nueva Solicitud]
    SCR002 -->|volver| SCR001
    SCR008 -->|guardar| SCR001
    SCR008 -->|cancelar| SCR001
```

## Transiciones de navegación

### NAV-001
- **origen:** SCR-001 (Búsqueda de Contratos)
- **destino:** SCR-002 (Detalle de Contrato)
- **condicion:** Click en fila de la tabla de resultados
- **roles:** ROL-001, ROL-002, ROL-003
- **requisitos:** FA-REQ-001
- **fuentes:** Figma-v2 frame 3, BRD sección 3.1

### NAV-002
- **origen:** SCR-001 (Búsqueda de Contratos)
- **destino:** SCR-008 (Nueva Solicitud)
- **condicion:** Click en botón "Nueva solicitud"
- **roles:** ROL-001 (GESTOR), ROL-003 (ADMIN)
- **requisitos:** FA-REQ-004
- **fuentes:** HU-015

### NAV-003
- **origen:** SCR-002 (Detalle de Contrato)
- **destino:** SCR-001 (Búsqueda de Contratos)
- **condicion:** Click en botón "Volver" o tras guardar cambios
- **roles:** ROL-001, ROL-002, ROL-003
- **requisitos:** FA-REQ-001
- **fuentes:** Manual usuario, código
```

---

## Plantilla 4 — business-rules.md

```markdown
---
app-id: MYAPP
client-id: acme
artifact: business-rules
version: "1.0"
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
status: in-progress | final
---

# Catálogo de Reglas de Negocio — MYAPP

## BRN-001 — Filtro de búsqueda obligatorio
- **pantalla:** SCR-001 (Búsqueda de Contratos)
- **requisito:** FA-REQ-001
- **descripcion:** Al menos un criterio de búsqueda debe estar informado.
  Si todos los campos están vacíos al pulsar "Buscar", mostrar mensaje de error.
- **mensaje-error:** "Debe indicar al menos un criterio de búsqueda"
- **tipo:** Validación de entrada
- **fuentes:** HU-001 criterio 1, BRD sección 3.1
- **confianza:** CONFIRMED
- **estado:** CONFIRMADA

## BRN-002 — Importe mínimo en alta de contrato [BLOQUEADA]
- **pantalla:** SCR-003 (Formulario Alta)
- **requisito:** FA-REQ-003
- **descripcion:** El importe del contrato debe ser mayor o igual a un mínimo.
  **Valor en disputa:** HU-023 indica 100€, BRD sección 4.2 indica 50€.
- **tipo:** Validación de negocio
- **fuentes:** HU-023 (Jira), BRD sección 4.2 — CONTRADICTORIAS
- **confianza:** ASSUMED
- **estado:** BLOQUEADA → FA-GAP-001
- **impacto-wf2:** WF2 no puede implementar validación hasta resolución

## BRN-003 — Paginación de resultados
- **pantalla:** SCR-001 (Búsqueda de Contratos)
- **requisito:** FA-REQ-001
- **descripcion:** Los resultados de búsqueda se muestran de 20 en 20.
  La paginación es obligatoria cuando hay más de 20 resultados.
- **tipo:** Comportamiento de visualización
- **fuentes:** HU-001 criterio 3, BRD sección 3.2, código BusquedaController.java
- **confianza:** CONFIRMED
- **estado:** CONFIRMADA
```

---

## Plantilla 5 — data-model.md

```markdown
---
app-id: MYAPP
client-id: acme
artifact: data-model
version: "1.0"
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
status: in-progress | final
---

# Modelo de Datos Funcional — MYAPP

> Nota: Este es el modelo funcional (qué datos maneja la aplicación).
> El modelo físico de BD se define en WF2 (Análisis Técnico).

## ENT-001 — Contrato
- **requisitos:** FA-REQ-001, FA-REQ-002, FA-REQ-003
- **descripcion:** Contrato mercantil entre la empresa y un cliente.
- **campos:**

| Campo          | Tipo funcional  | Obligatorio | Descripción                          | Validaciones conocidas         |
|----------------|-----------------|-------------|--------------------------------------|--------------------------------|
| id             | Identificador   | Sí (auto)   | Identificador único del contrato     | Formato CTR-YYYY-NNNNN (cliente acme) |
| clienteId      | Referencia      | Sí          | Cliente titular del contrato         | FK a ENT-002                   |
| fechaInicio    | Fecha           | Sí          | Fecha de inicio de vigencia          | Formato dd/MM/yyyy             |
| fechaFin       | Fecha           | No          | Fecha de fin de vigencia             | > fechaInicio si informada     |
| estado         | Enumerado       | Sí          | Estado actual: BORRADOR/ACTIVO/ANULADO | Solo ADMIN puede anular       |
| tipo           | Enumerado       | Sí          | Tipo de contrato (catálogo externo)  | —                              |
| importe        | Monetario       | Sí          | Importe del contrato en EUR          | Mínimo en disputa (FA-GAP-001) |

- **relaciones:**
  - ENT-001 (Contrato) → ENT-002 (Cliente): N:1 (un contrato tiene un cliente)
- **fuentes:** BRD sección 2.1, Contrato.java, T_CONTRATOS schema
- **confianza:** CONFIRMED

## ENT-002 — Cliente
- **requisitos:** FA-REQ-001
- **descripcion:** Persona física o jurídica titular de contratos.
- **campos:**

| Campo     | Tipo funcional | Obligatorio | Descripción                 | Validaciones conocidas |
|-----------|----------------|-------------|-----------------------------|------------------------|
| id        | Identificador  | Sí (auto)   | Identificador único cliente | —                      |
| nombre    | Texto          | Sí          | Nombre completo o razón social | Max 200 chars        |
| nif       | Texto          | Sí          | NIF/CIF                     | Enmascarar en artefactos (privacidad) |
| email     | Email          | No          | Email de contacto           | Formato válido         |
| segmento  | Enumerado      | Sí          | Segmento: PYME/EMPRESA/CORP | —                      |

- **fuentes:** BRD sección 2.2, Cliente.java
- **confianza:** CONFIRMED
```

---

## Plantilla 6 — roles-permissions.md

```markdown
---
app-id: MYAPP
client-id: acme
artifact: roles-permissions
version: "1.0"
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
status: in-progress | final
---

# Roles y Permisos — MYAPP

## ROL-001 — GESTOR
- **alias-cliente:** "Agente" (según acme-fa-rules)
- **descripcion:** Gestor de cartera de contratos. Acceso operativo.
- **pantallas-con-acceso:** SCR-001, SCR-002, SCR-003
- **acciones-permitidas:**
  - SCR-001: buscar, ver-detalle, nueva-solicitud
  - SCR-002: ver, editar (campos no restringidos)
  - SCR-003: crear alta
- **acciones-denegadas:**
  - SCR-001: exportar-excel
  - SCR-002: anular
- **requisitos-vinculados:** FA-REQ-001, FA-REQ-003, FA-REQ-004
- **fuentes:** BRD sección 5, Figma (btn visibilidad), HU-001
- **confianza:** CONFIRMED

## ROL-002 — SUPERVISOR
- **alias-cliente:** "Coordinador"
- **descripcion:** Supervisión de cartera. Sin acceso a alta/modificación.
- **pantallas-con-acceso:** SCR-001, SCR-002
- **acciones-permitidas:**
  - SCR-001: buscar, ver-detalle, exportar-excel
  - SCR-002: ver
- **acciones-denegadas:**
  - SCR-001: nueva-solicitud
  - SCR-002: editar, anular
- **requisitos-vinculados:** FA-REQ-001, FA-REQ-002
- **fuentes:** BRD sección 5
- **confianza:** CONFIRMED

## ROL-003 — ADMIN
- **descripcion:** Administrador del sistema. Acceso total.
- **pantallas-con-acceso:** todas
- **acciones-permitidas:** todas
- **requisitos-vinculados:** todos
- **fuentes:** BRD sección 5
- **confianza:** CONFIRMED
```

---

## Plantilla 7 — integrations-catalog.md

```markdown
---
app-id: MYAPP
client-id: acme
artifact: integrations-catalog
version: "1.0"
iteration: ITER-NNN
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
status: in-progress | final
---

# Catálogo de Integraciones — MYAPP

## INT-001 — SAP Facturación
- **tipo:** Consulta (solo lectura)
- **requisitos:** FA-REQ-005
- **descripcion:** Consulta de datos de facturación del contrato desde SAP.
  Mostrado en SCR-002 (Detalle) en la pestaña "Datos Financieros".
- **protocolo-esperado:** Desconocido — FA-GAP-003 (INTEGRATION-UNKNOWN)
- **datos-intercambiados:** id-contrato → {importe-facturado, pendiente, vencimientos}
- **pantallas-afectadas:** SCR-002
- **dependencia-wf2:** WF2 necesita contrato API para definir endpoint/servicio
- **fuentes:** SapFacService.java (deducido de código), BRD sección 7 (mencionado sin detalle)
- **confianza:** ASSUMED → FA-GAP-003
- **estado:** PENDIENTE — falta definición del contrato API
```

---

## Plantilla 8 — gaps.md (por requisito en output/FA-REQ-NNN/)

```markdown
---
app-id: MYAPP
client-id: acme
artifact: gaps
req-id: FA-REQ-003
version: "1.0"
iteration: ITER-NNN
---

# Gaps de FA-REQ-003 — Validación importe mínimo

## FA-GAP-001
- **tipo:** RULE-AMBIGUOUS
- **severidad:** BLOQUEANTE
- **iteracion-detectada:** ITER-001
- **pantalla:** SCR-003 (Formulario de Alta)
- **req-vinculados:** [FA-REQ-003]
- **descripcion:** >
    HU-023 dice "importe mínimo 100€", BRD sección 4.2 dice "importe mínimo 50€".
    Contradicción entre Historia de Usuario y documento de requisitos.
- **impacto:** WF2 no puede definir la validación BRN-002 sin esta aclaración.
- **accion-requerida:** "Consultar con PO — ¿qué valor es correcto? Actualizar HU-023 o BRD."
- **responsable-sugerido:** Product Owner
- **estado:** ABIERTO
- **iteracion-resuelta:** —
```

---

## Plantilla 9 — fa-prerequisites.md (pase a WF2)

```markdown
---
app-id: MYAPP
client-id: acme
artifact: fa-prerequisites
fa-coverage: 0.87
wf2-ready: true
iteration-closure: ITER-003
generated-by: fa-closure-gate
signed-by: [nombre y rol del operador]
signed-at: YYYY-MM-DDTHH:MM:SSZ
---

# Prerrequisitos WF1 → WF2 — MYAPP

## Alcance confirmado
- **FA-REQ confirmados:** 12 requisitos (ver requirements-registry.md)
- **SCR inventariadas:** 21 pantallas (sin ninguna sin descripción funcional)
- **Cobertura funcional:** 87% (≥ 80% requerido)
- **Iteraciones realizadas:** 3 (ITER-001, ITER-002, ITER-003)

## 🚫 Exclusiones confirmadas (NO se implementan en esta entrega)
| Funcionalidad                 | Motivo                        | Decidido por | Fecha      |
|-------------------------------|-------------------------------|--------------|------------|
| Exportación CSV               | Fuera de alcance v1           | PO — ITER-003| 2026-05-20 |
| Gestión de permisos admin (legacy) | Código muerto — no migrar | Operador    | 2026-05-19 |

## ❌ Bloqueantes para WF2
> Si esta sección tiene ítems con estado ABIERTO, WF2 NO puede iniciar.

Ninguno. Todos los gaps BLOQUEANTES resueltos en ITER-003.

## ⚠️ Vacíos aceptados (no bloquean WF2)
| Gap ID      | Descripción                           | Impacto técnico                        | Cómo gestionar en WF2                    |
|-------------|---------------------------------------|----------------------------------------|------------------------------------------|
| FA-GAP-003  | API SAP Facturación sin contrato       | INT-001 sin spec de endpoint           | Crear mock/stub; resolver con arquitecto |
| FA-GAP-008  | NFR de rendimiento sin SLA específico  | WF2 decide límites razonables          | Marcar como TODO con arquitecto          |
| FA-GAP-009  | NFR accesibilidad sin nivel confirmado | WF2 asume WCAG 2.1 AA por defecto      | Confirmar con cliente antes de F4         |

## ✅ Checklist de condiciones de entrada para WF2
- [x] requirements-registry.md: 12 FA-REQ, todos con estado CONFIRMADO o exclusión justificada
- [x] screen-inventory.md: 21 pantallas, ninguna sin descripción funcional completa
- [x] navigation-map.md: 0 transiciones sin condición definida
- [x] business-rules.md: 0 reglas en estado BLOQUEADA
- [x] data-model.md: 0 entidades sin campos definidos
- [x] roles-permissions.md: 0 acciones sin rol asignado
- [x] Cobertura funcional: 87% >= 80%
- [x] FA-GAPS BLOQUEANTES abiertos: 0
- [x] Closure decision firmada por operador

## Firma del operador
- **Operador:** [nombre y rol]
- **Fecha:** YYYY-MM-DDTHH:MM:SSZ
- **Declaración:** "El análisis funcional de MYAPP está suficientemente completo para
  iniciar el Análisis Técnico. Los vacíos aceptados están documentados y su gestión
  en WF2 está definida."
```

---

## Plantilla 10 — open-questions-ITER-NNN.html (para reuniones con PO)

```html
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Dudas y Vacíos Funcionales — {APP_ID} — {ITER_ID}</title>
<style>
  body { font-family: Arial, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; }
  .blocking { background: #fee2e2; border-left: 4px solid #dc2626; padding: 12px; margin: 10px 0; border-radius: 4px; }
  .recommended { background: #fef3c7; border-left: 4px solid #d97706; padding: 12px; margin: 10px 0; border-radius: 4px; }
  .informative { background: #dbeafe; border-left: 4px solid #2563eb; padding: 12px; margin: 10px 0; border-radius: 4px; }
  .gap-id { font-weight: bold; font-family: monospace; }
  .action { background: #f0fdf4; padding: 8px; border-radius: 4px; margin-top: 8px; }
  h1 { border-bottom: 2px solid #374151; }
  h2 { color: #374151; }
  .meta { color: #6b7280; font-size: 0.9em; }
</style>
</head>
<body>

<h1>Dudas y Vacíos Funcionales — {APP_ID} — {ITER_ID}</h1>
<p class="meta">Para resolver antes de {NEXT_ITER_ID} · Generado: {TIMESTAMP}</p>
<p class="meta">Responsable de seguimiento: Operador · Destino: Product Owner / Arquitecto</p>

<h2>❌ CRÍTICO — Bloquean el análisis técnico ({N} ítems)</h2>
<p>Estos vacíos impiden el inicio de WF2. Deben resolverse antes de la próxima iteración.</p>

<div class="blocking">
  <p><span class="gap-id">[FA-GAP-001]</span> ¿Cuál es el importe mínimo en el alta de contrato: 100€ o 50€?</p>
  <p><strong>Pantalla:</strong> SCR-003 (Formulario Alta) · <strong>Requisito:</strong> FA-REQ-003</p>
  <p><strong>Contexto:</strong> HU-023 dice "mínimo 100€", BRD sección 4.2 dice "mínimo 50€". Hay contradicción.</p>
  <p><strong>Fuentes en conflicto:</strong> HU-023 (Jira) vs BRD-v1 sección 4.2</p>
  <p><strong>Responsable sugerido:</strong> Product Owner</p>
  <div class="action"><strong>Acción requerida:</strong> Confirmar valor correcto y actualizar HU-023 o BRD sección 4.2 en input/docs/</div>
</div>

<div class="blocking">
  <p><span class="gap-id">[FA-GAP-002]</span> ¿Cómo funciona el flujo de confirmación en el alta de contrato?</p>
  <p><strong>Pantalla:</strong> SCR-006 (Confirmación Alta) — sin descripción funcional</p>
  <p><strong>Requisito:</strong> FA-REQ-006</p>
  <p><strong>Contexto:</strong> SCR-003 navega a SCR-006 según Figma pero SCR-006 no tiene especificación.</p>
  <div class="action"><strong>Acción requerida:</strong> Proporcionar especificación de SCR-006 o wireframe en input/screens/</div>
</div>

<h2>⚠️ RECOMENDADO — Podrían causar decisiones incorrectas en WF2 ({N} ítems)</h2>

<div class="recommended">
  <p><span class="gap-id">[FA-GAP-003]</span> ¿Cuál es el contrato de la API de SAP Facturación?</p>
  <p><strong>Integración:</strong> INT-001 (SAP) · <strong>Requisito:</strong> FA-REQ-005</p>
  <p><strong>Contexto:</strong> Se detecta llamada a SAP en el código pero no hay especificación del API.</p>
  <div class="action"><strong>Acción requerida:</strong> Proporcionar especificación OpenAPI o documentación de SAP en input/specs/</div>
</div>

<h2>ℹ️ INFORMATIVO — Detalle útil no crítico ({N} ítems)</h2>

<div class="informative">
  <p><span class="gap-id">[FA-GAP-006]</span> ¿Debe migrarse la funcionalidad de exportación PDF detectada en el código?</p>
  <p><strong>Contexto:</strong> ExportPDFController existe en código fuente pero no está documentada en ninguna HU o BRD.</p>
  <div class="action"><strong>Acción requerida (opcional):</strong> Operador decide si incluir en alcance o excluir con justificación.</div>
</div>

<h2>Cómo proporcionar respuestas</h2>
<ol>
  <li>Actualizar o añadir ficheros en <code>input/docs/</code>, <code>input/screens/</code> o <code>input/specs/</code></li>
  <li>Ejecutar: <code>/fa-run-workflow ./source-app "" {APP_ID} {CLIENT_ID} continue-iteration</code></li>
  <li>El workflow procesará las nuevas fuentes y actualizará los gaps resueltos</li>
</ol>

</body>
</html>
```

---

## Plantilla 11 — iteration-report-ITER-NNN.md

```markdown
---
app-id: MYAPP
client-id: acme
artifact: iteration-report
iteration: ITER-002
generated-at: YYYY-MM-DDTHH:MM:SSZ
generated-by: fa-generate-output
---

# Informe de Iteración ITER-002 — MYAPP

## Progreso
| Métrica                    | ITER-001 | ITER-002 | Δ    |
|----------------------------|----------|----------|------|
| Cobertura funcional        | 58%      | 72%      | +14% |
| FA-REQ confirmados         | 7        | 10       | +3   |
| Pantallas inventariadas    | 12       | 17       | +5   |
| Gaps BLOQUEANTES abiertos  | 5        | 2        | -3   |
| Gaps RECOMENDADO abiertos  | 4        | 3        | -1   |

## Fuentes nuevas procesadas en ITER-002
- `input/docs/reunion-po-2026-05-19.txt` → resolvió FA-GAP-001, FA-GAP-002
- `input/screens/figma-v2-export.pdf` → añadió SCR-015, SCR-016, SCR-017 (+3 pantallas)
- `input/specs/sap-api-v1.yaml` → resolvió FA-GAP-003 (INT-001 documentada)

## Qué se resolvió en ITER-002
- **FA-GAP-001** (RULE-AMBIGUOUS): Importe mínimo confirmado en 100€ por PO (acta reunión)
- **FA-GAP-002** (SCREEN-MISSING): SCR-006 Confirmación Alta especificada con wireframe Figma v2
- **FA-GAP-003** (INTEGRATION-UNKNOWN): API SAP Facturación documentada en sap-api-v1.yaml
- **FA-GAP-005** (REQ-ORPHAN): Frame Admin-Config confirmado como exclusión (no migrar)

## Qué sigue pendiente
- **FA-GAP-007** (FLOW-INCOMPLETE, BLOQUEANTE): Flujo de aprobación SCR-016 sin condiciones de transición
- **FA-GAP-008** (NFR-MISSING, RECOMENDADO): Sin SLA de rendimiento específico

## Próximos pasos recomendados
1. **PO debe confirmar** el flujo completo SCR-016 → SCR-017 → SCR-018 (FA-GAP-007 — BLOQUEANTE)
2. **Arquitecto debe confirmar** niveles de accesibilidad requeridos (FA-GAP-009)
3. Ejecutar ITER-003 tras resolver FA-GAP-007
```

---

## Plantilla 12 — iteration-tracker.md (resources/)

```yaml
---
app-id: MYAPP
client-id: acme
total-iterations: 2
last-iteration: ITER-002
status: in-progress   # in-progress | closed
coverage-last: 0.72
gaps-bloqueantes-abiertos: 2
---

## ITER-001
- fecha-inicio: 2026-05-18T10:00:00Z
- fuentes-analizadas: [BRD-v1.pdf, export-jira-20260518.json, screens/ (14 imgs)]
- pantallas-detectadas: 12
- gaps-detectados: 9 (BLOQUEANTE:5, RECOMENDADO:3, INFORMATIVO:1)
- cobertura-alcanzada: 0.58
- accion-operador: "Solicitado Figma v2 y acta reunión PO 2026-05-19"
- fingerprint: sha256:a3f9b2c1d4e5f6a7b8c9d0e1f2a3b4c5

## ITER-002
- fecha-inicio: 2026-05-19T15:00:00Z
- fuentes-nuevas: [figma-v2-export.pdf, reunion-po-2026-05-19.txt, sap-api-v1.yaml]
- pantallas-detectadas: 17 (+5: SCR-015, SCR-016, SCR-017, SCR-018, SCR-019)
- gaps-detectados: 5 (BLOQUEANTE:2, RECOMENDADO:2, INFORMATIVO:1)
- gaps-resueltos: [FA-GAP-001, FA-GAP-002, FA-GAP-003, FA-GAP-005]
- cobertura-alcanzada: 0.72
- accion-operador: "Pendiente confirmar flujo aprobación SCR-016 (FA-GAP-007)"
- fingerprint: sha256:b7e3c9a2f1d4e5a6b7c8d9e0f1a2b3c4
```

---

## Plantilla 13 — closure-decision.md (resources/)

```markdown
---
app-id: MYAPP
client-id: acme
artifact: closure-decision
iteration-closure: ITER-003
generated-by: fa-closure-gate
---

# Decisión de Cierre WF1 — MYAPP

## Checklist obligatorio (verificado automáticamente por fa-closure-gate)
- [x] FA-GAPS BLOQUEANTES abiertos: 0
- [x] Cobertura funcional: 87% >= 80% (umbral configurado)
- [x] requirements-registry.md generado y revisado por operador
- [x] screen-inventory.md: 21 pantallas, ninguna sin descripción funcional
- [x] navigation-map.md: 0 transiciones sin condición definida
- [x] business-rules.md: 0 reglas en estado BLOQUEADA
- [x] traceability-matrix.md generada sin huérfanos (0 FA-REQ sin SCR, 0 SCR sin FA-REQ)

## Vacíos menores aceptados (no bloquean WF2)
| Gap ID      | Tipo           | Justificación aceptada                              |
|-------------|----------------|-----------------------------------------------------|
| FA-GAP-008  | NFR-MISSING    | WF2 decide límites razonables con arquitecto        |
| FA-GAP-009  | NFR-MISSING    | WCAG 2.1 AA asumido por defecto; confirmar en F4    |

## Firma del operador (manual)
- [x] Operador ha revisado todos los artefactos de output/

- **Operador:** [Nombre y Rol]
- **Fecha:** YYYY-MM-DDTHH:MM:SSZ
- **Declaración:** "El análisis funcional de MYAPP está suficientemente completo
  para iniciar el Análisis Técnico (WF2). Los 12 requisitos funcionales están
  confirmados, la cobertura alcanza el 87%, y los vacíos aceptados tienen
  plan de gestión documentado."
```
