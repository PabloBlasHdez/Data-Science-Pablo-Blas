---
name: jira-extractor
description: >
  Mapeo detallado de campos Jira a FA-REQ-NNN. Cubre exports JSON de Jira Cloud
  y Jira Server. Activo cuando input/remote/jira.yml tiene enabled: true.
---

# jira-extractor — Extracción de Tickets Jira

> **Scope:** Extracción de tickets Jira a requisitos funcionales FA-REQ
> **Cubre:** mapeo-campos-jira, filtrado-tickets, epics-stories-bugs, criterios-aceptacion
> **No cubre:** Jira Automation, Jira Workflows — solo extracción de contenido de tickets

## Activación

Se activa cuando `sources.remote.enabled = true` y existe `input/remote/jira.yml`.
Usa MCP nativo (`mcp-server: jira-mcp`) si disponible, o procesa el export JSON local.

## Resolución de credenciales (`auth`)

El extractor lee el bloque `auth:` del `.yml` y resuelve cada referencia
`${VAR}` leyendo el entorno del proceso EN MEMORIA. El valor resuelto NUNCA
se escribe en logs, RESUMENes ni artefactos generados.

| `auth.scheme` | Cabecera HTTP construida                                                  |
|---------------|---------------------------------------------------------------------------|
| `token`       | `Authorization: Bearer ${token}` (o cabecera específica de la herramienta: `X-Figma-Token: ${token}` para Figma) |
| `basic`       | `Authorization: Basic base64(${user}:${password})` — la concatenación se hace en memoria, nunca se persiste |
| `oauth`       | Intercambio previo client_credentials → obtener `access_token` → `Authorization: Bearer <access_token>`. El `access_token` también es memoria volátil. |

### Compatibilidad legacy

Si el `.yml` declara `api-token: ${VAR}` al nivel raíz (sin bloque `auth`),
normalizar internamente a `{ scheme: token, token: ${VAR} }` antes de
procesar.

### Validaciones obligatorias antes de cualquier petición

```
1. Resolver cada ${VAR} contra el entorno. Si alguna no está definida
   → emitir FA-GAP REMOTE-CREDENTIAL-MISSING (BLOQUEANTE) y abortar
     esta fuente.
2. Verificar que ningún campo de auth.* contiene un literal (debe ser
   exactamente el patrón ${...}). Si lo contiene
   → emitir FA-GAP REMOTE-CREDENTIAL-LITERAL (BLOQUEANTE) y abortar.
3. Enmascaramiento en logs: cualquier traza que mencione la credencial
   debe mostrar ${VAR_NAME}=*** (nunca el valor resuelto).
```

## Alcance del análisis (`scope`)

El fichero `input/remote/jira.yml` declara obligatoriamente la sección `scope`,
definida en el sub-diálogo interactivo de `fa-source-scanner` cuando el operador
configura Jira por primera vez. Esta sección acota qué tickets entran al análisis
y debe respetarse en TODAS las consultas que haga este extractor.

```yaml
scope:
  kind: epic | story
  keys:
    - MYAPP-EP-001
    - MYAPP-EP-002
```

| `scope.kind` | Comportamiento del extractor                                                                                              |
|--------------|---------------------------------------------------------------------------------------------------------------------------|
| `epic`       | Por cada clave en `keys`, resolver todas las HDU vinculadas (`parent.key = {epic}` o `"Epic Link" = {epic}`) y procesarlas. Las épicas en sí NO generan FA-REQ (ver "Mapeo de Tipos de Issue"). |
| `story`      | Procesar únicamente los issues cuya `key` esté en `keys`. Ignorar el resto del proyecto incluso si hay más Stories disponibles. |

### Construcción del filtro JQL / MCP

- `kind: epic` →
  - MCP/JQL: `project = {project} AND ("Epic Link" in ({keys}) OR parent in ({keys}))`
  - Export JSON local: filtrar `issues[]` donde `fields.parent.key ∈ keys` o el
    custom field de "Epic Link" coincida con alguna clave.
- `kind: story` →
  - MCP/JQL: `project = {project} AND key in ({keys})`
  - Export JSON local: filtrar `issues[]` donde `key ∈ keys`.

### Validaciones previas a la extracción

```
1. scope.kind debe ser "epic" o "story". Otro valor → emitir FA-GAP
   REMOTE-SCOPE-MISSING (BLOQUEANTE) y abortar Jira en esta iteración.
2. scope.keys debe ser un array no vacío. Vacío o ausente → REMOTE-SCOPE-MISSING.
3. Cada clave debe cumplir ^[A-Z][A-Z0-9]*-[A-Z0-9-]+$ y empezar por el prefijo
   declarado en `project`. Si alguna clave no encaja con el prefijo del proyecto,
   emitir advertencia (no bloquea) y procesarla igualmente — puede tratarse de
   una HDU/épica de un proyecto vinculado.
4. Si tras aplicar el filtro NO se obtiene ningún ticket → emitir FA-GAP
   REMOTE-SCOPE-EMPTY (RECOMENDADO) con la lista de claves no encontradas.
```

## Estructura del Export Jira (JSON)

```json
{
  "issues": [
    {
      "key": "MYAPP-001",
      "fields": {
        "summary": "Búsqueda de contratos por cliente",
        "issuetype": { "name": "Story" },
        "status": { "name": "Done" },
        "priority": { "name": "High" },
        "description": "Como gestor quiero buscar contratos...",
        "customfield_10016": "5",
        "customfield_10014": "Como gestor...\n*Criterios de aceptación:*\n...",
        "labels": ["v1", "modulo-contratos"],
        "components": [{ "name": "Búsqueda" }],
        "parent": { "key": "MYAPP-EP-001", "fields": { "summary": "Módulo Contratos" } }
      }
    }
  ]
}
```

## Mapeo de Campos

| Campo Jira (JSON path)          | Campo FA-REQ              | Transformación                               |
|---------------------------------|---------------------------|----------------------------------------------|
| `fields.summary`                | descripcion               | Normalizar idioma si primary-language ≠ idioma del campo |
| `fields.issuetype.name`         | tipo / tipo-req           | Ver tabla de tipos abajo                     |
| `fields.description`            | criterios-aceptacion      | Parsear formato "Como X quiero Y para Z"     |
| `fields.customfield_* (acceptance criteria)` | criterios-aceptacion | Añadir a los anteriores        |
| `fields.priority.name`          | prioridad-origen          | Blocker→Crítica, Critical→Alta, Major→Media  |
| `fields.status.name`            | estado-origen             | Mapeo directo                                |
| `fields.labels`                 | notas de alcance          | Aplicar reglas de {client}-fa-rules          |
| `fields.components[].name`      | area-funcional            | Contexto para agrupar FA-REQ por módulo      |
| `key`                           | origen                    | "HU-NNN (Jira MYAPP-NNN)"                   |

## Mapeo de Tipos de Issue

| issuetype.name    | tipo FA-REQ    | tipo-req  | Tratamiento especial                     |
|-------------------|----------------|-----------|------------------------------------------|
| `Story`           | funcional      | DIRECTO   | Crear FA-REQ con criterios de aceptación |
| `Bug`             | incidencia     | DIRECTO   | Solo si project.type = incident          |
| `Epic`            | —              | —         | NO crear FA-REQ — agrupar sus Stories    |
| `Task`            | funcional      | DIRECTO   | Si tiene criterios de aceptación         |
| `Sub-task`        | —              | —         | Vincular al FA-REQ de la Story padre     |
| `Improvement`     | funcional      | DIRECTO   | Tratar como Story                        |

## Filtrado de Tickets

**Incluir:**
- `status.name ∈ {To Do, In Progress, Done}` Y `resolution ∈ {null, Done, Fixed}`

**Excluir con justificación registrada:**
- `status.name = "Won't Fix"` → anotar exclusión en requirements-registry
- `resolution = "Won't Fix"` → ídem
- Labels que el {client}-fa-rules marque como "excluir" (ej: "fase-2", "parked")
- Epics → no crear FA-REQ (solo usar para agrupar)

## Extracción de Criterios de Aceptación

### Formato 1 — Historia de Usuario Clásica
```
Como {rol} quiero {acción} para {objetivo}.

Criterios de aceptación:
- Dado {precondición}, cuando {acción}, entonces {resultado}
- ...
```
→ Extraer los "Dado/Cuando/Entonces" como criterios individuales.

### Formato 2 — Lista en el campo Description
```
**Acceptance Criteria:**
1. El usuario puede filtrar por cliente
2. Si no hay resultados, se muestra mensaje
```
→ Extraer cada ítem como criterio individual.

### Formato 3 — Campo customfield separado
Algunos Jira usan `customfield_10016` u otros para acceptance criteria.
→ Intentar los campos custom más comunes; si no se encuentra, usar `description`.

## Uso con MCP Nativo (Jira MCP)

Si `mcp-server: jira-mcp` está disponible:
```
Consultas típicas con MCP Jira (ya filtradas por scope):
- scope.kind = epic:
    project = {project-key}
    AND ("Epic Link" in ({scope.keys}) OR parent in ({scope.keys}))
    ORDER BY created ASC
- scope.kind = story:
    project = {project-key}
    AND key in ({scope.keys})
    ORDER BY created ASC

Filtros adicionales (compatibles con cualquiera de los anteriores):
- Excluir bajadas: AND status != "Won't Fix"
- Por sprint:      AND sprint in openSprints()
```

El MCP permite consultas en tiempo real sin necesidad de export descargado.
Nunca usar JQL sin la cláusula derivada de `scope` — el alcance del análisis
está definido por configuración, no por todo el proyecto.
