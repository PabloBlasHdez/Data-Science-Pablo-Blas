---
name: ft-backend-runner
description: >
  Skill 3B — Ejecuta tests de API/back generados por la skill 2A (ft-backend-test-generator).
  Lanza la colección Newman/Postman (.json) contra el microservicio, monitoriza la ejecución
  y muestra los resultados. Usa este skill cuando el usuario diga "ejecuta los tests de API",
  "lanza Newman", "pasa los tests del back", "ejecuta la colección Postman", o cualquier
  variante de ejecución de tests de API REST.
  Para tests de front/E2E usa la skill 3A `ft-frontend-runner`.
metadata:
  author: "GitHub Copilot"
  version: "1.0"
  category: "testing"
---

# FT Backend Runner — Skill 3B (API Back)

Skill para ejecutar tests de API REST usando **Newman** (CLI de Postman),
monitorizar la ejecución y mostrar los resultados. Ejecuta la colección `.json`
y el entorno `.json` generados por la skill 2A (`ft-backend-test-generator`).

> **Para tests de front (Cilantrum)** usa la skill 3A `ft-frontend-runner`.

---

## Cuándo usar este skill

- El usuario quiere ejecutar los tests de **API/back** generados por la skill 2A
- El usuario pide "ejecuta Newman", "pasa los tests del back", "lanza la colección Postman", "ejecuta los tests de API"
- El usuario quiere verificar que los endpoints del microservicio responden correctamente
- El usuario quiere ver los resultados de una ejecución Newman

**No uses este skill** si:
- El usuario quiere ejecutar tests de **front/E2E** (usa skill 3A `ft-frontend-runner`)
- El usuario quiere **generar** la colección Newman (usa skill 2A `ft-backend-test-generator`)

---

## Inputs requeridos

| Input | Descripción | Ejemplo |
|---|---|---|
| **Colección `.json`** | Ruta a la colección Newman/Postman generada por skill 2A | `[repo-destino]/api-tests/mi-api-collection.json` |
| **Entorno `.json`** | Ruta al archivo de entorno con variables (baseUrl, token, etc.) | `[repo-destino]/api-tests/PRE.environment.json` |

Si falta algún input, **pídelo explícitamente**:

```
Para ejecutar los tests de API necesito:
1. Ruta a la colección Newman (.json)
2. Ruta al archivo de entorno (.json) — ej: PRE.environment.json

¿Cuáles son las rutas?
```

Si el usuario solo proporciona el repo destino, busca los archivos automáticamente:

```
file_search en repo destino: **/*-collection.json
file_search en repo destino: **/*.environment.json
```

---

## Flujo completo

```
PASO 1: Validar inputs (colección + entorno)
  ↓
PASO 2: Verificar que Newman está disponible
  ↓
PASO 3: Ejecutar Newman
  ↓
PASO 4: Mostrar resultados
```

---

## PASO 1 — Validar inputs

1. **Colección `.json`** — verifica que el archivo existe y es una colección Postman v2.1 válida
2. **Entorno `.json`** — verifica que el archivo existe y contiene las variables necesarias (`baseUrl` como mínimo)
3. **Variables de entorno** — revisa que las variables críticas estén rellenadas (no vacías):
   - `baseUrl` — debe tener un valor real, no placeholder
   - `token` / `tokenUrl` — si la API requiere autenticación, deben estar configurados

Si las variables están vacías, **avisa al usuario** antes de ejecutar:

```
⚠️ Las siguientes variables de entorno están vacías en [archivo]:
- token
- tokenUrl

Los tests que requieran autenticación fallarán. ¿Quieres continuar igualmente?
```

---

## PASO 2 — Verificar que Newman está instalado y en el PATH (OBLIGATORIO)

**Ejecutar estos comandos en secuencia desde PowerShell** antes de continuar:

### 2.1 Comprobar si npm está en el PATH

```powershell
$env:PATH -split ";" | Select-String "npm"
```

### 2.2 Si npm NO está en el PATH, añadirlo

```powershell
$env:PATH += ";$env:APPDATA\npm"
```

### 2.3 Verificar que Newman funciona

```powershell
newman --version
```

Debe devolver `6.2.2` (o superior).

### 2.4 Localizar la ruta del ejecutable

```powershell
Get-Command newman -ErrorAction SilentlyContinue | Select-Object Source
```

**Valores conocidos en este entorno:**
```
Versión: 6.2.2
Ruta:    $env:APPDATA\npm\newman.ps1
```

### 2.5 Si Newman NO está instalado

Si tras añadir npm al PATH `newman --version` sigue fallando:

```
⚠️ Newman no está instalado. Para instalarlo:
  npm install -g newman

¿Quieres que lo instale?
```

**No continuar** al PASO 3 sin Newman instalado y funcionando.

### 2.6 Verificar reporter HTML (OBLIGATORIO)

```powershell
npm list -g newman-reporter-html
```

Si no está instalado, **instalarlo antes de continuar**:

```powershell
npm install -g newman-reporter-html
```

El reporte HTML es **OBLIGATORIO** en cada ejecución. No continuar sin este reporter instalado.

### 2.7 Verificar que la plantilla HTML personalizada está disponible

El reporte HTML usa una **plantilla Handlebars personalizada** (`htmlreqres.hbs`) que muestra
request y response de cada llamada. Esta plantilla está en los assets de esta skill:

```
[skill-path]/assets/htmlreqres.hbs
```

Antes de ejecutar, **copiar la plantilla al repo destino** si no está ahí:

```powershell
Copy-Item "[skill-path]/assets/htmlreqres.hbs" "[repo-destino]/api-tests/htmlreqres.hbs" -Force
```

Si la plantilla no se encuentra en los assets de la skill, buscarla en el repo destino o pedirla al usuario.

---

## PASO 3 — Ejecutar Newman

Ejecuta la colección con el entorno especificado. **SIEMPRE incluir los reporters JSON + HTML con plantilla personalizada:**

**Con environment:**
```powershell
newman run "[ruta-coleccion].json" `
  -e "[ruta-entorno].json" `
  -r cli,json,html `
  --reporter-json-export "[repo-destino]/api-tests/results/newman-results.json" `
  --reporter-html-template "[repo-destino]/api-tests/htmlreqres.hbs" `
  --reporter-html-export "[repo-destino]/api-tests/results/newman-report.html" `
  --timeout-request 10000 `
  --delay-request 100 `
  -k
```

**Sin environment:**
```powershell
newman run "[ruta-coleccion].json" `
  -r cli,json,html `
  --reporter-json-export "[repo-destino]/api-tests/results/newman-results.json" `
  --reporter-html-template "[repo-destino]/api-tests/htmlreqres.hbs" `
  --reporter-html-export "[repo-destino]/api-tests/results/newman-report.html" `
  --timeout-request 10000 `
  --delay-request 100 `
  -k
```

**Los dos reportes son OBLIGATORIOS en CADA ejecución:**
- `newman-results.json` — resultados en JSON (para procesamiento automático)
- `newman-report.html` — reporte visual HTML con plantilla `htmlreqres.hbs` (muestra request + response de cada llamada)

**Flags obligatorios:**
- `-r cli,json,html` — reporters CLI + JSON + HTML
- `--reporter-html-template` — SIEMPRE usar la plantilla `htmlreqres.hbs`
- `-k` — ignorar errores de certificado SSL

**Opciones adicionales según contexto:**
- Si el usuario especifica una carpeta concreta de la colección: añade `--folder "[nombre-carpeta]"`
- Si el usuario quiere más iteraciones: añade `--iteration-count N`

**El comando NO se ejecuta automáticamente** — se presenta al usuario para su aprobación.

### 3.1 Verificar que el reporte HTML se generó (OBLIGATORIO)

**Después de ejecutar, SIEMPRE comprobar que el archivo `newman-report.html` existe:**

```powershell
Test-Path "[repo-destino]/api-tests/results/newman-report.html"
```

Si el archivo **NO existe**, la ejecución se considera **incompleta**. Posibles causas:
- `newman-reporter-html` no está instalado → instalar y re-ejecutar
- La plantilla `htmlreqres.hbs` no se encontró → copiar y re-ejecutar
- Error en la ejecución → revisar el output de consola

**No continuar al PASO 4 sin el reporte HTML generado.** Si es necesario, re-ejecutar el comando.

---

## PASO 4 — Mostrar resultados

Tras la ejecución, presenta los resultados:

```markdown
## Resultados de ejecución Newman — API Tests

**Colección**: [nombre de la colección]
**Entorno**: [DEV/PRE/PRO]
**Estado**: ✅ ALL PASSED / ❌ FAILURES DETECTED / ⚠️ PARTIAL

### Tests ejecutados
| Total | ✅ Pasados | ❌ Fallidos | ⏭️ Skipped | Tiempo total |
|---|---|---|---|---|
| X | X | X | X | Xs |

### ❌ Tests fallidos (si los hay)
| # | Test | Endpoint | Error |
|---|---|---|---|
| 1 | [nombre del test] | [método + path] | [mensaje de error] |
| 2 | ... | ... | ... |

### ⏭️ Tests skipped (si los hay)
| # | Test | Endpoint | Motivo |
|---|---|---|---|
| 1 | [nombre del test] | [método + path] | [motivo si se puede inferir] |

### Assertions (detalle secundario)
| Total | Pasadas | Fallidas |
|---|---|---|
| X | X | X |

### Archivos generados (SIEMPRE ambos)
- `api-tests/results/newman-results.json` — resultados en JSON
- `api-tests/results/newman-report.html` — reporte visual HTML (request + response de cada llamada)

### Acciones disponibles
- Ver detalles de un fallo específico
- Re-ejecutar solo los requests fallidos
- Ejecutar con otro archivo de entorno (PRE, PRO)
```

---

## Gotchas

- **Reporte HTML OBLIGATORIO con plantilla personalizada**: SIEMPRE generar `newman-report.html` con `-r cli,json,html --reporter-html-template htmlreqres.hbs`. Usa `newman-reporter-html` (NO `htmlextra`). La plantilla `htmlreqres.hbs` DEBE estar presente — copiarla desde los assets de la skill si no existe en el repo destino.
- **Verificar variables de entorno antes de ejecutar**: si `baseUrl` o `token` están vacíos, los tests fallarán. Avisa al usuario antes de lanzar.
- **Newman es un CLI local**: a diferencia de Cilantrum (que se ejecuta en Gluon Testing remoto), Newman se ejecuta **localmente** en la máquina del usuario. Asegúrate de que Newman está instalado.
- **Timeouts**: el timeout por defecto de Newman es muy bajo. Usa `--timeout-request 10000` (10s) como mínimo.
- **Orden de ejecución importa**: si la colección tiene un request de autenticación primero que guarda el token en variables, el orden de ejecución debe respetarse. Newman ejecuta en orden por defecto.
- **No hardcodees datos sensibles**: tokens, passwords, client_secrets nunca deben ir en la colección `.json`. Siempre en el archivo de entorno, que no se commitea.
- **Esta skill es solo BACK**: si el usuario pide ejecutar tests de front/Cilantrum, redirige a la skill 3A `ft-frontend-runner`.
- **Colección generada vs manual**: esta skill puede ejecutar cualquier colección Newman, no solo las generadas por skill 2A. Pero está optimizada para ese flujo.

---

## Comandos de ejemplo para el usuario

> "ejecuta los tests de API con el entorno DEV"
> "lanza Newman contra la colección mi-api-collection.json"
> "pasa los tests del back en PRE"
> "ejecuta solo la carpeta 'Autenticación' de la colección"
> "muéstrame los resultados del último Newman"
> "re-ejecuta los tests pero con el entorno PRO"
