---
name: fa-functional-synthesizer
description: >
  Reglas para consolidar los 4 RESUMENes de FASE 1 en una especificación funcional
  coherente. Deduplica pantallas, resuelve conflictos entre fuentes, asigna IDs
  definitivos (FA-REQ-NNN, SCR-NNN, BRN-NNN, ENT-NNN) y calcula confianza.
  Carga {client}-fa-rules para nomenclatura y reglas funcionales del cliente.
---

# fa-functional-synthesizer — Síntesis Funcional

> **Scope:** Consolidación y síntesis de RESUMENes en WF1-FA FASE 2
> **Cubre:** deduplicacion, resolucion-conflictos, asignacion-ids, trazabilidad-bidireccional
> **No cubre:** extracción de fuentes primarias — eso es FASE 1; NFR — ver fa-nfr-extractor

## Inputs

- `resources/FA-DOCS-RESUMEN.md`
- `resources/FA-UI-RESUMEN.md`
- `resources/FA-CODE-RESUMEN.md` (si existe — solo migration/modification/incident)
- `resources/FA-REQ-RESUMEN.md`
- Client Skill `{client-id}-fa-rules` (nomenclatura, alcance, jerarquía de confianza)

## Output

`resources/FA-SYNTHESIS-RESUMEN.md` — ver plantilla en `Templates/fa-resumen-templates.md`

## Fase 1: Consolidación de FA-REQ

```
Por cada FA-REQ candidato detectado en los 4 RESUMENes:
  1. Agrupar por identidad funcional (mismo requisito descrito desde fuentes distintas)
  2. Fusionar información complementaria
  3. Resolver conflictos (ver política de conflictos)
  4. Asignar FA-REQ-NNN definitivo (secuencial, empezando por 001)
  5. Calcular confianza del FA-REQ consolidado
```

**Criterio de identidad funcional para agrupar:**
Dos candidatos son el mismo requisito si:
- Describen la misma pantalla Y el mismo flujo de usuario
- O tienen el mismo ID de origen (misma HU, mismo ticket)
- O describen la misma regla de negocio en la misma pantalla

**No agrupar si:**
- Solo comparten la misma entidad de datos pero son acciones distintas
- El contexto funcional es diferente (buscar vs. editar vs. eliminar)

## Fase 2: Consolidación de Pantallas

```
Por cada SCR candidata en los 4 RESUMENes:
  1. Agrupar pantallas con el mismo nombre funcional de distintas fuentes
  2. Fusionar elementos UI, acciones, roles de todas las fuentes
  3. Contar fuentes confirmatorias → calcular confianza
  4. Asignar SCR-NNN definitivo
  5. Vincular a FA-REQ-NNN correspondientes
```

**Regla de deduplicación de pantallas:**
Dos candidatos son la misma pantalla si:
- El nombre funcional es equivalente (ignorar variaciones menores de texto)
- O el mismo fichero/ruta de código produce la vista
- O el mismo frame de Figma con mismo nombre

**Fuentes confirmatorias para confianza:**
- CONFIRMED: ≥ 2 fuentes distintas confirman la pantalla
- INFERRED: solo 1 fuente la menciona
- ASSUMED: deducida de contexto sin mención explícita

## Fase 3: Consolidación de Reglas de Negocio

```
Por cada BRN candidata en los 4 RESUMENes:
  1. Agrupar reglas que describen la misma condición en la misma pantalla
  2. Si coinciden → CONFIRMED
  3. Si contradicen → FA-GAP RULE-AMBIGUOUS → BRN queda en estado BLOQUEADA
  4. Asignar BRN-NNN definitivo
  5. Vincular a SCR-NNN y FA-REQ-NNN
```

## Política de Resolución de Conflictos entre Fuentes

| Tipo de conflicto                      | Política                                                    |
|----------------------------------------|-------------------------------------------------------------|
| Misma regla, valores distintos          | FA-GAP RULE-AMBIGUOUS — BLOQUEANTE — registrar ambos valores |
| Pantalla en UI pero no en docs          | Incluir (UI confirma existencia) + verificar en CV gate     |
| Pantalla en docs pero no en UI          | Incluir como INFERRED + FA-GAP SCREEN-MISSING si es CONFIRMADA |
| Comportamiento código ≠ spec           | FA-GAP DISCREPANCIA-DOC-CODIGO — BLOQUEANTE                 |
| Funcionalidad en código, sin doc        | FA-GAP UNDOCUMENTED-FEATURE — operador decide              |
| Spec documentada, sin código            | FA-GAP UNIMPLEMENTED-SPEC — operador confirma FA-REQ       |
| Roles distintos para la misma acción    | FA-GAP ROLE-UNCLEAR — BLOQUEANTE                           |

**Regla de oro:** NUNCA silenciar contradicciones. Si dos fuentes dicen cosas
distintas sobre el mismo elemento funcional, registrar el conflicto como FA-GAP
y marcar el elemento como BLOQUEADO hasta resolución.

## Jerarquía de Confianza (aplicar según client-rules)

La jerarquía por defecto (puede ser sobreescrita por `{client}-fa-rules`):
```
1. Código fuente              → comportamiento real actual (migration/modification)
2. Figma v2+ (diseño reciente)→ intención de diseño validada
3. BRD firmado / HU aprobada  → requisito formal del cliente
4. Manual de usuario          → comportamiento esperado por usuario
5. Actas de reunión           → intención informal
6. Emails / notas             → contexto adicional, no normativo
```

## Construcción de Trazabilidad Bidireccional

`fa-functional-synthesizer` debe construir la siguiente matriz:

```
FA-REQ-NNN → SCR-NNN (pantallas que pertenecen a este req)
SCR-NNN → BRN-NNN (reglas que aplican en esta pantalla)
SCR-NNN → ENT-NNN (entidades que se visualizan/editan en esta pantalla)
SCR-NNN → NAV-NNN (transiciones de/hacia esta pantalla)
FA-REQ-NNN → ROL-NNN (roles con acceso a los requisitos)

Verificaciones de integridad:
- ¿Todo FA-REQ tiene al menos una SCR? → si no: FA-GAP REQ-WITHOUT-SCREEN
- ¿Toda SCR tiene al menos un FA-REQ? → si no: FA-GAP REQ-ORPHAN
- ¿Todo FA-REQ funcional tiene al menos una BRN? → si no: FA-GAP REQ-WITHOUT-RULE
```

## Aplicación de Client Rules

Al synthesizar, cargar `{client}-fa-rules` y aplicar:
1. **Nomenclatura funcional:** renombrar roles, IDs, estados según alias del cliente
2. **Reglas de alcance:** marcar como EXCLUIDO lo que el cliente diga excluir
3. **Jerarquía de confianza:** usar la jerarquía del cliente si difiere de la default
4. **Restricciones de privacidad:** enmascarar datos sensibles en artefactos

## Cálculo de Cobertura

```
cobertura = (pantallas_con_≥2_fuentes_confirmatorias / total_pantallas) × 100
```

Reportar esta métrica en el FA-SYNTHESIS-RESUMEN para que `fa-coverage-gate` la use.
