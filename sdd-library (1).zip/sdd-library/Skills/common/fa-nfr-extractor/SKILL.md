---
name: fa-nfr-extractor
description: >
  Busca y clasifica requisitos no funcionales (NFR) en todas las fuentes del
  análisis: rendimiento, seguridad, accesibilidad, internacionalización,
  disponibilidad y mantenibilidad. Emite FA-GAP NFR-MISSING para dominios
  críticos sin especificación.
---

# fa-nfr-extractor — Requisitos No Funcionales

> **Scope:** Extracción de requisitos no funcionales en WF1-FA FASE 2
> **Cubre:** categorias-nfr, patrones-extraccion, nfr-missing-gaps, formato-nfr
> **No cubre:** implementación técnica de NFR — eso es WF2; NFR de proceso (metodología)

## Categorías NFR a Buscar

### 1. Rendimiento
| Indicador lingüístico         | Ejemplo                                        |
|-------------------------------|------------------------------------------------|
| SLA explícito                 | "respuesta en menos de X segundos"             |
| Capacidad / volumen           | "soportar N usuarios concurrentes"             |
| Throughput                    | "procesar N transacciones por hora"            |
| Tiempos de carga              | "la pantalla carga en menos de X segundos"     |

**Campos NFR de rendimiento:**
- Operación afectada (búsqueda, guardado, carga de pantalla, etc.)
- SLA numérico (tiempo máximo, percentil si se especifica)
- Condición de medición (usuarios concurrentes, volumen de datos)
- Pantallas / FA-REQ afectados

### 2. Seguridad
| Indicador                      | Ejemplo                                        |
|--------------------------------|------------------------------------------------|
| Autenticación                  | "el usuario debe estar autenticado", "SSO", "OAuth2" |
| Autorización / RBAC            | "solo ADMIN puede", "control de acceso"        |
| Protección de datos            | "GDPR", "datos personales", "cifrado", "enmascarar" |
| Auditoría                      | "registrar quién hizo qué", "log de acciones" |
| Normativa                      | "ISO 27001", "PCI-DSS", "ENS"                 |

### 3. Accesibilidad
| Indicador                      | Ejemplo                                        |
|--------------------------------|------------------------------------------------|
| WCAG                           | "cumplir WCAG 2.1", "nivel AA", "nivel AAA"   |
| Lectores de pantalla           | "compatible con lector de pantalla"           |
| Contraste                      | "ratio de contraste 4.5:1"                    |
| Navegación teclado             | "navegable sin ratón"                         |

### 4. Internacionalización (i18n)
| Indicador                      | Ejemplo                                        |
|--------------------------------|------------------------------------------------|
| Idiomas                        | "disponible en español e inglés"              |
| Formatos de fecha/número       | "formato europeo de fechas"                   |
| Zona horaria                   | "convertir a hora local del usuario"          |
| Moneda                         | "visualizar en EUR", "3 decimales"            |

### 5. Disponibilidad y Fiabilidad
| Indicador                      | Ejemplo                                        |
|--------------------------------|------------------------------------------------|
| SLA de disponibilidad          | "99.9% uptime", "máximo 4 horas de downtime"  |
| Backup / Recuperación          | "backup diario", "RTO de 4 horas"             |
| Mantenimiento                  | "ventana de mantenimiento semanal"            |

### 6. Mantenibilidad
| Indicador                      | Ejemplo                                        |
|--------------------------------|------------------------------------------------|
| Código limpio                  | "seguir estándares de Clean Code"             |
| Cobertura de tests             | "mínimo 80% de cobertura de tests"            |
| Documentación                  | "código documentado con JavaDoc"              |

## Formato de Registro NFR

```markdown
## NFR-{NNN}
- **categoria:** Rendimiento | Seguridad | Accesibilidad | i18n | Disponibilidad | Mantenibilidad
- **descripcion:** Descripción precisa del requisito no funcional
- **metrica:** Valor numérico o criterio medible (si se especifica)
- **condicion:** Contexto de medición (si aplica)
- **req-vinculados:** [FA-REQ-NNN, ...] (o "todos" si aplica globalmente)
- **pantallas-afectadas:** [SCR-NNN, ...] (o "todas" si aplica globalmente)
- **fuente:** Nombre del documento + sección/página
- **confianza:** CONFIRMED | INFERRED | ASSUMED
```

**Ejemplo:**
```markdown
## NFR-001
- categoria: Rendimiento
- descripcion: La pantalla de búsqueda debe devolver resultados en menos de 3 segundos
- metrica: < 3 segundos (tiempo de respuesta end-to-end)
- condicion: Con hasta 100 usuarios concurrentes y base de datos con 1M registros
- req-vinculados: [FA-REQ-001]
- pantallas-afectadas: [SCR-001]
- fuente: BRD sección 6.1 — "Requisitos de rendimiento"
- confianza: CONFIRMED
```

## Gaps NFR-MISSING

Para los siguientes dominios NFR **críticos**, si no se encuentra ninguna fuente:
→ Emitir FA-GAP tipo `NFR-MISSING` (severidad RECOMENDADO)

| Dominio          | Emitir gap si...                                           |
|------------------|------------------------------------------------------------|
| Seguridad/Auth   | No hay ninguna mención de autenticación/autorización       |
| GDPR/Privacidad  | La app maneja datos personales y no hay mención de GDPR    |
| Rendimiento      | Hay pantallas de consulta masiva sin SLA documentado       |
| Accesibilidad    | No hay mención de WCAG o accesibilidad                     |
| i18n             | La app tiene idioma configurado pero sin formatos de datos |

**Formato del gap NFR-MISSING:**
```markdown
## FA-GAP-{NNN}
- tipo: NFR-MISSING
- severidad: RECOMENDADO
- categoria-nfr: Rendimiento | Seguridad | Accesibilidad | ...
- req-vinculados: [todos | FA-REQ-NNN específicos]
- descripcion: No se encontró ninguna especificación de {dominio} en las fuentes analizadas.
               Dominio crítico que WF2 necesita para diseño técnico correcto.
- impacto: WF2 tomará decisiones razonables por defecto (documentadas en fa-prerequisites.md)
- accion-requerida: "Confirmar con cliente si hay requisitos de {dominio}"
- responsable-sugerido: Product Owner | Arquitecto
- estado: ABIERTO
```

## Sección NFR en FA-SYNTHESIS-RESUMEN

`fa-nfr-extractor` añade la sección `## Requisitos No Funcionales` al FA-SYNTHESIS-RESUMEN
con todos los NFR encontrados organizados por categoría, más la lista de gaps NFR-MISSING.
