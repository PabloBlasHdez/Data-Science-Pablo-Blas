---
name: fa-complexity-sizer
description: >
  Clasifica la complejidad del proyecto en small/medium/large basándose en las
  fuentes disponibles. Determina APP_SIZE que ajusta comportamiento del workflow
  (tamaño de prompts, lotes de imágenes, estrategia de análisis).
---

# fa-complexity-sizer — Clasificación de Complejidad

> **Scope:** Clasificación de complejidad de proyectos para WF1-FA
> **Cubre:** criterios-clasificacion, APP_SIZE, ajustes-por-tamaño
> **No cubre:** análisis de calidad del código — ese es fa-code-extractor

## Criterios de Clasificación

| Criterio                          | Small      | Medium      | Large      |
|-----------------------------------|------------|-------------|------------|
| Fuentes habilitadas (`enabled: true`) | 1–3    | 4–6         | 7+         |
| Páginas de documentación estimadas | < 50 pág   | 50–200 pág  | 200+ pág   |
| Pantallas estimadas               | < 10       | 10–30       | 30+        |
| Ficheros UI en código fuente      | < 20       | 20–80       | 80+        |

**Regla de clasificación:** Usar el criterio más alto alcanzado. Si tres criterios dan
"medium" y uno da "large", el resultado es `large`.

## Procedimiento de Sizing

1. Leer `fa-config.yml` → contar `sources.*.enabled = true`
2. Contar páginas estimadas en `input/docs/` (aproximación: 1 PDF A4 ≈ 1 página por MB)
3. Contar imágenes en `input/screens/`
4. Si `sources.code.enabled = true`: contar ficheros `*.jsp`, `*.html`, `*.vue`, `*.tsx`, `*.cshtml`, `*.ftl` en `source-app/`
5. Aplicar tabla → `APP_SIZE = small | medium | large`
6. Escribir resultado en `resources/complexity-assessment.md`

## Formato de salida: complexity-assessment.md

```markdown
---
app-id: {APP_ID}
assessed-at: YYYY-MM-DDTHH:MM:SSZ
---

# Complexity Assessment — {APP_ID}

## Resultado
- **APP_SIZE:** small | medium | large
- **PROMPT_SIZE_HINT:** compact | standard | extended

## Métricas medidas
| Criterio                    | Valor medido | Clasificación |
|-----------------------------|--------------|---------------|
| Fuentes habilitadas         | N            | small/medium/large |
| Páginas documentación (est) | N            | small/medium/large |
| Pantallas estimadas         | N            | small/medium/large |
| Ficheros UI en código       | N (o N/A)    | small/medium/large |

## Criterio determinante
El criterio más alto alcanzado: {criterio} → {tamaño}
```

## Ajustes por APP_SIZE

### APP_SIZE = small
- **PROMPT_SIZE_HINT:** compact
- Subagentes pueden procesar todas las fuentes en una sola invocación
- `fa-ui-extractor`: procesa todas las imágenes en un lote
- Síntesis: procesamiento único sin fragmentación

### APP_SIZE = medium
- **PROMPT_SIZE_HINT:** standard
- Subagentes procesan fuentes en lotes lógicos (por tipo de documento)
- `fa-ui-extractor`: máximo 10 imágenes por llamada
- Síntesis: puede requerir consolidación en dos pasadas

### APP_SIZE = large
- **PROMPT_SIZE_HINT:** extended
- Subagentes procesan fuentes en lotes pequeños (por carpeta o módulo)
- `fa-ui-extractor`: **máximo 5 imágenes por llamada** (límite multimodal)
- Síntesis: consolidación fragmentada por dominio funcional
- Orquestador debe gestionar context window activamente

## Estimación rápida para fa-config.yml incompleto

Si `fa-config.yml` no tiene información suficiente para calcular, usar estimación conservadora:
- Sin código fuente → máximo `medium` por defecto
- Sin documentación → `small` por defecto
- Con código fuente legado (migration) → asumir `medium` hasta verificación
