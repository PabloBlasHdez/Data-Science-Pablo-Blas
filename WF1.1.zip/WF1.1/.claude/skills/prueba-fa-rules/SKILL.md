---
name: prueba-fa-rules
description: >
  Client Skill para WF1-FA del cliente PRUEBA. Define las reglas funcionales,
  nomenclatura de negocio, alcance, jerarquía de confianza, restricciones
  de privacidad y convenciones del stack target.
---

# PRUEBA FA Rules

> **Scope:** Reglas funcionales del cliente PRUEBA para análisis funcional WF1-FA
> **Cubre:** nomenclatura, alcance, confianza, privacidad, convenciones-target
> **No cubre:** stack técnico detallado
> **Cliente:** prueba

---

## Sección 1 — Nomenclatura Funcional del Cliente

### Alias de Roles

| Nombre en documentos del cliente | ID estándar en artefactos | Notas                          |
|----------------------------------|---------------------------|--------------------------------|
| Usuario / Owner                  | USER                      | Propietario de mascotas        |
| Veterinario                      | GESTOR                    | Profesional con acceso clínico |
| Recepcionista / Staff            | SUPERVISOR                | Gestión de citas y admin       |
| Administrador                    | ADMIN                     | Administrador del sistema      |

### Terminología de Negocio

| Término del cliente | Equivalente funcional estándar | Notas                    |
|---------------------|-------------------------------|--------------------------|
| Pet / Mascota       | Paciente / Entidad mascota    | Entidad principal        |
| Owner / Dueño       | Propietario de mascota        | Usuario registrado       |
| Visit / Visita      | Consulta veterinaria          | Registro de atención     |
| Vet / Veterinario   | Profesional GESTOR            | Usuario con rol clínico  |
| Ficha               | Detalle / vista individual    | Pantalla de detalle      |
| Listado             | Búsqueda / lista              | Pantalla de búsqueda     |
| Alta                | Creación                      | Acción de crear registro |
| Baja                | Eliminación                   | Acción de eliminar       |

---

## Sección 2 — Reglas de Alcance

### Exclusiones Automáticas

| Indicador                         | Acción                                       |
|-----------------------------------|----------------------------------------------|
| Funcionalidades marcadas "Fase 2" | Excluir con nota "Fase 2 — fuera de alcance" |
| Pantallas marcadas DEPRECATED     | Marcar como código muerto funcional          |

### Indicadores de Inclusión Prioritaria

| Indicador                         | Prioridad                                |
|-----------------------------------|------------------------------------------|
| Flujos de gestión de mascotas     | Máxima prioridad — núcleo del sistema    |
| Flujos de citas y visitas         | Alta prioridad                           |
| Panel de administración           | Prioridad media                          |

---

## Sección 3 — Jerarquía de Confianza

```
(Mayor autoridad)
4. Especificación funcional escrita (BRD / Functional Spec)
3. Figma / wireframes validados con cliente
2. Historias de usuario aprobadas
1. Actas de reunión y emails
(Menor autoridad)
```

---

## Sección 4 — Restricciones de Privacidad

| Tipo de dato                      | Enmascaramiento en artefactos              |
|-----------------------------------|--------------------------------------------|
| Datos médicos de animales         | Generalizar — no incluir datos reales      |
| Datos de contacto de propietarios | Reemplazar por datos ficticios de ejemplo  |

**Regulaciones aplicables:** GDPR, LOPD-GDD.

---

## Sección 5 — Convenciones Target

### Frontend

- **Tecnología:** Angular 17+
- **Módulos:** por dominio (owners, pets, vets, appointments), lazy-loading
- **Nomenclatura componentes:** PascalCase, sufijo `Component`, kebab-case en selector
- **Formularios:** Reactive Forms para formularios con más de 3 campos
- **Rutas:** kebab-case en URLs, `/api/v1/` prefix
- **Estilos:** SCSS, Bootstrap 5 o Angular Material

### Backend

- **Tecnología:** Java 17 + Spring Boot 3+
- **Arquitectura:** Controller → Service → Repository (JPA)
- **Endpoints:** REST plural, `/api/v1/` prefix
- **Autenticación:** Spring Security + JWT
- **Base de datos:** H2 (dev/test), PostgreSQL (producción)

### Formatos de Datos

- **Fechas:** dd/MM/yyyy en UI; ISO 8601 en API
- **Idioma UI:** es — Español
- **Zona horaria:** Europe/Madrid

---

## Sección 6 — Reglas de Confianza por Herramienta

| Fuente                    | Confianza     | Notas                         |
|---------------------------|---------------|-------------------------------|
| Functional Spec PetClinic | CONFIRMED     | Fuente principal del proyecto |
| Figma / wireframes        | N/A           | No disponibles                |

---

## Sección 7 — Módulos y Dominios del Proyecto

| Módulo / Dominio           | Prefijo FA-REQ   | Notas                   |
|----------------------------|------------------|-------------------------|
| Módulo Auth / Acceso       | FA-REQ-0XX       | Login, registro, perfil |
| Módulo Owners / Propietarios | FA-REQ-1XX     | Gestión de propietarios |
| Módulo Pets / Mascotas     | FA-REQ-2XX       | Gestión de mascotas     |
| Módulo Vets / Veterinarios | FA-REQ-3XX       | Gestión de veterinarios |
| Módulo Visits / Citas      | FA-REQ-4XX       | Citas y visitas         |
| Módulo Admin               | FA-REQ-5XX       | Panel de administración |
