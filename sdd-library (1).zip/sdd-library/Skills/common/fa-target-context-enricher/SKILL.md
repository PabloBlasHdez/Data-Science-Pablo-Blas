---
name: fa-target-context-enricher
description: >
  Enriquece el FA-SYNTHESIS-RESUMEN con las convenciones del stack target del
  cliente: nomenclatura de componentes, formatos de datos, idioma de la UI,
  arquitectura esperada. Lee la sección "Convenciones target" del Client Skill.
  No modifica los requisitos funcionales — solo añade contexto para WF2.
---

# fa-target-context-enricher — Enriquecimiento con Contexto Target

> **Scope:** Enriquecimiento con convenciones target del cliente en WF1-FA FASE 2
> **Cubre:** convenciones-frontend, convenciones-backend, formatos, idioma-ui, privacidad
> **No cubre:** análisis técnico de implementación — eso es WF2; requisitos funcionales

## Propósito

WF1 produce especificación funcional stack-agnóstica. Sin embargo, el equipo de WF2
(Análisis Técnico) necesita saber en qué tecnología se va a implementar para tomar
decisiones de diseño técnico informadas.

`fa-target-context-enricher` añade al FA-SYNTHESIS-RESUMEN una sección
`target-context` con las convenciones del cliente, sin tocar los FA-REQ ni los SCR.

## Input

- `resources/FA-SYNTHESIS-RESUMEN.md` (generado por fa-functional-synthesizer)
- Sección **"Convenciones target"** del Client Skill `{client-id}-fa-rules`
- `fa-config.yml` → campos `project.target.frontend` y `project.target.backend`

## Output

`resources/FA-SYNTHESIS-RESUMEN.md` actualizado con sección `## Target Context` añadida al final.

## Sección Target Context a Generar

```markdown
## Target Context
> Convenciones del stack target para WF2 (Análisis Técnico).
> Fuente: {client-id}-fa-rules + fa-config.yml

### Stack confirmado
- **Frontend:** {valor de project.target.frontend en fa-config.yml}
- **Backend:** {valor de project.target.backend en fa-config.yml}
- **Idioma UI primario:** {primary-language de fa-config.yml}

### Convenciones frontend ({tecnología})
{Copiar directamente de la sección "Convenciones target → Frontend" del Client Skill}

Ejemplo para Angular:
- Estructura: módulos por dominio, lazy-loading obligatorio
- Nomenclatura componentes: PascalCase, sufijo 'Component'
- Nomenclatura servicios: PascalCase, sufijo 'Service'
- Estado: NgRx / Signals / servicios con BehaviorSubject (según client-rules)
- Formularios: Reactive Forms obligatorio para formularios complejos
- Rutas: kebab-case en URLs

### Convenciones backend ({tecnología})
{Copiar directamente de la sección "Convenciones target → Backend" del Client Skill}

Ejemplo para .NET:
- Arquitectura: Clean Architecture con capas Domain/Application/Infrastructure/API
- Patrón: CQRS con MediatR para comandos y queries
- Nomenclatura endpoints: REST, plural, kebab-case
- Nomenclatura DTOs: PascalCase, sufijo 'Request'/'Response'

### Formatos de datos
- Fechas: {formato del cliente, ej: dd/MM/yyyy}
- Fechas con hora: {ej: dd/MM/yyyy HH:mm:ss}
- Moneda: {ej: EUR, 2 decimales, símbolo al final: "1.234,56 €"}
- Números: {ej: separador decimal coma, separador miles punto}

### Idioma y localización
- Idioma UI primario: {ej: es}
- Idioma UI secundario: {ej: en — si aplica}
- Zona horaria base: {ej: Europe/Madrid}

### Notas de privacidad para WF2
{Restricciones de privacidad relevantes para el diseño técnico}
Ejemplo: NIF/CIF nunca en logs; datos de tarjeta solo tokenizados; GDPR aplica

### Notas de seguridad para WF2
{Si el client-rules menciona requisitos de seguridad técnicos}
Ejemplo: JWT tokens, OAuth2, RBAC implementado con middleware X
```

## Casos de Client Rules Vacías o Parciales

Si la sección "Convenciones target" del Client Skill no existe o está incompleta:
1. Usar los valores de `fa-config.yml → project.target` como base
2. Indicar en el target-context que las convenciones son genéricas (no validadas con el cliente)
3. Registrar FA-GAP tipo `ARCH-BLOCKER` si hay decisiones técnicas críticas sin definir
   (ej: mecanismo de autenticación sin confirmar)

## Lo que NO hace este skill

- No modifica FA-REQ, SCR, BRN, ENT ni ningún elemento funcional
- No toma decisiones técnicas de implementación (eso es WF2)
- No valida que la tecnología target sea viable (eso es WF2)
- Solo transcribe las convenciones declaradas en el Client Skill al artefacto de síntesis
