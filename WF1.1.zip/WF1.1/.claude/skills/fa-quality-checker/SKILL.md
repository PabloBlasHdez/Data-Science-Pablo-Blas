---
name: fa-quality-checker
description: >
  Heurísticas de detección de violaciones de los 6 atributos de calidad
  ISO/IEC/IEEE 29148:2018 (unambiguous, complete, consistent, verifiable,
  traceable, feasible). Lee dinámicamente fa-governance.yml para conocer
  qué atributos son obligatorios y qué tipo de gap emitir por cada uno.
  Aplicado por fa-quality-gate sobre cada FA-REQ tras FASE 1.
---

# fa-quality-checker — Heurísticas ISO 29148

> **Scope:** Verificación de calidad de requisitos contra ISO 29148
> **Cubre:** deteccion-ambiguedad, completitud, consistencia, verificabilidad, trazabilidad, viabilidad
> **No cubre:** resolución — el operador debe aportar fuente o aclaración

## Contrato de uso

Este skill se invoca por `fa-quality-gate` con:

- **Inputs:**
  - `resources/FA-DOCS-RESUMEN.md` (y los otros 3 RESUMENes si existen)
  - `fa-governance.yml` (resolución portable: `{workspace_root}/fa-governance.yml`
    → `./fa-governance.yml` → `../fa-governance.yml`, primera ubicación existente)
    → secciones `requirements_quality.validation_rules` y `overrides_schema`
  - `fa-config.yml` → sección `governance-overrides` (si existe)

- **Outputs:**
  - Lista de `FA-GAP` candidatos (uno por atributo fallado por FA-REQ)
  - `resources/governance-effective.md` (política efectiva tras merge override)
  - `resources/quality-report.md` (informe por atributo y por FA-REQ)

---

## Política efectiva (merge fa-governance + overrides)

```
atributos_obligatorios = fa-governance.yml.requirements_quality.mandatory_attributes
atributos_a_verificar  = atributos_obligatorios - fa-config.yml.governance-overrides.skip_quality_attributes

Para cada atributo en atributos_a_verificar:
  gap_type     = fa-governance.yml.validation_rules[atributo].gap_type
  severity     = fa-governance.yml.validation_rules[atributo].severity
  // Aplicar override de severidad si existe
  severity_eff = fa-config.yml.governance-overrides.override_severity[gap_type] ?: severity

→ Escribir resources/governance-effective.md con la política efectiva resuelta
```

> **Importante:** No hay heurísticas hardcoded en el agente o en este skill.
> Los atributos a verificar, sus tipos de gap y sus severidades vienen del YAML.
> Cambiar `mandatory_attributes` o añadir un nuevo atributo en el YAML cambia
> automáticamente el comportamiento del gate sin tocar código.

---

## Heurísticas de detección por atributo

Las heurísticas operan sobre el texto del FA-REQ (descripción + criterios + metadatos
extraídos del RESUMEN). Cada FAIL emite un FA-GAP del tipo declarado en el YAML.

### unambiguous → REQ-AMBIGUOUS

```
Para cada FA-REQ:
  Recoger texto = descripcion + criterios-aceptacion (si existen)

  FAIL si:
    (a) Contiene palabras vagas listadas en validation_rules.unambiguous.detection_heuristics.vague_words
        (búsqueda case-insensitive, palabra completa)
    (b) Contiene "?" o "¿" en la descripción (preguntas sin resolver)
    (c) Menciona dos alternativas con "o" / "ó" sin resolución posterior
        (ej: "se bloquea, advierte O permite igualmente")

  Mensaje de gap:
    "FA-REQ-{NNN} no cumple atributo unambiguous (ISO 29148).
     Detectado: {evidencia textual}.
     Acción: redactar de forma inequívoca o documentar la decisión del PO."
```

### complete → REQ-INCOMPLETE

```
Para cada FA-REQ:
  FAIL si:
    (a) criterios-aceptacion vacíos o ausentes (campo no existe en el RESUMEN)
    (b) descripcion.length < 30 caracteres
    (c) tipo = ASUMIDO Y origen vacío
    (d) tipo = DIRECTO pero ninguna fuente referenciada

  Mensaje de gap:
    "FA-REQ-{NNN} no cumple atributo complete (ISO 29148).
     Carece de: {criterios | descripción suficiente | origen}.
     Acción: aportar la información ausente."
```

### consistent → REQ-INCONSISTENT

```
Aplicar tras la síntesis (FASE 2) si está disponible, o sobre los RESUMENes
crudos si se ejecuta tras FASE 1.

FAIL si:
  (a) Existe otro FA-REQ con misma pantalla/entidad y comportamiento contradictorio
      (heurística: dos FA-REQ comparten SCR pero usan verbos opuestos:
       "permite" vs "bloquea", "obligatorio" vs "opcional")
  (b) Una BRN vinculada al FA-REQ tiene confianza CONFIRMED pero el FA-REQ
      la contradice (verificable por análisis textual)
  (c) cross-validation-report.md emitió FAIL en CV-04 (roles) o CV-06 (flujos)
      para una pantalla vinculada al FA-REQ

Mensaje de gap:
  "FA-REQ-{NNN} no cumple atributo consistent (ISO 29148).
   Conflicto con: {FA-REQ-MMM o BRN-NNN}.
   Acción: resolver la contradicción con el PO."
```

### verifiable → REQ-UNVERIFIABLE

```
Para cada FA-REQ:
  FAIL si:
    (a) criterios-aceptacion vacíos (sin Given/When/Then ni medidas objetivas)
    (b) descripcion contiene adjetivos subjetivos sin umbral:
        ["rápido", "fácil", "amigable", "robusto", "intuitivo", "moderno",
         "óptimo", "eficiente", "agradable"]
    (c) FA-REQ es NFR-* pero no contiene número ni unidad
        (ej: NFR de performance sin segundos/ms; NFR de capacidad sin volumen)

  Mensaje de gap:
    "FA-REQ-{NNN} no cumple atributo verifiable (ISO 29148).
     Sin métrica objetiva: {adjetivos detectados}.
     Acción: añadir criterio testeable (umbral, condición Given/When/Then)."
```

### traceable → REQ-UNTRACEABLE

```
Para cada FA-REQ:
  FAIL si:
    (a) origen vacío (no se puede rastrear al stakeholder_need)
    (b) Ninguna SCR vinculada Y ninguna BRN vinculada (sin downstream)
    (c) tipo = ASUMIDO sin justificación documentada

  Mensaje de gap:
    "FA-REQ-{NNN} no cumple atributo traceable (ISO 29148).
     Sin: {origen | downstream}.
     Acción: documentar el stakeholder o fuente origen, vincular pantalla/regla."
```

### feasible → REQ-INFEASIBLE

```
Para cada FA-REQ:
  FAIL si:
    (a) Depende de INT-NNN (integración) con confianza ASSUMED
    (b) Menciona tecnología no presente en {client}-fa-rules sec.5 (target context)
    (c) El documento original incluye marcadores explícitos:
        "¿es viable?", "pendiente de arquitecto", "depende de infra"

  Mensaje de gap (severidad RECOMENDADO por defecto):
    "FA-REQ-{NNN} requiere validación de viabilidad (ISO 29148).
     Motivo: {integración ASSUMED | tecnología no confirmada | duda explícita}.
     Acción: revisión por arquitecto antes de cierre WF1."
```

---

## Resolución de IDs FA-GAP

Los gaps emitidos por este skill se numeran continuando la secuencia
existente en `resources/open-gaps.md`. Si el último gap es FA-GAP-029,
el primer gap de calidad será FA-GAP-030.

Cada gap emitido sigue el formato canónico definido en `fa-gap-detector`,
añadiendo un campo extra `iso_attribute` para trazabilidad inversa:

```yaml
## FA-GAP-{NNN}
- tipo: REQ-AMBIGUOUS
- iso_attribute: unambiguous            # ← campo nuevo (trazabilidad a ISO 29148)
- severidad: BLOQUEANTE
- iteracion-detectada: ITER-NNN
- req-vinculados: [FA-REQ-NNN]
- pantalla: SCR-NNN
- descripcion: >
    {mensaje generado por la heurística, con evidencia textual citada}
- impacto: WF2 no puede generar test cases verificables para este FA-REQ
- accion-requerida: {acción concreta indicada por la heurística}
- responsable-sugerido: Product Owner
- estado: ABIERTO
- iteracion-resuelta: —
```

---

## Plantilla `resources/quality-report.md`

```markdown
# Quality Report — Iteración ITER-NNN

**Política efectiva:** ver `governance-effective.md`
**Atributos verificados:** unambiguous, complete, consistent, verifiable, traceable, feasible
**Total FA-REQ evaluados:** {N}

## Resumen por atributo

| Atributo     | FA-REQ pasa | FA-REQ falla | % cumplimiento | Gaps emitidos |
|--------------|-------------|--------------|----------------|---------------|
| unambiguous  | 10          | 4            | 71%            | 4 × REQ-AMBIGUOUS |
| complete     | 12          | 2            | 86%            | 2 × REQ-INCOMPLETE |
| consistent   | 14          | 0            | 100%           | 0             |
| verifiable   | 8           | 6            | 57%            | 6 × REQ-UNVERIFIABLE |
| traceable    | 14          | 0            | 100%           | 0             |
| feasible     | 13          | 1            | 93%            | 1 × REQ-INFEASIBLE |

## Detalle por FA-REQ

| FA-REQ      | unambig | complete | consist | verif | traceab | feasib | Veredicto |
|-------------|---------|----------|---------|-------|---------|--------|-----------|
| FA-REQ-001  | ✓       | ✓        | ✓       | ✗     | ✓       | ✓      | FAIL      |
| FA-REQ-002  | ✗       | ✓        | ✓       | ✗     | ✓       | ✓      | FAIL      |
| ...         |         |          |         |       |         |        |           |

## Veredicto del Gate

- Total FA-REQ: {N}
- FA-REQ que pasan los 6 atributos: {M}
- FA-REQ con al menos un atributo fallado: {N-M}
- Gaps BLOQUEANTES de calidad emitidos: {X}
- Gaps RECOMENDADOS de calidad emitidos: {Y}

→ Veredicto: `pass` | `fail` | `checkpoint`
```

---

## Plantilla `resources/governance-effective.md`

```markdown
# Política de Gobernanza Efectiva — ITER-NNN

Resultado del merge `fa-governance.yml` + `fa-config.yml.governance-overrides`.
Esta es la política aplicada por fa-quality-gate y fa-closure-gate en esta iteración.

## Atributos de calidad verificados

| Atributo     | Gap type emitido    | Severidad efectiva | Origen severidad |
|--------------|---------------------|--------------------|------------------|
| unambiguous  | REQ-AMBIGUOUS       | BLOQUEANTE         | fa-governance.yml |
| complete     | REQ-INCOMPLETE      | BLOQUEANTE         | fa-governance.yml |
| consistent   | REQ-INCONSISTENT    | BLOQUEANTE         | fa-governance.yml |
| verifiable   | REQ-UNVERIFIABLE    | BLOQUEANTE         | fa-governance.yml |
| traceable   | REQ-UNTRACEABLE     | BLOQUEANTE         | fa-governance.yml |
| feasible     | REQ-INFEASIBLE      | RECOMENDADO        | fa-governance.yml |

## Atributos omitidos (governance-overrides.skip_quality_attributes)

{lista o "ninguno"}

## Otros parámetros efectivos

- max_unvalidated_requirements_allowed: {valor}  (origen: {global | override})
- allow_assumed_to_inferred_promotion: {bool}   (origen: {global | override})
```
