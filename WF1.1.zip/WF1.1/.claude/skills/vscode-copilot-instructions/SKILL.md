---
name: vscode-copilot-instructions
description: >
  Crear o editar instrucciones de proyecto que Copilot Chat aplica
  automáticamente: .github/copilot-instructions.md (workspace-wide) y
  .github/instructions/*.instructions.md (scoped por glob applyTo). Define
  convenciones, stack, estilo y reglas que el agente debe seguir.
  Activar cuando el usuario quiere fijar reglas de proyecto para Copilot,
  documentar convenciones del repo, o crear guías por área (frontend, tests).
---

# vscode-copilot-instructions — Reglas de Proyecto para Copilot

> **Scope:** Ficheros de instrucciones que VS Code Copilot Chat carga automáticamente
> **Cubre:** copilot-instructions.md workspace-wide, *.instructions.md scoped por glob, frontmatter applyTo, buenas prácticas de redacción
> **No cubre:** prompts de un solo uso (usar Chat directamente); skills (ver spec de agent-skills)

## Cuándo activar

- "Configura las reglas del proyecto para Copilot"
- "Quiero que Copilot use siempre React Server Components"
- "Añade convenciones de tests al chat de Copilot"
- "Crea reglas que solo apliquen a ficheros .tsx"

## Dos niveles de instrucciones

| Fichero                                       | Alcance                                | Frontmatter |
|-----------------------------------------------|----------------------------------------|-------------|
| `.github/copilot-instructions.md`             | TODO el workspace, siempre cargado     | No requiere |
| `.github/instructions/{name}.instructions.md` | Scoped por glob via `applyTo`          | Sí (`applyTo`) |

VS Code Copilot Chat carga ambos automáticamente al iniciar la sesión.

## copilot-instructions.md — Workspace-wide

Sin frontmatter. Markdown plano. Lo lee Copilot en CADA conversación del workspace.

```markdown
# Convenciones del proyecto

## Stack
- Frontend: Next.js 14 (App Router) + TypeScript estricto
- Backend: Node 20 + Fastify + Prisma + PostgreSQL
- Tests: Vitest (unit), Playwright (e2e)

## Estilo
- TypeScript: prefer `type` over `interface` salvo para extends públicos
- Imports: orden — externos / internos absolutos (@/...) / relativos
- No usar `any` — usar `unknown` + narrowing

## Estructura
- Código de UI en `app/` (App Router), no en `pages/`
- Lógica de dominio en `src/domain/`, sin dependencias de framework

## Comandos
- Build: `npm run build` (ver .vscode/tasks.json)
- Tests: `npm test` o F5 con config "Debug Tests"
```

## *.instructions.md — Scoped

Con frontmatter `applyTo` (glob). Solo aplica cuando el usuario edita ficheros que matchean el patrón.

```markdown
---
applyTo: "**/*.tsx,**/*.test.tsx"
---

# Reglas para componentes React

- Usar Server Components por defecto. Marcar con `'use client'` solo si hace falta hooks de cliente.
- Props: definir como `type Props = { ... }`, nunca como `interface`.
- Tests: usar `@testing-library/react` con `render()` + `screen.findByRole`.
- Evitar `useEffect` para fetching — preferir Server Components o React Query.
```

### Schema del frontmatter

```yaml
---
applyTo: <glob | comma-separated globs>
---
```

Patrones aceptados (sintaxis VS Code):
- `**/*.ts` — todos los .ts
- `src/**/*.tsx` — todos los .tsx bajo src/
- `**/*.{md,mdx}` — múltiples extensiones
- `**/*.test.*` — solo tests
- `tests/**` — todo el árbol tests/

## Buenas prácticas de redacción

1. **Voz imperativa** — "Usar X" en vez de "Se debería usar X"
2. **Específico, no genérico** — "Importar utilidades desde `@/lib/utils`" mejor que "Mantén imports limpios"
3. **Razón cuando ayude** — "Usar Server Components (mejor SEO y bundle)" — pero ser breve
4. **Listas, no párrafos** — Copilot escanea bullets mejor que prosa
5. **Evitar contradicciones** entre el workspace-wide y los scoped
6. **No duplicar lo obvio del lenguaje** — Copilot ya sabe que TypeScript necesita tipos
7. **Documentar SOLO lo no-obvio** — convenciones del repo, no syntax del framework

## Anti-patterns

- ❌ Instrucciones de >1500 caracteres por bloque → Copilot las trunca
- ❌ Reglas contradictorias entre workspace y scoped (gana scoped — orden de carga importa)
- ❌ Secretos / paths absolutos / nombres de personas en los .md
- ❌ Globs demasiado amplios en applyTo (`**/*`) — empuja a usar copilot-instructions.md

## Validaciones aplicables al generar/editar

- ✅ Ficheros .md en `.github/` (workspace-wide) o `.github/instructions/` (scoped)
- ✅ Solo los scoped llevan frontmatter `applyTo`
- ✅ Tamaño total razonable (< 5 KB por fichero para evitar truncado)
- ✅ Sin secrets (regex de detección: cadena > 20 chars con mezcla letras/dígitos/símbolos sin estructura URL)
- ✅ Patrones glob en `applyTo` no apuntan a `node_modules/` o `dist/`

## Procedimiento al crear desde cero

1. **Workspace-wide primero**: crear `.github/copilot-instructions.md` con stack, estructura y convenciones generales.
2. **Scoped después**: si hay reglas que solo aplican a un área (frontend, backend, tests), crear ficheros separados bajo `.github/instructions/`.
3. **Inventariar al final**: listar al usuario los ficheros creados y los globs activos.

## Procedimiento al editar uno existente

1. Leer el fichero actual
2. Identificar la sección a modificar (preservar el resto)
3. Aplicar la edición específica
4. Verificar tamaño total tras editar (< 5 KB recomendado)
5. Si se añadió scope nuevo no cubierto por ningún fichero → crear un nuevo `.instructions.md`

## Mecanismo de descubrimiento de VS Code

VS Code Copilot Chat busca al abrir el workspace:
1. `.github/copilot-instructions.md` → carga siempre
2. `.github/instructions/*.instructions.md` → carga lazy, evalúa `applyTo` por fichero activo

No hace falta declarar nada en `settings.json` — la convención de directorio es suficiente.
