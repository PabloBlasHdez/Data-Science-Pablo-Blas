---
name: fa-iteration-manager
description: >
  Gestiona el estado entre iteraciones del WF1-FA: fingerprint de fuentes,
  tracker de iteraciones, y lógica de reanudación por modo. Garantiza
  trazabilidad inmutable del historial de análisis.
---

# fa-iteration-manager — Gestión de Iteraciones

> **Scope:** Control de estado e iteraciones en WF1-FA
> **Cubre:** fingerprint, iteration-tracker, modos-reanudacion, historico-inmutable
> **No cubre:** contenido funcional de las iteraciones — eso es tarea de los agentes

## Modos de Ejecución del Workflow

El orquestador `fa-run-workflow` acepta cuatro modos en el parámetro `$4`:

| Modo                 | Descripción                                                        | Qué hace                                        |
|----------------------|--------------------------------------------------------------------|-------------------------------------------------|
| `full`               | Análisis completo desde cero                                       | Crea ITER-001 (o incrementa), ejecuta todo      |
| `update-sources`     | Se añadieron fuentes nuevas en input/; re-analizar solo lo nuevo   | Diff de fingerprint → re-ejecuta agentes afectados |
| `reassemble`         | Los RESUMENes están OK; solo re-ensamblar artefactos de output     | Salta FASE 1 y 2, va directo a fa-generate-output |
| `continue-iteration` | Continuación tras resolución de gaps por el operador               | Incrementa ITER-NNN, ejecuta análisis completo con fuentes actualizadas |

## Procedimiento de Fingerprint

El fingerprint detecta si las fuentes cambiaron entre ejecuciones:

```
1. Calcular hash SHA-256 de cada fichero en input/ (recursivo)
2. Ordenar lista de hashes por ruta
3. Hash final = SHA-256 del string concatenado "{ruta}:{hash}\n" por fichero
4. Comparar con fingerprint anterior en resources/source-fingerprint.md
5. Si diferente → fuentes cambiaron → ITER se incrementa
6. Si igual y modo = full → advertir al operador (¿re-analizar fuentes sin cambios?)
```

**Formato de `resources/source-fingerprint.md`:**

```markdown
---
app-id: {APP_ID}
iteration: ITER-NNN
computed-at: YYYY-MM-DDTHH:MM:SSZ
---

# Source Fingerprint — ITER-NNN

## Hash global de input/
sha256:{hash-global}

## Detalle por fichero
| Ruta                                    | SHA-256                          |
|-----------------------------------------|----------------------------------|
| input/docs/BRD-v1.pdf                   | sha256:a1b2c3d4e5f6...           |
| input/docs/HU-sprint3.docx              | sha256:b2c3d4e5f6a7...           |
| input/screens/busqueda-contratos.png    | sha256:c3d4e5f6a7b8...           |
| input/specs/clientes-api.yaml           | sha256:d4e5f6a7b8c9...           |
```

## Formato de `resources/iteration-tracker.md`

El tracker es **inmutable**: nunca se borran iteraciones pasadas, solo se añaden nuevas.

```yaml
---
app-id: {APP_ID}
client-id: {CLIENT_ID}
total-iterations: N
last-iteration: ITER-NNN
status: in-progress | closed
coverage-last: 0.XX
gaps-bloqueantes-abiertos: N
---

## ITER-001
- fecha-inicio: YYYY-MM-DDTHH:MM:SSZ
- modo: full | update-sources | reassemble | continue-iteration
- fuentes-analizadas: [lista de ficheros/fuentes procesadas en esta iteración]
- pantallas-detectadas: N
- gaps-detectados: N (BLOQUEANTE:N, RECOMENDADO:N, INFORMATIVO:N)
- gaps-resueltos: []  # lista de FA-GAP-NNN resueltos en esta iteración
- cobertura-alcanzada: 0.XX
- agentes-ejecutados: [fa-docs-analyzer, fa-ui-analyzer, fa-requirements-analyzer]
- accion-operador: "Descripción de qué hizo el operador para preparar la siguiente iteración"
- fingerprint: sha256:{hash}

## ITER-002
- fecha-inicio: YYYY-MM-DDTHH:MM:SSZ
- modo: continue-iteration
- fuentes-nuevas: [lista de ficheros NUEVOS o MODIFICADOS respecto a ITER-001]
- pantallas-detectadas: N (+N nuevas: SCR-NNN, SCR-MMM)
- gaps-detectados: N (BLOQUEANTE:N, RECOMENDADO:N, INFORMATIVO:N)
- gaps-resueltos: [FA-GAP-001, FA-GAP-002, FA-GAP-003]
- cobertura-alcanzada: 0.XX
- agentes-ejecutados: [fa-docs-analyzer, fa-ui-analyzer, fa-code-analyzer, fa-requirements-analyzer]
- accion-operador: "..."
- fingerprint: sha256:{hash}
```

## Lógica de Reanudación

### Modo `continue-iteration`
1. Calcular fingerprint actual de `input/`
2. Comparar con último fingerprint en `source-fingerprint.md`
3. Identificar ficheros nuevos o modificados
4. Incrementar ITER-NNN (ITER-001 → ITER-002, etc.)
5. Registrar `fuentes-nuevas` en el tracker
6. Ejecutar workflow completo (FASE 1 con fuentes actualizadas)
7. Mantener gaps resueltos del tracker como contexto para los agentes

### Modo `update-sources`
1. Calcular diff de fingerprint
2. Mapear ficheros modificados → agentes afectados (según tabla de tipos)
3. Re-ejecutar solo los agentes afectados
4. Fusionar nuevos RESUMENes con los existentes en `resources/`
5. Re-ejecutar gates y síntesis

### Modo `reassemble`
1. Verificar que todos los RESUMENes existen en `resources/`
2. Si falta algún RESUMEN → error con instrucción de qué modo usar
3. Ejecutar directamente `fa-generate-output`

## Criterios de Cierre de Iteración

Una iteración se considera "lista para operador" cuando:
- Los gates de FASE 1 (cross-validation + coverage) han emitido veredicto
- El informe `operator/iteration-report-ITER-NNN.md` está generado
- El fichero `operator/FA-REQ-NNN/open-questions-ITER-NNN.html` está disponible para todos los FA-REQ con gaps

El operador entonces:
1. Revisa `open-questions-ITER-NNN.html`
2. Obtiene aclaraciones del cliente/PO
3. Actualiza o añade ficheros en `input/`
4. Ejecuta `/fa-run-workflow ... continue-iteration`
