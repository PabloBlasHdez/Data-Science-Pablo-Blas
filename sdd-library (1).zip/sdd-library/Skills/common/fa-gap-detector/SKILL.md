---
name: fa-gap-detector
description: >
  Catálogo completo de tipos de gaps funcionales del WF1-FA. Define los 16 tipos
  de gaps, sus severidades, formatos de registro y criterios de detección.
  Usado por todos los agentes analizadores y gates del workflow.
---

# fa-gap-detector — Catálogo de Gaps Funcionales

> **Scope:** Clasificación y registro de gaps funcionales en análisis WF1-FA
> **Cubre:** tipos-de-gap, severidades, formato-registro, criterios-deteccion
> **No cubre:** resolución de gaps — esa responsabilidad es del operador

## Tipos de Gaps y Severidades

| Tipo ID                    | Nombre                    | Descripción                                                                 | Severidad    |
|----------------------------|---------------------------|-----------------------------------------------------------------------------|--------------|
| `SCREEN-MISSING`           | Pantalla sin descripción  | Pantalla referenciada desde otra pero sin descripción funcional             | BLOQUEANTE   |
| `FLOW-INCOMPLETE`          | Flujo incompleto          | Transición sin condición de entrada/salida definida                        | BLOQUEANTE   |
| `RULE-AMBIGUOUS`           | Regla ambigua             | Regla de negocio vaga o contradictoria entre fuentes                       | BLOQUEANTE   |
| `DATA-UNDEFINED`           | Dato sin definir          | Campo o entidad sin tipo, validaciones o formato                           | RECOMENDADO  |
| `ROLE-UNCLEAR`             | Permiso no claro          | Acción sin rol asignado o rol sin permisos definidos                       | BLOQUEANTE   |
| `INTEGRATION-UNKNOWN`      | Integración desconocida   | Sistema externo sin detalles de API o contrato                            | RECOMENDADO  |
| `DISCREPANCIA-DOC-CODIGO`  | Conflicto doc vs código   | Comportamiento difiere entre código y especificación                       | BLOQUEANTE   |
| `UNDOCUMENTED-FEATURE`     | Funcionalidad sin doc     | Existe en código, sin especificación funcional                            | RECOMENDADO  |
| `UNIMPLEMENTED-SPEC`       | Spec no implementada      | Documentada pero ausente en código                                         | RECOMENDADO  |
| `NFR-MISSING`              | NFR sin especificar       | Requisito no funcional crítico sin especificar                            | RECOMENDADO  |
| `SCOPE-UNCLEAR`            | Alcance no claro          | Dudas sobre si la funcionalidad está en el alcance del proyecto            | INFORMATIVO  |
| `REQ-ORPHAN`               | Requisito huérfano        | FA-REQ sin pantalla ni regla vinculada — sin trazabilidad a ningún artefacto | RECOMENDADO |
| `REQ-WITHOUT-SCREEN`       | Requisito sin pantalla    | FA-REQ confirmado sin SCR asignada                                        | BLOQUEANTE   |
| `REQ-WITHOUT-RULE`         | Requisito sin regla       | FA-REQ funcional sin ninguna BRN asociada                                 | RECOMENDADO  |
| `ARCH-BLOCKER`             | Bloqueante arquitectural  | Decisión técnica externa al equipo funcional que bloquea FA-REQ           | BLOQUEANTE   |
| `REMOTE-CHANNEL-MISSING`   | Canal remoto faltante     | Fuente con `enabled: true` en fa-config.yml sin canal MCP ni fichero .yml | BLOQUEANTE   |
| `REQ-AMBIGUOUS`            | Req. no inequívoco (ISO 29148) | FA-REQ con redacción ambigua: palabras vagas ("podría", "etc."), preguntas sin resolver, valores subjetivos sin métrica | BLOQUEANTE |
| `REQ-INCOMPLETE`           | Req. incompleto (ISO 29148) | FA-REQ sin criterios de aceptación, sin SCR o sin reglas asociadas — falta información crítica | BLOQUEANTE |
| `REQ-INCONSISTENT`         | Req. inconsistente (ISO 29148) | FA-REQ que contradice otro FA-REQ o BRN ya registrado                  | BLOQUEANTE   |
| `REQ-UNVERIFIABLE`         | Req. no verificable (ISO 29148) | FA-REQ sin criterio de aceptación testeable; uso de adjetivos no medibles ("rápido", "fácil", "amigable") sin umbral | BLOQUEANTE |
| `REQ-UNTRACEABLE`          | Req. sin trazabilidad (ISO 29148) | FA-REQ sin origen documentado o sin downstream (SCR/BRN/test)        | BLOQUEANTE   |
| `REQ-INFEASIBLE`           | Req. con duda de viabilidad (ISO 29148) | FA-REQ que requiere validación de arquitecto: depende de integración desconocida o tecnología no confirmada | RECOMENDADO |
| `ASSUMPTION-UNVALIDATED`   | Asunción sin validar (BABOK) | FA-REQ con confianza ASSUMED sin validación explícita del PO (governance.iteration_control) | BLOQUEANTE |

## Escala de Severidades

| Severidad    | Significado                                                             | Impacto en workflow       |
|--------------|-------------------------------------------------------------------------|---------------------------|
| BLOQUEANTE   | Impide avanzar a WF2. Debe resolverse o aceptarse con justificación     | FASE 2 y WF2 bloqueados   |
| RECOMENDADO  | Podría causar decisiones incorrectas en WF2 si no se resuelve           | Avisa al operador; no bloquea |
| INFORMATIVO  | Detalle útil para contexto, no afecta decisiones técnicas               | Solo documentado           |

## Formato de Registro: FA-GAP-NNN

```markdown
## FA-GAP-{NNN}
- tipo: {TIPO_ID}
- severidad: BLOQUEANTE | RECOMENDADO | INFORMATIVO
- iteracion-detectada: ITER-NNN
- pantalla: SCR-NNN (Nombre Pantalla) — omitir si no aplica
- req-vinculados: [FA-REQ-NNN, FA-REQ-MMM]
- descripcion: >
    Descripción detallada del gap. Incluir qué fuentes se contradicen,
    qué está ausente o qué decisión hace falta.
- impacto: Qué no puede determinarse/implementarse hasta resolver este gap.
- accion-requerida: "Acción concreta que debe tomar el operador o el cliente"
- responsable-sugerido: Product Owner | Arquitecto | Operador | Cliente
- estado: ABIERTO | RESUELTO | ACEPTADO
- iteracion-resuelta: — (o ITER-NNN cuando se resuelva)
```

## Formato especial: ARCH-BLOCKER

```markdown
## FA-GAP-{NNN}
- tipo: ARCH-BLOCKER
- severidad: BLOQUEANTE
- requisito: FA-REQ-NNN
- iteracion-detectada: ITER-NNN
- descripcion: >
    El mecanismo/sistema/decisión técnica {nombre} no está confirmado.
    Afecta a {qué requisitos o funcionalidades}.
- fuente: input/docs/{fichero-donde-se-menciona-la-duda}
- impacto: FA-REQ-{NNN} permanece en estado BLOQUEADO hasta resolución.
- accion-requerida: "Confirmar {decisión} con {rol responsable}"
- responsable-sugerido: Arquitecto de solución | Equipo de seguridad | etc.
- estado: ABIERTO
- iteracion-resuelta: —
```

## Criterios de Detección por Agente

### fa-docs-analyzer detecta:
- `RULE-AMBIGUOUS` — cuando dos documentos dan valores/condiciones contradictorias para la misma regla
- `SCREEN-MISSING` — cuando un documento menciona una pantalla sin describirla
- `NFR-MISSING` — cuando un dominio NFR (rendimiento, seguridad, accesibilidad) no tiene ninguna fuente
- `ARCH-BLOCKER` — cuando un documento lista dudas arquitecturales sin resolver

### fa-ui-analyzer detecta:
- `SCREEN-MISSING` — cuando Figma/diseño referencia una pantalla que no existe en el fichero
- `REQ-ORPHAN` — cuando un frame de diseño no puede vincularse a ningún FA-REQ conocido
- `FLOW-INCOMPLETE` — cuando una flecha de navegación no tiene condición o destino definido

### fa-code-analyzer detecta:
- `DISCREPANCIA-DOC-CODIGO` — cuando el comportamiento en código difiere de la documentación
- `UNDOCUMENTED-FEATURE` — cuando existe funcionalidad en código sin ninguna HU o spec asociada
- `UNIMPLEMENTED-SPEC` — cuando una spec documentada no tiene implementación en código

### fa-requirements-analyzer detecta:
- `FLOW-INCOMPLETE` — HU sin criterios de aceptación
- `REQ-WITHOUT-SCREEN` — FA-REQ confirmado que no menciona ninguna pantalla
- `SCOPE-UNCLEAR` — ticket con etiqueta "por confirmar", "fuera de alcance?", etc.

### fa-cross-validation-gate detecta:
- `SCREEN-DISCREPANCY` (→ registrar como `DISCREPANCIA-DOC-CODIGO`) — pantallas en UI no en docs o viceversa
- `ROLE-UNCLEAR` — roles mencionados en permisos pero no en HU o viceversa
- `INTEGRATION-UNKNOWN` — integraciones en docs sin contratos disponibles

### fa-functional-synthesizer detecta (FASE 2):
- `REQ-ORPHAN` — FA-REQ sin pantalla ni regla tras consolidar todos los RESUMENes
- `REQ-WITHOUT-RULE` — FA-REQ funcional sin ninguna BRN detectada
- `DATA-UNDEFINED` — entidades con campos sin tipo o validaciones

## Gestión del fichero open-gaps.md

El fichero `resources/open-gaps.md` es el registro central de todos los gaps activos.

**Cabecera del fichero:**
```markdown
---
app-id: {APP_ID}
last-updated: YYYY-MM-DDTHH:MM:SSZ
total-gaps: N
bloqueantes-abiertos: N
recomendados-abiertos: N
---

# Gaps Funcionales Abiertos — {APP_ID}

## BLOQUEANTES ({N})
[listar FA-GAP-NNN de severidad BLOQUEANTE con estado ABIERTO]

## RECOMENDADOS ({N})
[listar FA-GAP-NNN de severidad RECOMENDADO con estado ABIERTO]

## INFORMATIVOS ({N})
[listar FA-GAP-NNN de severidad INFORMATIVO con estado ABIERTO]

## Resueltos / Aceptados ({N})
[listar FA-GAP-NNN con estado RESUELTO o ACEPTADO — no eliminar del fichero]
```

**Reglas de actualización:**
- Nunca eliminar gaps; solo cambiar estado a RESUELTO o ACEPTADO
- Actualizar `iteracion-resuelta` al resolver
- Los gaps ACEPTADO deben incluir `justificacion-aceptacion` con quién la aprobó
