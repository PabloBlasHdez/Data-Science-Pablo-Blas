---
name: ft-push-test-to-git
description: >
  Skill compartida por ft-frontend-runner y ft-backend-runner.
  Verifica si el directorio de tests generados puede subirse a Git y realiza el push.
  Detecta si ya existe un repositorio remoto configurado; si no, solicita el nombre del repo
  o las credenciales de GitHub para crearlo o vincularlo.
  Usa git CLI + MCP de GitHub cuando esté disponible.
metadata:
  author: "GitHub Copilot"
  version: "1.0"
  category: "testing"
---

# Push Tests to Git — Skill compartida (Runner Agents)

Skill para verificar el estado Git del directorio de tests generados y subir el código
al repositorio remoto. Compartida por `frontend-runner-agent` y `backend-runner-agent`.

---

## Cuándo usar este skill

- Al terminar la ejecución de tests, antes de cerrar el pipeline de QA
- El usuario dice "sube los tests a git", "commitea los tests", "push al repo", "quiero versionar los tests"
- El usuario quiere dejar trazabilidad de los scripts de test en el repositorio

---

## Workflow de Ejecución

### PASO 1 — Verificar estado Git del directorio de tests

Ejecuta en el directorio de tests:

```bash
git -C "<ruta-tests>" rev-parse --is-inside-work-tree
```

| Resultado | Acción |
|---|---|
| `true` | El directorio ya pertenece a un repo Git. Ir al **Paso 2**. |
| Error / `false` | No hay repo Git. Ir al **Paso 1b**. |

#### Paso 1b — Inicializar repositorio local

```bash
git -C "<ruta-tests>" init
git -C "<ruta-tests>" add .
git -C "<ruta-tests>" commit -m "feat(tests): add generated QA test scripts"
```

---

### PASO 2 — Verificar remote configurado

```bash
git -C "<ruta-tests>" remote get-url origin
```

| Resultado | Acción |
|---|---|
| URL devuelta | Remote ya configurado. Ir al **Paso 4**. |
| Error (no remote) | Solicitar datos al usuario. Ir al **Paso 3**. |

---

### PASO 3 — Recopilar datos del repositorio remoto

Pregunta al usuario con `vscode_askQuestions` **solo lo que falte**:

```
Para subir los tests a GitHub necesito:
1. URL del repositorio remoto
   (ej: https://github.com/org/repo.git  o  git@github.com:org/repo.git)
2. Rama destino (por defecto: "main")
3. ¿Tienes el remote ya creado en GitHub?
   · Sí, ya existe → usamos la URL directamente
   · No, créalo tú → necesito: organización/usuario, nombre del repo, visibilidad (público/privado)
```

#### Paso 3a — Crear repo remoto (si no existe)

Si el usuario pide crearlo, usa el MCP de GitHub si está disponible:

```
Herramienta: github MCP → create_repository
  · name:        <nombre indicado por el usuario>
  · owner:       <org o usuario indicado>
  · private:     true (por defecto, salvo que el usuario indique público)
  · description: "QA test scripts — generados automáticamente por GitHub Copilot"
```

Si el MCP de GitHub no está disponible, indica al usuario los pasos manuales:
```
Crea el repositorio en https://github.com/new y proporciona la URL resultante.
```

#### Paso 3b — Vincular remote

```bash
git -C "<ruta-tests>" remote add origin <url-remota>
```

---

### PASO 4 — Verificar credenciales

Ejecuta un dry-run para comprobar acceso:

```bash
git -C "<ruta-tests>" ls-remote origin
```

| Resultado | Acción |
|---|---|
| Éxito (lista de refs) | Credenciales OK. Ir al **Paso 5**. |
| Error de autenticación | Solicitar credenciales. Ver abajo. |

#### Gestión de credenciales

Si falla por autenticación, pregunta al usuario:

```
La autenticación con GitHub ha fallado. ¿Cómo quieres autenticarte?

1. Token de acceso personal (PAT) — recomendado
   Proporciona tu PAT y lo configuro como credencial para esta sesión.
2. SSH — ya tengo clave SSH configurada
   Verificamos que la clave está activa.
3. GitHub CLI (gh auth login) — te guío para autenticarte.
```

Para PAT, configura la URL con credencial embebida temporalmente:
```bash
git -C "<ruta-tests>" remote set-url origin https://<PAT>@github.com/<org>/<repo>.git
```

> ⚠️ **Seguridad**: nunca almacenes el PAT en ficheros del repositorio ni en el historial de commits.
> Tras el push, restaura la URL limpia:
> ```bash
> git -C "<ruta-tests>" remote set-url origin https://github.com/<org>/<repo>.git
> ```

---

### PASO 5 — Preparar y ejecutar el push

#### Comprobar rama activa y cambios pendientes

```bash
git -C "<ruta-tests>" status --short
git -C "<ruta-tests>" branch --show-current
```

#### Stage y commit (si hay cambios sin commitear)

```bash
git -C "<ruta-tests>" add .
git -C "<ruta-tests>" commit -m "feat(tests): update generated QA test scripts [$(date +%Y-%m-%d)]"
```

Si no hay cambios, informa al usuario: `"No hay cambios nuevos respecto al último commit."` y finaliza.

#### Push

```bash
git -C "<ruta-tests>" push -u origin <rama>
```

---

### PASO 6 — Output

Al finalizar presenta el resumen:

```
✅ Tests subidos a GitHub correctamente

🔗 Repositorio: <url-remota>
🌿 Rama:        <rama>
📦 Commit:      <hash corto> — <mensaje>
📁 Ficheros:    X ficheros subidos

[Si se creó el repo]  👉 https://github.com/<org>/<repo>
```

Si el push falla, muestra el error completo y sugiere la acción correctiva concreta.

---

## Reglas

- **No almacenes credenciales en disco ni en ficheros del repo.**
- **No hagas `git push --force`** salvo que el usuario lo solicite explícitamente y confirme.
- Si el repo ya tiene commits remotos y hay divergencia, informa al usuario y ofrece:
  - `git pull --rebase` antes del push
  - o crear una nueva rama con los tests
- Gestiona el progreso con `manage_todo_list`.
