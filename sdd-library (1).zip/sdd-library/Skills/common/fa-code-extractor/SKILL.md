---
name: fa-code-extractor
description: >
  Patrones y reglas para extraer funcionalidad existente del código fuente en
  proyectos de migración, modificación e incidencias. Detecta pantallas, rutas,
  entidades, reglas de negocio y código muerto funcional. Aplica política de
  discrepancia código vs documentación.
---

# fa-code-extractor — Extracción de Código Fuente

> **Scope:** Extracción funcional de código fuente en WF1-FA
> **Cubre:** patrones-por-tecnologia, deteccion-codigo-muerto, politica-discrepancia, extraccion-rutas
> **No cubre:** análisis de calidad técnica — eso es WF2; documentos de texto — ver fa-docs-extractor

## Activación

Este skill solo se aplica cuando `project.type ∈ {migration, modification, incident}`.
Para `project.type = new`: no existe código fuente que analizar.

## Patrones de Detección por Tecnología

### Frontend Web (JSP, Thymeleaf, FreeMarker, Angular, React, Vue)

```
Ficheros a buscar (prioridad alta):
  *.jsp, *.jspx          → pantallas JSP Metrópolis/Java EE
  *.html + @Component    → componentes Angular
  *.tsx, *.jsx           → componentes React
  *.vue                  → componentes Vue
  *.cshtml               → vistas Razor .NET
  *.ftl                  → plantillas FreeMarker
  *.html (templates)     → plantillas Thymeleaf

Por cada fichero de vista:
  - Nombre funcional deducido del título/nombre del fichero
  - Campos de formulario: <input name="X">, [(ngModel)]="X", v-model="X"
  - Botones y acciones: <button>, click handlers, submit handlers
  - Rutas de navegación: href, routerLink, [routerLink], navigate()
  - Roles: *ngIf="hasRole('X')", v-if="role === 'X'", [Authorize(Roles="X")]
  - Código muerto: rendered="false", [hidden]="true", v-show="false", disabled flags
```

### Backend — Controladores y Rutas

```
Ficheros a buscar:
  *Controller.java, *Action.java, *Servlet.java  → endpoints Java
  *Controller.cs, *ApiController.cs              → endpoints .NET
  *.py con @app.route, @router                   → endpoints Python
  routes/*.ts, router/*.ts                       → rutas Node/Express/Angular

Por cada controlador:
  - Rutas expuestas (@RequestMapping, [Route], app.route)
  - Métodos HTTP (GET, POST, PUT, DELETE)
  - Parámetros de entrada
  - Vista devuelta (return "nombre-vista", return View("nombre"))
  - Servicios invocados
```

### Backend — Lógica de Negocio

```
Ficheros a buscar:
  *Service.java, *ServiceImpl.java  → servicios de negocio
  *Manager.java, *Handler.java      → gestores
  *Validator.java                   → validaciones
  *Rules.java, *Policy.java         → reglas explícitas

Por cada método de negocio relevante:
  - Regla que implementa (if/switch/validación)
  - Valores hardcoded con semántica de negocio (umbrales, límites, estados)
  - Llamadas a sistemas externos (HTTP clients, RMI, SOAP)
  - Condiciones de negocio en queries (WHERE status = 'ACTIVO', etc.)
```

### Backend — Entidades y Esquema

```
Ficheros a buscar:
  *Entity.java, *Model.java, @Entity  → entidades JPA
  *.cs con [Table], DbSet<X>          → entidades EF .NET
  *.sql, *.ddl                        → schemas SQL
  *.json schema, *.yaml (OpenAPI)     → schemas documentados

Por cada entidad:
  - Nombre de la clase/tabla → nombre funcional
  - Campos/columnas con tipo
  - Constraints: NOT NULL, UNIQUE, FK
  - Validaciones en anotaciones: @NotNull, @Size, @Min, @Max
```

## Detección de Código Muerto Funcional

**Tipos de código muerto a detectar:**

| Patrón                         | Ejemplo                              | Tipo registrado          |
|--------------------------------|--------------------------------------|--------------------------|
| `rendered="false"` en JSP      | `<cg:panel rendered="false">`        | Vista desactivada        |
| Feature flag desactivado       | `if (FeatureFlags.NEW_FLOW == false)` | Funcionalidad desactivada|
| `@Deprecated` en controller    | `@Deprecated class LegacyController` | Endpoint obsoleto        |
| Comentario "deprecated" / "old"| `// deprecated, usar NuevaClase`     | Código a revisar         |
| Servlet sin mapeo en web.xml   | Clase Servlet sin url-pattern        | Endpoint huérfano        |
| Ruta sin vista asociada        | Controller que devuelve vista inexistente | Ruta rota           |
| Vista sin ruta que la invoque  | .jsp sin ningún controller que la use | Pantalla huérfana       |

**Regla fundamental de código muerto:**
> El operador SIEMPRE decide si el código muerto debe migrarse o no.
> El agente lo detecta, lo documenta y lo presenta. NUNCA lo excluye automáticamente.
> NUNCA marcar automáticamente como "no migrar".

## Política de Discrepancia Código vs Documentación

Aplicable para `project.type ∈ {migration, modification}`.

| Tipo de discrepancia             | Fuente ganadora | Acción                                                    |
|----------------------------------|-----------------|-----------------------------------------------------------|
| Comportamiento real de la app    | Código fuente   | Documentar como comportamiento real actual                |
| Intención de negocio             | Documentación   | Documentar como objetivo del requisito                    |
| Funcionalidad en código, sin doc | Código fuente   | FA-GAP `UNDOCUMENTED-FEATURE` → FA-REQ candidato          |
| Spec documentada, sin código     | Documentación   | FA-GAP `UNIMPLEMENTED-SPEC` → operador confirma FA-REQ    |
| Regla contradictoria código≠doc  | Ambiguo         | FA-GAP `DISCREPANCIA-DOC-CODIGO` — BLOQUEANTE → FA-REQ bloqueado |

**Ejemplo de discrepancia:**
```
Código: if (importe < 100) throw ValidationException("Mínimo 100€")
BRD sección 4.2: "El importe mínimo es 50€"
→ DISCREPANCIA-DOC-CODIGO — BLOQUEANTE
→ No registrar ni el valor del código ni el de la doc como correcto
→ Registrar ambos con la contradicción en FA-GAP
```

## Alcance de Análisis por project.type

| project.type   | Alcance de análisis                                      |
|----------------|----------------------------------------------------------|
| `migration`    | Análisis completo del código fuente — toda la aplicación |
| `modification` | Análisis limitado al área modificada (ficheros afectados)|
| `incident`     | Análisis de diagnóstico — área afectada + código relacionado |

Para `modification` e `incident`, el operador debe indicar el área de impacto.
Si no se indica, analizar el área deducible del ticket/HU vinculada.

## Integración con fa-docs-extractor

Al detectar comportamiento en código:
1. Buscar en los RESUMENes de docs si está documentado
2. Si coincide → CONFIRMED (fuente doble)
3. Si difiere → FA-GAP DISCREPANCIA-DOC-CODIGO
4. Si no está documentado → FA-GAP UNDOCUMENTED-FEATURE

Esta validación cruzada es responsabilidad de `fa-cross-validation-gate`,
pero el agente debe marcar los casos detectados en su RESUMEN para que el gate los evalúe.
