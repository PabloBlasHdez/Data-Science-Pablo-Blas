---
name: fa-ui-extractor
description: >
  Patrones y reglas para extraer inventario funcional de imágenes: capturas de
  pantalla, wireframes, exportaciones de Figma/Sketch/XD y diagramas SVG.
  Usa la capacidad multimodal de Claude para leer imágenes directamente.
---

# fa-ui-extractor — Extracción de Imágenes y Diseños

> **Scope:** Extracción funcional de imágenes de diseño e interfaz en WF1-FA
> **Cubre:** lectura-multimodal, extraccion-pantallas-visuales, estados-ui, flujos-visuales
> **No cubre:** documentos de texto — ver fa-docs-extractor; diagramas .drawio — ver drawio-extractor

## Capacidad Multimodal

`fa-ui-analyzer` usa la capacidad multimodal de Claude para leer imágenes directamente
con la herramienta `Read(path)`. No se convierte la imagen a texto antes — Claude
interpreta el contenido visual.

**Formatos soportados:** PNG, JPG, GIF, SVG, PDF (exportaciones de diseño)

**Limitación por APP_SIZE:**
- `small` → procesar todas las imágenes en un lote
- `medium` → máximo 10 imágenes por llamada
- `large` → **máximo 5 imágenes por llamada** (respetar este límite siempre)

## Campos a Extraer por Pantalla Visual

Por cada imagen que muestre una pantalla o vista de la aplicación:

```
Campos obligatorios:
  nombre-funcional: Nombre descriptivo deducido del contenido visual
                    (no usar nombre del fichero como nombre funcional)
  elementos-ui:    Lista de elementos interactivos y de visualización visibles:
                   - inputs: tipo (text, date, select, checkbox, radio)
                   - botones: etiqueta visible del botón
                   - tablas: columnas visibles y datos de ejemplo
                   - paneles: qué información contienen
                   - tabs/pestañas: nombres de las pestañas
                   - mensajes: textos de error/éxito/info visibles
  textos-visibles: Títulos, etiquetas de campos, textos de botones, mensajes
                   (transcribir el texto exacto visible en la imagen)
  estados:         Estado visible en la imagen:
                   - vacío (sin datos cargados)
                   - con-datos (tabla o campos con datos de ejemplo)
                   - error (mensaje de error visible)
                   - cargando (spinner o skeleton visible)
                   - deshabilitado (campos o botones grayed-out)
  acciones:        Acciones que el usuario puede realizar en esta pantalla
                   (deducir de botones, menús, íconos de acción visibles)

Campos opcionales:
  roles-visibles:  Indicaciones visuales de rol (ej: btn visible solo en modo admin)
  pantallas-origen: Si hay breadcrumbs o navegación que indica de dónde se viene
  pantallas-destino: Si hay flechas o conectores que muestran a dónde se navega
  notas-diseño:   Anotaciones del diseñador visibles en la imagen
```

## Clasificación de Tipos de Imagen

| Tipo visual                  | Estrategia de extracción               | FA-REQ producido |
|------------------------------|----------------------------------------|------------------|
| Captura de pantalla real     | Extraer estado actual de la aplicación | INFERRED         |
| Wireframe / mockup           | Extraer estructura y flujo intencional | INFERRED         |
| Frame Figma con nombres      | Usar nombre del frame como nombre SCR  | INFERRED → CONFIRMED si coincide con doc |
| Diagrama de flujo (imagen)   | Extraer estados y transiciones         | INFERRED         |
| Prototipo navegable (export) | Tratar cada frame como pantalla        | INFERRED         |

## Detección de Permisos Visuales

Indicadores visuales de que un elemento está restringido por rol:
- Botón aparece en gris / deshabilitado en una variante de la pantalla
- Elemento presente en "vista ADMIN" y ausente en "vista USER"
- Anotación en el diseño: "solo SUPERVISOR", "solo admin", etc.
- Lock icon junto a un elemento
- Pantalla marcada con un rol específico en el nombre del frame Figma

Si se detecta restricción visual → registrar como permiso con confianza INFERRED.

## Detección de Código Muerto Funcional (pantallas desactivadas)

En exportaciones de Figma o aplicaciones legacy:
- Frame marcado con "DEPRECATED", "OLD", "DO NOT USE"
- Pantalla con comentario de diseñador "no implementar" o "desactivado"
- En screenshots: pantalla con banner "DESACTIVADO" o acceso bloqueado

**Regla de código muerto funcional:**
El operador SIEMPRE decide si una pantalla desactivada debe migrarse o no.
El agente la marca como `estado: CÓDIGO MUERTO FUNCIONAL` y la incluye en el
FA-CODE-RESUMEN con la sección de código muerto, pero NUNCA la excluye automáticamente.

## Manejo de Exportaciones Figma (PDF multi-frame)

Cuando `input/screens/` contiene un PDF exportado de Figma:
1. Cada página del PDF es potencialmente una pantalla o un frame de diseño
2. Usar nombre de la sección/página del PDF como nombre candidato de SCR
3. Si el PDF tiene índice → usar nombres del índice
4. Conectar frames relacionados en el campo `pantallas-destino`

## Vinculación a FA-REQ

**Toda pantalla visual detectada debe vincularse a al menos un FA-REQ candidato.**
Si no es posible vincular (no hay HU conocida, no hay doc relacionada):
→ Registrar como `FA-GAP tipo REQ-ORPHAN` para que el operador asigne en la siguiente iteración.
→ No inventar un FA-REQ para cubrir la pantalla huérfana.

## Extracción de Flujos de Navegación desde Imágenes

Si la imagen muestra flechas o conectores entre pantallas:
- Registrar como `NAV-NNN` con origen, destino y condición (texto de la flecha si existe)
- Si la flecha no tiene etiqueta → condición = "desconocida" → FA-GAP FLOW-INCOMPLETE
- Si hay múltiples destinos desde un estado → registrar cada flecha como transición separada
