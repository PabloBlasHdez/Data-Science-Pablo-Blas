---
name:       "requirements-governance"
scope:      "Gobernanza de requisitos SDD — BABOK v3 + ISO/IEC/IEEE 29148:2018"
covers:     [principios BABOK v3, 6 atributos de calidad ISO 29148, mapeo atributo→gap_type,
             clasificación CONFIRMED/INFERRED/ASSUMED, trazabilidad bidireccional,
             gestión de gaps, validación requerida, criterios de cierre, control de iteración]
not-covers: [reglas/terminología de cliente — ver Skills/clients/{CLIENT_ID}/...,
             taxonomía de checks de seguridad SEC-* — ver fa-security-rules,
             lógica de ejecución de gates — vive en Agents/gates/*.agent.md]
version:    "1.0"
---

# Requirements Governance — referencia de política

Política **global y declarativa** de gobernanza de requisitos para el pipeline SDD.
Es **conocimiento consultable, no instrucciones de acción**: los gates y skills la
referencian para decidir veredictos; no contiene lógica de ejecución.

Sustituye al antiguo fichero `fa-governance.yml`. Cualquier agente que necesite estas
reglas lo declara en su frontmatter como `skills: [common/requirements-governance]`.
Al resolverse como skill normal, su ausencia ya **no** produce un ERROR BLOQUEANTE de
ruta fija; el orquestador lo carga como cualquier otro Common Skill.

## Qué cubre y qué NO

| Cubre | No cubre |
|:------|:---------|
| Principios BABOK v3 aplicables a todo FA-REQ | Nomenclatura/terminología de cada cliente → Client Skill |
| 6 atributos de calidad ISO/IEC/IEEE 29148:2018 y su mapeo a gaps | Heurísticas SEC-01..SEC-07 de seguridad → `fa-security-rules` |
| Reglas de clasificación de confianza | Umbrales de cobertura por proyecto → `fa-config.yml` (`coverage-threshold`) |
| Política de trazabilidad, gaps, validación y cierre | Implementación de los gates → `Agents/gates/*.agent.md` |

## 1. Principios (BABOK v3)

| Principio | Regla verificable |
|:----------|:------------------|
| `stakeholder_centricity` | Cada FA-REQ referencia al menos un stakeholder origen |
| `business_value` | Cada FA-REQ declara el valor de negocio que aporta |

## 2. Clasificación de confianza

| Nivel | Condición | `requires_validation` | Efecto |
|:------|:----------|:----------------------|:-------|
| `CONFIRMED` | ≥2 fuentes O 1 fuente primaria | no | Sin gap |
| `INFERRED` | 1 fuente única | sí | Genera FA-GAP de validación |
| `ASSUMED` | Sin evidencia | mandatory | Genera FA-GAP **BLOQUEANTE** (`ASSUMPTION-UNVALIDATED`) |

## 3. Atributos de calidad obligatorios (ISO/IEC/IEEE 29148:2018)

Cada FA-REQ se verifica contra los 6 atributos. Cada atributo fallado emite el `gap_type`
indicado con su severidad por defecto.

| Atributo | Verifica | gap_type | Severidad |
|:---------|:---------|:---------|:----------|
| `unambiguous` | Sin palabras vagas ni preguntas abiertas | `REQ-AMBIGUOUS` | BLOQUEANTE |
| `complete` | Criterios de aceptación, descripción y origen | `REQ-INCOMPLETE` | BLOQUEANTE |
| `consistent` | No contradice otro FA-REQ ni BRN vinculada | `REQ-INCONSISTENT` | BLOQUEANTE |
| `verifiable` | Sin adjetivos subjetivos; umbrales numéricos en NFR | `REQ-UNVERIFIABLE` | BLOQUEANTE |
| `traceable` | Tiene origen Y downstream (SCR/BRN/test) | `REQ-UNTRACEABLE` | BLOQUEANTE |
| `feasible` | Sin dependencias ASSUMED; tecnología en target-context | `REQ-INFEASIBLE` | RECOMENDADO |

> Los FA-GAP de calidad llevan el campo `iso_attribute` para auditoría inversa.

## 4. Trazabilidad bidireccional

Obligatoria para todo FA-REQ:

- **Origen (upstream):** `stakeholder_need` / `business_requirement`.
- **Downstream:** `system_component` / `test_case`.

`fa-closure-gate` verifica que la trazabilidad bidireccional esté completa antes de cerrar.

## 5. Gestión de gaps

| Regla | Valor |
|:------|:------|
| `blocking_gaps_prevent_progress` | `true` — gaps BLOQUEANTES paran CV/Coverage/Security/Cierre |
| `assumed_requirements_generate_gap` | `true` — cada FA-REQ ASSUMED genera `ASSUMPTION-UNVALIDATED` |

## 6. Validación requerida (antes del cierre)

Requieren validación explícita del PO/business_owner:
`inferred_requirements`, `assumed_requirements`, `critical_flows`, `business_rules`.
`fa-closure-gate` solicita firma del operador con checklist por categoría.

## 7. Criterios de cierre (`completion_criteria`)

Usados por `fa-closure-gate` como criterios automáticos:

- `all_requirements_classified` (CONFIRMED/INFERRED/ASSUMED)
- `all_requirements_have_traceability` (bidireccional)
- `no_blocking_gaps` (severidad BLOQUEANTE = 0)
- `all_requirements_meet_quality_attributes` (6 atributos ISO 29148)
- `deliverables_complete` (requirements-registry + business-rules + navigation)

## 8. Control de iteración

| Parámetro | Valor | Efecto |
|:----------|:------|:-------|
| `max_unvalidated_requirements_allowed` | `0` | Al cierre no puede quedar ningún INFERRED/ASSUMED sin validación; `fa-closure-gate` bloquea hasta resolución |

## 9. Política de seguridad (`security_requirements`)

Política que consume `fa-security-gate`; la **taxonomía de checks SEC-01..SEC-07 vive en
`fa-security-rules`**, no aquí.

| Política | Regla |
|:---------|:------|
| `sensitive_actions` | CRUD, baja, exportación e impresión exigen rol explícito |
| `read_write_separation` | El acceso de consulta se distingue del de escritura |
| `audit_critical_actions` | Las acciones críticas requieren registro de auditoría coherente |
| `permission_target_mapping` | Cada permiso del origen mapea de forma clara al stack target |

## 10. Overrides por proyecto

Un proyecto puede relajar políticas declarando `governance-overrides` en su `fa-config.yml`
(ej: `skip_quality_attributes: [feasible]` en discovery/incident). El merge entre esta
política global y los overrides del proyecto se persiste en
`resources/governance-effective.md` para trazabilidad. La política base (este skill) no se
edita por proyecto.

## Política canónica (forma declarativa)

```yaml
principles:
  - stakeholder_centricity
  - business_value

requirements_classification:
  confidence_level:
    CONFIRMED: { sources: ">=2 OR primary", requires_validation: false }
    INFERRED:  { sources: "1", requires_validation: true }
    ASSUMED:   { sources: "0", requires_validation: mandatory, gap: ASSUMPTION-UNVALIDATED, severity: BLOQUEANTE }

requirements_quality:
  mandatory_attributes:
    unambiguous: { gap_type: REQ-AMBIGUOUS,    severity: BLOQUEANTE }
    complete:    { gap_type: REQ-INCOMPLETE,   severity: BLOQUEANTE }
    consistent:  { gap_type: REQ-INCONSISTENT, severity: BLOQUEANTE }
    verifiable:  { gap_type: REQ-UNVERIFIABLE, severity: BLOQUEANTE }
    traceable:   { gap_type: REQ-UNTRACEABLE,  severity: BLOQUEANTE }
    feasible:    { gap_type: REQ-INFEASIBLE,   severity: RECOMENDADO }

traceability:
  bidirectional: true
  upstream:   [stakeholder_need, business_requirement]
  downstream: [system_component, test_case]

gap_management:
  rules:
    blocking_gaps_prevent_progress: true
    assumed_requirements_generate_gap: true

validation:
  required_for: [inferred_requirements, assumed_requirements, critical_flows, business_rules]

completion_criteria:
  - all_requirements_classified
  - all_requirements_have_traceability
  - no_blocking_gaps
  - all_requirements_meet_quality_attributes
  - deliverables_complete

governance:
  iteration_control:
    max_unvalidated_requirements_allowed: 0

security_requirements:
  sensitive_actions: [create, update, delete, export, print]
  read_write_separation: true
  audit_critical_actions: true
  permission_target_mapping: required
```
