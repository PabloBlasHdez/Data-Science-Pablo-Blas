# Plantillas Canónicas de RESUMENes — WF1 Functional Analysis

Estas plantillas definen la estructura de salida estándar que cada subagente analizador
debe producir en `resources/`. El orquestador y los gates dependen de esta estructura.

---

## Plantilla 1 — FA-DOCS-RESUMEN (fa-docs-analyzer)

```markdown
━━━ INICIO FA-DOCS-RESUMEN ━━━

## FA-DOCS-RESUMEN
- agente: fa-docs-analyzer
- iteracion: ITER-NNN
- timestamp: YYYY-MM-DDTHH:MM:SSZ
- fuentes-procesadas: [lista de ficheros leídos con ruta relativa]

### Universo detectado
| Tipo       | Patrón                          | Cantidad | IDs clave            |
|------------|---------------------------------|----------|----------------------|
| Documentos | BRD, HU, emails, actas, manuales| N        | doc-001, doc-002...  |
| Pantallas  | Mencionadas en texto            | N        | SCR-NNN candidatos   |
| Reglas     | Extraídas de texto              | N        | BRN-NNN candidatos   |
| Entidades  | Mencionadas en texto            | N        | ENT-NNN candidatos   |

### Requisitos funcionales detectados
| ID         | Descripción breve                    | Origen       | Tipo     | Confianza |
|------------|--------------------------------------|--------------|----------|-----------|
| FA-REQ-001 | Búsqueda de contratos por cliente    | BRD sec 3.1  | DIRECTO  | CONFIRMED |
| FA-REQ-002 | Exportar resultados a Excel          | HU-023 Jira  | DIRECTO  | CONFIRMED |
| FA-REQ-003 | Validación mínimo importe 100€       | Acta PO 05/20| ASUMIDO  | ASSUMED   |

### Pantallas / Vistas identificadas
| ID      | Nombre                     | FA-REQ vinculados       | Fuente        | Confianza |
|---------|----------------------------|-------------------------|---------------|-----------|
| SCR-001 | Búsqueda de Contratos      | FA-REQ-001, FA-REQ-002  | BRD sec 3.1   | CONFIRMED |
| SCR-002 | Detalle de Contrato        | FA-REQ-001              | Manual usuario| INFERRED  |

### Reglas de negocio detectadas
| ID      | Pantalla | FA-REQ vinculado | Descripción                          | Fuente       | Confianza |
|---------|----------|------------------|--------------------------------------|--------------|-----------|
| BRN-001 | SCR-001  | FA-REQ-001       | Cliente siempre obligatorio en filtro| BRD sec 3.1  | CONFIRMED |
| BRN-002 | SCR-003  | FA-REQ-003       | Importe mínimo 100€ (en disputa)     | Acta vs BRD  | ASSUMED   |

### Entidades funcionales detectadas
| ID      | Nombre    | FA-REQ vinculados      | Campos principales              | Fuente      | Confianza |
|---------|-----------|------------------------|---------------------------------|-------------|-----------|
| ENT-001 | Contrato  | FA-REQ-001, FA-REQ-002 | id, cliente, fecha, estado, tipo| BRD sec 2.1 | CONFIRMED |
| ENT-002 | Cliente   | FA-REQ-001             | id, nombre, nif, email          | BRD sec 2.2 | CONFIRMED |

### Flujos de navegación detectados
| ID      | Origen  | Destino | Condición                    | FA-REQ vinculado | Fuente    |
|---------|---------|---------|------------------------------|------------------|-----------|
| NAV-001 | SCR-001 | SCR-002 | Click en fila de resultado   | FA-REQ-001       | BRD sec 3 |
| NAV-002 | SCR-001 | SCR-008 | Click "Nueva solicitud"      | FA-REQ-004       | HU-015    |

### Roles y permisos detectados
| ID      | Nombre     | Acciones permitidas              | FA-REQ vinculados | Fuente    |
|---------|------------|----------------------------------|-------------------|-----------|
| ROL-001 | GESTOR     | buscar, ver-detalle              | FA-REQ-001        | BRD sec 5 |
| ROL-002 | SUPERVISOR | buscar, ver-detalle, exportar    | FA-REQ-001, FA-REQ-002 | BRD sec 5 |
| ROL-003 | ADMIN      | todo                             | todos             | BRD sec 5 |

### Integraciones externas detectadas
| ID      | Sistema externo | Tipo          | FA-REQ vinculados | Detalles conocidos   | Confianza |
|---------|----------------|---------------|-------------------|----------------------|-----------|
| INT-001 | SAP Facturación | Consulta      | FA-REQ-005        | API desconocida      | ASSUMED   |

### Requisitos no funcionales detectados
| ID       | Categoría    | Descripción                      | Fuente      | Confianza |
|----------|--------------|----------------------------------|-------------|-----------|
| NFR-001  | Rendimiento  | Resultados en < 3 seg            | BRD sec 6.1 | CONFIRMED |
| NFR-002  | Seguridad    | RBAC obligatorio todas pantallas | BRD sec 6.2 | CONFIRMED |

### Checklist de reglas cliente aplicadas
- [ ] Nomenclatura funcional cliente aplicada (IDs, alias de roles)
- [ ] Exclusiones de alcance verificadas (Fase 2, DEPRECATED)
- [ ] Jerarquía de confianza de fuentes aplicada
- [ ] Restricciones de privacidad aplicadas (NIF/CIF enmascarados)

### Bloqueados / Gaps detectados
| ID          | Tipo                   | Severidad    | FA-REQ afectado | Descripción breve                          |
|-------------|------------------------|--------------|-----------------|--------------------------------------------|
| FA-GAP-001  | RULE-AMBIGUOUS         | BLOQUEANTE   | FA-REQ-003      | HU-023 dice 100€, BRD dice 50€            |
| FA-GAP-002  | SCREEN-MISSING         | BLOQUEANTE   | FA-REQ-006      | Pantalla confirmación alta sin descripción |
| FA-GAP-003  | INTEGRATION-UNKNOWN    | RECOMENDADO  | FA-REQ-005      | API SAP sin contrato ni URL conocida       |

━━━ FIN FA-DOCS-RESUMEN ━━━
```

---

## Plantilla 2 — FA-UI-RESUMEN (fa-ui-analyzer)

```markdown
━━━ INICIO FA-UI-RESUMEN ━━━

## FA-UI-RESUMEN
- agente: fa-ui-analyzer
- iteracion: ITER-NNN
- timestamp: YYYY-MM-DDTHH:MM:SSZ
- fuentes-procesadas: [lista de imágenes/exportaciones procesadas]

### Universo detectado
| Tipo      | Patrón                              | Cantidad | IDs clave           |
|-----------|-------------------------------------|----------|---------------------|
| Imágenes  | Screenshots, wireframes, exportes   | N        | pantallas analizadas |
| Pantallas | Identificadas visualmente           | N        | SCR-NNN candidatos  |
| Flujos    | Conexiones detectadas entre frames  | N        | NAV-NNN candidatos  |

### Requisitos funcionales detectados
| ID         | Descripción breve                 | Origen          | Tipo     | Confianza |
|------------|-----------------------------------|-----------------|----------|-----------|
| FA-REQ-001 | Pantalla de búsqueda con filtros  | figma-frame-003 | INFERRED | INFERRED  |

### Pantallas / Vistas identificadas
| ID      | Nombre                  | FA-REQ vinculados | Fuente               | Confianza | Elementos UI principales               |
|---------|-------------------------|-------------------|----------------------|-----------|----------------------------------------|
| SCR-001 | Búsqueda de Contratos   | FA-REQ-001        | figma-v2 frame 3     | CONFIRMED | input:cliente, input:fecha, tabla-resultados, btn:buscar, btn:exportar |
| SCR-002 | Detalle de Contrato     | FA-REQ-001        | screenshot-detalle.png | INFERRED | panel-datos, tabs:documentos/histórico, btn:editar, btn:anular |

### Reglas de negocio visibles
| ID      | Pantalla | FA-REQ vinculado | Descripción visual                      | Fuente           | Confianza |
|---------|----------|------------------|-----------------------------------------|------------------|-----------|
| BRN-001 | SCR-001  | FA-REQ-001       | Campo cliente marcado como obligatorio (*) | figma-frame-003 | INFERRED  |
| BRN-003 | SCR-001  | FA-REQ-001       | Tabla muestra máx 20 filas con paginación | figma-frame-003 | INFERRED  |

### Entidades funcionales detectadas
| ID      | Nombre    | FA-REQ vinculados | Campos visibles en UI                   | Fuente           | Confianza |
|---------|-----------|-------------------|-----------------------------------------|------------------|-----------|
| ENT-001 | Contrato  | FA-REQ-001        | id, cliente, fecha-inicio, estado, tipo | figma-frame-003  | INFERRED  |

### Flujos de navegación detectados
| ID      | Origen  | Destino | Elemento UI desencadenante | FA-REQ vinculado | Fuente           |
|---------|---------|---------|---------------------------|------------------|------------------|
| NAV-001 | SCR-001 | SCR-002 | Click fila tabla           | FA-REQ-001       | figma-frame-003  |

### Roles y permisos detectados visualmente
| Elemento           | Pantalla | Estado detectado      | FA-REQ vinculado | Confianza |
|--------------------|----------|-----------------------|------------------|-----------|
| btn:exportar       | SCR-001  | Visible solo SUPERVISOR | FA-REQ-002     | INFERRED  |
| btn:nueva-solicitud| SCR-001  | Visible solo GESTOR+   | FA-REQ-004     | INFERRED  |

### Checklist de reglas cliente aplicadas
- [ ] Nomenclatura funcional cliente aplicada
- [ ] Pantallas DEPRECATED marcadas como código muerto funcional

### Bloqueados / Gaps detectados
| ID          | Tipo           | Severidad   | FA-REQ afectado | Descripción breve                            |
|-------------|----------------|-------------|-----------------|----------------------------------------------|
| FA-GAP-004  | SCREEN-MISSING | BLOQUEANTE  | FA-REQ-004      | Frame "Nueva Solicitud" referenciado en nav pero no existe en Figma |
| FA-GAP-005  | REQ-ORPHAN     | RECOMENDADO | —               | Frame "Admin-Config" sin requisito funcional asignado              |

━━━ FIN FA-UI-RESUMEN ━━━
```

---

## Plantilla 3 — FA-CODE-RESUMEN (fa-code-analyzer)

*Solo activo para project.type ∈ {migration, modification, incident}*

```markdown
━━━ INICIO FA-CODE-RESUMEN ━━━

## FA-CODE-RESUMEN
- agente: fa-code-analyzer
- iteracion: ITER-NNN
- timestamp: YYYY-MM-DDTHH:MM:SSZ
- project-type: migration | modification | incident
- source-path: ./source-app/
- fuentes-procesadas: [lista de directorios/ficheros clave analizados]

### Universo detectado
| Tipo           | Patrón                           | Cantidad | IDs clave            |
|----------------|----------------------------------|----------|----------------------|
| Controladores  | *Controller, *Action, *Servlet   | N        | rutas identificadas  |
| Vistas/Pantallas| *.jsp, *.html, *.cshtml, *.vue  | N        | SCR-NNN candidatos   |
| Entidades      | *.entity, *.model, *.schema      | N        | ENT-NNN candidatos   |
| Servicios      | *Service, *Manager               | N        | lógica de negocio    |
| Código muerto  | rendered=false, deprecated, flags| N        | marcados para revisión|

### Requisitos funcionales detectados
| ID         | Descripción breve                  | Origen               | Tipo     | Confianza |
|------------|------------------------------------|----------------------|----------|-----------|
| FA-REQ-001 | Pantalla búsqueda contratos        | BusquedaController.java | INFERRED | CONFIRMED |
| FA-REQ-007 | Exportación PDF                    | ExportController.java   | INFERRED | INFERRED  |

### Pantallas / Vistas identificadas en código
| ID      | Nombre (deducido)        | Ruta en código                          | FA-REQ vinculados | Confianza | Estado      |
|---------|--------------------------|----------------------------------------|-------------------|-----------|-------------|
| SCR-001 | Búsqueda de Contratos    | views/contratos/busqueda.jsp           | FA-REQ-001        | CONFIRMED | ACTIVO      |
| SCR-007 | Gestión de Permisos Admin| views/admin/permisos.jsp (rendered=false)| —               | INFERRED  | CÓDIGO MUERTO|

### Reglas de negocio en código
| ID      | Clase/Método                      | FA-REQ vinculado | Descripción lógica                 | Confianza | Doc conocida |
|---------|-----------------------------------|------------------|------------------------------------|-----------|--------------|
| BRN-001 | ContratoBusqueda.validateFilters()| FA-REQ-001       | cliente != null → obligatorio      | CONFIRMED | Sí — BRD 3.1 |
| BRN-004 | ImporteValidator.check()          | FA-REQ-003       | minImporte = 100 (hardcoded)       | CONFIRMED | DISCREPANCIA — BRD dice 50 |

### Entidades en código
| ID      | Clase/Tabla        | FA-REQ vinculados | Campos principales                  | Confianza |
|---------|--------------------|-------------------|-------------------------------------|-----------|
| ENT-001 | Contrato.java / T_CONTRATOS | FA-REQ-001 | id, clienteId, fechaInicio, estado, tipo | CONFIRMED |
| ENT-003 | AuditLog.java / T_AUDIT | —           | id, userId, accion, timestamp      | INFERRED  |

### Código muerto funcional detectado
| Tipo              | Ruta                             | Descripción                          | Acción sugerida          |
|-------------------|----------------------------------|--------------------------------------|--------------------------|
| rendered=false    | views/admin/permisos.jsp         | Pantalla de permisos desactivada     | Operador decide migrar/no|
| flag desactivado  | FeatureFlags.EXPORT_CSV=false    | Exportación CSV nunca activa         | Confirmar exclusión       |
| @Deprecated       | LegacyBusquedaServlet.java       | Servlet antiguo sin rutas activas    | Candidato a no migrar    |

### Integraciones detectadas en código
| ID      | Sistema          | Clase/Método llamado              | FA-REQ vinculados | Detalles             |
|---------|------------------|-----------------------------------|-------------------|----------------------|
| INT-001 | SAP Facturación  | SapFacService.getFactura(id)      | FA-REQ-005        | URL config: sap.host |

### Discrepancias código vs documentación
| FA-GAP | Tipo                    | Código dice               | Doc dice           | FA-REQ afectado |
|--------|-------------------------|---------------------------|--------------------|-----------------|
| FA-GAP-001 | DISCREPANCIA-DOC-CODIGO | minImporte = 100 (hardcoded) | BRD dice 50€    | FA-REQ-003      |
| FA-GAP-006 | UNDOCUMENTED-FEATURE    | ExportPDF existe en código | No documentado     | —               |

### Checklist de reglas cliente aplicadas
- [ ] Código muerto detectado presentado al operador (nunca auto-marcado como no migrar)
- [ ] Política discrepancia aplicada (código = comportamiento real, doc = intención)

### Bloqueados / Gaps detectados
| ID          | Tipo                    | Severidad    | FA-REQ afectado | Descripción breve                   |
|-------------|-------------------------|--------------|-----------------|-------------------------------------|
| FA-GAP-001  | DISCREPANCIA-DOC-CODIGO | BLOQUEANTE   | FA-REQ-003      | Importe mínimo: código 100€ vs BRD 50€ |
| FA-GAP-006  | UNDOCUMENTED-FEATURE    | RECOMENDADO  | —               | ExportPDF en código sin spec        |

━━━ FIN FA-CODE-RESUMEN ━━━
```

---

## Plantilla 4 — FA-REQ-RESUMEN (fa-requirements-analyzer)

```markdown
━━━ INICIO FA-REQ-RESUMEN ━━━

## FA-REQ-RESUMEN
- agente: fa-requirements-analyzer
- iteracion: ITER-NNN
- timestamp: YYYY-MM-DDTHH:MM:SSZ
- fuentes-procesadas: [jira-export.json, historias-usuario.feature, etc.]

### Universo detectado
| Tipo          | Patrón                         | Cantidad | IDs clave         |
|---------------|--------------------------------|----------|-------------------|
| Stories Jira  | type:Story, status:To Do/Done  | N        | HU-NNN            |
| Bugs/Incidencias | type:Bug                    | N        | INC-NNN           |
| Epics         | type:Epic                      | N        | EP-NNN            |
| Scenarios Gherkin | Feature files               | N        | .feature paths    |

### Requisitos funcionales detectados
| ID         | Descripción breve                    | Origen     | Tipo     | Criterios aceptación | Confianza |
|------------|--------------------------------------|------------|----------|----------------------|-----------|
| FA-REQ-001 | Búsqueda contratos por cliente/fecha | HU-001     | DIRECTO  | Sí — 3 criterios     | CONFIRMED |
| FA-REQ-002 | Exportar resultados Excel            | HU-023     | DIRECTO  | Sí — 2 criterios     | CONFIRMED |
| FA-REQ-008 | Fix: búsqueda no filtra por estado   | INC-045    | DIRECTO  | Sí — reproducible    | CONFIRMED |

### Pantallas / Vistas referenciadas en HU
| ID      | Nombre                   | FA-REQ vinculados        | Fuente     | Confianza |
|---------|--------------------------|--------------------------|------------|-----------|
| SCR-001 | Búsqueda de Contratos    | FA-REQ-001, FA-REQ-008   | HU-001     | CONFIRMED |

### Criterios de aceptación por FA-REQ
#### FA-REQ-001 — Búsqueda de contratos
**Origen:** HU-001 (Jira MYAPP-001)
**Como:** Gestor de contratos
**Quiero:** Buscar contratos por cliente, fecha y estado
**Para:** Gestionar mi cartera de contratos

| # | Criterio                                               | Tipo       |
|---|--------------------------------------------------------|------------|
| 1 | Dado ningún filtro, muestra error "indica al menos un filtro" | Validación |
| 2 | Dado cliente seleccionado, devuelve contratos de ese cliente | Funcional |
| 3 | Dado +200 resultados, pagina de 20 en 20              | Rendimiento|

#### FA-REQ-002 — Exportar a Excel
*[mismo patrón]*

### Reglas de negocio en criterios de aceptación
| ID      | FA-REQ vinculado | Descripción extraída del criterio        | Confianza |
|---------|------------------|------------------------------------------|-----------|
| BRN-001 | FA-REQ-001       | Al menos un filtro obligatorio           | CONFIRMED |
| BRN-003 | FA-REQ-001       | Paginación de 20 en 20                  | CONFIRMED |

### Escenarios Gherkin detectados
| Feature                  | Escenario                        | FA-REQ vinculado | Mappeo            |
|--------------------------|----------------------------------|------------------|-------------------|
| busqueda-contratos.feature | Buscar por cliente existente   | FA-REQ-001       | Criterio 2        |
| busqueda-contratos.feature | Buscar sin filtros             | FA-REQ-001       | Criterio 1        |

### Checklist de reglas cliente aplicadas
- [ ] HUs de "Fase 2" excluidas con justificación
- [ ] Tickets CLOSED/WON'T-FIX marcados como excluidos

### Bloqueados / Gaps detectados
| ID          | Tipo           | Severidad   | FA-REQ afectado | Descripción breve                     |
|-------------|----------------|-------------|-----------------|---------------------------------------|
| FA-GAP-007  | FLOW-INCOMPLETE| BLOQUEANTE  | FA-REQ-004      | HU-015 sin criterios de aceptación    |
| FA-GAP-008  | NFR-MISSING    | RECOMENDADO | FA-REQ-001      | Sin SLA de rendimiento en criterios   |

━━━ FIN FA-REQ-RESUMEN ━━━
```

---

## Plantilla 5 — FA-SYNTHESIS-RESUMEN (fa-functional-synthesizer)

```markdown
━━━ INICIO FA-SYNTHESIS-RESUMEN ━━━

## FA-SYNTHESIS-RESUMEN
- agente: fa-functional-synthesizer
- iteracion: ITER-NNN
- timestamp: YYYY-MM-DDTHH:MM:SSZ
- basado-en: [FA-DOCS-RESUMEN, FA-UI-RESUMEN, FA-CODE-RESUMEN, FA-REQ-RESUMEN]
- client-rules-aplicadas: {client-id}-fa-rules

### Estadísticas de consolidación
| Métrica                          | Valor |
|----------------------------------|-------|
| FA-REQ confirmados               | N     |
| SCR asignadas                    | N     |
| BRN asignadas                    | N     |
| ENT asignadas                    | N     |
| FA-GAP abiertos                  | N     |
| FA-GAP BLOQUEANTES               | N     |
| Cobertura estimada               | NN%   |

### Registro maestro FA-REQ (requirements-registry)
| ID         | Descripción                           | Estado     | SCR vinculadas        | Gaps abiertos | Fuentes |
|------------|---------------------------------------|------------|-----------------------|---------------|---------|
| FA-REQ-001 | Búsqueda de contratos por cliente     | CONFIRMADO | SCR-001               | 0             | 3 fuentes |
| FA-REQ-002 | Exportar resultados a Excel           | CONFIRMADO | SCR-001               | 0             | 2 fuentes |
| FA-REQ-003 | Validación importe mínimo             | BLOQUEADO  | SCR-003               | FA-GAP-001    | 2 fuentes (conflicto) |
| FA-REQ-006 | Flujo de confirmación alta            | PENDIENTE  | —                     | FA-GAP-002    | 1 fuente  |

### Inventario de pantallas consolidado
| ID      | Nombre                   | FA-REQ vinculados         | Roles con acceso        | Confianza | Fuentes confirmatorias |
|---------|--------------------------|---------------------------|-------------------------|-----------|------------------------|
| SCR-001 | Búsqueda de Contratos    | FA-REQ-001, FA-REQ-002    | GESTOR, SUPERVISOR, ADMIN | CONFIRMED | BRD, Figma, Código    |
| SCR-002 | Detalle de Contrato      | FA-REQ-001                | GESTOR, SUPERVISOR, ADMIN | CONFIRMED | Manual, Código        |
| SCR-003 | Formulario Alta          | FA-REQ-003                | GESTOR, ADMIN           | INFERRED  | Figma                 |

### Catálogo de reglas de negocio consolidado
| ID      | Pantalla | FA-REQ vinculado | Descripción                    | Confianza | Estado     |
|---------|----------|------------------|--------------------------------|-----------|------------|
| BRN-001 | SCR-001  | FA-REQ-001       | Cliente obligatorio en filtro  | CONFIRMED | CONFIRMADA |
| BRN-002 | SCR-003  | FA-REQ-003       | Importe mínimo (en disputa)    | ASSUMED   | BLOQUEADA → FA-GAP-001 |

### Modelo de datos funcional consolidado
| ID      | Nombre    | FA-REQ vinculados         | Campos confirmados                          | Confianza |
|---------|-----------|---------------------------|---------------------------------------------|-----------|
| ENT-001 | Contrato  | FA-REQ-001, FA-REQ-002    | id, clienteId, fechaInicio, fechaFin, estado, tipo, importe | CONFIRMED |
| ENT-002 | Cliente   | FA-REQ-001                | id, nombre, nif, email, segmento            | CONFIRMED |

### Mapa de navegación consolidado
| ID      | Origen  | Destino | Condición                        | Roles         | FA-REQ vinculado |
|---------|---------|---------|----------------------------------|---------------|------------------|
| NAV-001 | SCR-001 | SCR-002 | Click en fila de resultado       | todos         | FA-REQ-001       |
| NAV-002 | SCR-001 | SCR-008 | Click "Nueva solicitud"          | GESTOR, ADMIN | FA-REQ-004       |

### Permisos y roles consolidados
| ID      | Nombre     | Pantallas con acceso    | Acciones                         | FA-REQ vinculados |
|---------|------------|-------------------------|----------------------------------|-------------------|
| ROL-001 | GESTOR     | SCR-001, SCR-002, SCR-003 | buscar, ver-detalle, alta       | FA-REQ-001..004   |
| ROL-002 | SUPERVISOR | SCR-001, SCR-002        | buscar, ver-detalle, exportar    | FA-REQ-001, FA-REQ-002 |
| ROL-003 | ADMIN      | todas                   | todo incluyendo admin            | todos             |

### Catálogo de integraciones consolidado
| ID      | Sistema externo | Tipo     | FA-REQ vinculados | API conocida | Confianza |
|---------|----------------|----------|-------------------|--------------|-----------|
| INT-001 | SAP Facturación | Consulta | FA-REQ-005        | No           | ASSUMED → FA-GAP-003 |

### Requisitos no funcionales
| ID      | Categoría   | Descripción                          | FA-REQ vinculados | Fuente      | Confianza |
|---------|-------------|--------------------------------------|-------------------|-------------|-----------|
| NFR-001 | Rendimiento | Resultados en < 3 segundos           | FA-REQ-001        | BRD sec 6.1 | CONFIRMED |
| NFR-002 | Seguridad   | RBAC obligatorio en todas las pantallas | todos          | BRD sec 6.2 | CONFIRMED |
| NFR-003 | Accesibilidad | WCAG 2.1 nivel AA                  | todos             | Sin fuente  | FA-GAP-009 → NFR-MISSING |

### Gaps consolidados (open-gaps)
| ID          | Tipo                    | Severidad    | FA-REQ afectado | Responsable sugerido | Estado  |
|-------------|-------------------------|--------------|-----------------|----------------------|---------|
| FA-GAP-001  | RULE-AMBIGUOUS          | BLOQUEANTE   | FA-REQ-003      | Product Owner        | ABIERTO |
| FA-GAP-002  | SCREEN-MISSING          | BLOQUEANTE   | FA-REQ-006      | Product Owner        | ABIERTO |
| FA-GAP-003  | INTEGRATION-UNKNOWN     | RECOMENDADO  | FA-REQ-005      | Arquitecto           | ABIERTO |
| FA-GAP-006  | UNDOCUMENTED-FEATURE    | RECOMENDADO  | —               | Operador (decidir)   | ABIERTO |

━━━ FIN FA-SYNTHESIS-RESUMEN ━━━
```
