---
name: gherkin-extractor
description: >
  Mapeo de ficheros Gherkin (.feature) a FA-REQ con criterios de aceptación
  estructurados. Cada Feature puede generar uno o más FA-REQ; cada Scenario
  es un criterio de aceptación. Activo cuando existen ficheros .feature en
  input/specs/.
---

# gherkin-extractor — Extracción de Ficheros Gherkin

> **Scope:** Extracción de requisitos desde ficheros Gherkin en WF1-FA
> **Cubre:** feature-to-fa-req, scenario-to-criterio, given-when-then, scenario-outline
> **No cubre:** ejecución de tests — eso es WF4; step definitions técnicas

## Activación

Se activa cuando existen ficheros con extensión `.feature` en `input/specs/`.

## Mapeo Feature → FA-REQ

### Estructura básica de un fichero .feature

```gherkin
Feature: Búsqueda de contratos
  Como gestor de contratos
  Quiero poder buscar contratos por diferentes criterios
  Para gestionar mi cartera de contratos eficientemente

  Background:
    Given el usuario está autenticado como "GESTOR"
    And se encuentra en la pantalla de búsqueda

  Scenario: Búsqueda exitosa por cliente
    When selecciona el cliente "ACME Corp" en el filtro
    And pulsa el botón "Buscar"
    Then ve una tabla con los contratos del cliente "ACME Corp"
    And la tabla muestra las columnas: ID, Fecha, Estado, Tipo, Importe

  Scenario: Búsqueda sin filtros
    When pulsa "Buscar" sin seleccionar ningún filtro
    Then ve el mensaje de error "Debe indicar al menos un criterio de búsqueda"

  Scenario Outline: Validación de importes mínimos
    When introduce el importe <valor>
    Then el campo muestra el estado <estado>
    
    Examples:
      | valor | estado   |
      | 0     | error    |
      | 50    | warning  |
      | 100   | valido   |
```

### Mapeo a FA-REQ

```
Feature                → FA-REQ (o grupo de FA-REQ si los scenarios cubren funcionalidades distintas)
Feature description    → descripcion del FA-REQ
Rol en "Como X"        → ROL-NNN candidato
Background             → precondiciones comunes a todos los criterios
Scenario               → criterio de aceptación individual
Scenario Outline       → criterio parametrizado (cada combinación de Examples es un caso)
```

### Formato de Criterio de Aceptación desde Gherkin

Convertir Given/When/Then a lenguaje de negocio:

```
Scenario: "Búsqueda exitosa por cliente"
Given: "el usuario está autenticado como GESTOR"
When: "selecciona cliente ACME Corp y pulsa Buscar"
Then: "ve tabla con contratos de ACME, columnas: ID, Fecha, Estado, Tipo, Importe"

→ Criterio: "Al buscar por cliente seleccionado, se muestran sus contratos
             con columnas: ID, Fecha, Estado, Tipo, Importe"
```

## Extracción de Reglas de Negocio desde Scenarios

Los Scenarios revelan reglas de negocio:
- Scenarios de validación → BRN candidata (severidad y valor de la regla)
- Scenarios de permiso → ROL-NNN (quién puede hacer qué)
- Scenarios de estado → estados de ENT-NNN o SCR-NNN

**Ejemplos:**
```
Scenario "Búsqueda sin filtros → error"
→ BRN: "Al menos un filtro obligatorio para ejecutar búsqueda"

Scenario Outline con importes
→ BRN: "Importe < 50 → error; 50 ≤ importe < 100 → advertencia; ≥ 100 → válido"
→ Nota: si BRD dice algo diferente → FA-GAP DISCREPANCIA-DOC-CODIGO

Scenario "El supervisor puede exportar Excel"
→ ROL-002 (SUPERVISOR) puede acción "exportar-excel" en SCR-001
```

## Tags de Gherkin

Los tags en los scenarios añaden metadatos útiles:

```gherkin
@smoke @sprint3 @FA-REQ-001
Scenario: Búsqueda exitosa
```

| Tag Gherkin            | Interpretación funcional                          |
|------------------------|---------------------------------------------------|
| `@FA-REQ-NNN`          | Vincular explícitamente a ese FA-REQ              |
| `@smoke`               | Caso principal (happy path)                       |
| `@regression`          | Caso de regresión (comportamiento ya validado)    |
| `@pending`, `@wip`     | Criterio no implementado → verificar en código    |
| `@ignore`, `@skip`     | No incluir en criterios (pendiente de definición) |

## Scenario Outline y Examples

Los Scenario Outline con múltiples filas en Examples representan una familia de casos:
- Crear un único criterio de aceptación parametrizado
- Documentar los valores límite relevantes (boundary values)
- Si los valores revelan una regla → crear BRN con los valores exactos

```
Scenario Outline con valores 0, 50, 100 de importe
→ BRN-002: Validación de importe mínimo
   - < 50: error
   - 50 ≤ valor < 100: advertencia
   - ≥ 100: válido
```

## Discrepancias entre Gherkin y Documentación

Si un scenario dice algo diferente a lo especificado en documentos:
→ FA-GAP DISCREPANCIA-DOC-CODIGO (el código de tests es "código")
→ Documentar el valor del scenario vs. el valor del documento
→ El operador debe resolver cuál es correcto
