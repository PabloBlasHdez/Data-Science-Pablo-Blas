---
name: demo-fa-rules
description: >
  Plantilla de Client Skill para WF1-FA. Define las reglas funcionales,
  nomenclatura de negocio, alcance, jerarquía de confianza, restricciones
  de privacidad y convenciones del stack target de un cliente. Esta plantilla
  se copia a {client-id}-fa-rules y se personaliza por proyecto.
---

# DEMO FA Rules — Plantilla de Client Skill

> **Scope:** Reglas funcionales del cliente DEMO para análisis funcional WF1-FA
> **Cubre:** nomenclatura, alcance, confianza, privacidad, convenciones-target
> **No cubre:** stack técnico detallado — crear {client}-stack skill separado si es complejo
> **Cliente:** demo (plantilla)

> **INSTRUCCIONES PARA CREAR UN CLIENT SKILL REAL:**
> 1. Copiar este fichero a `.claude/skills/{client-id}-fa-rules/SKILL.md`
> 2. Sustituir `demo` por el `client-id` real en el frontmatter
> 3. Completar cada sección con los datos reales del cliente
> 4. Eliminar estas instrucciones y los ejemplos marcados con [EJEMPLO]
> 5. Registrar el nuevo skill en el inventario Excel del equipo

---

## Sección 1 — Nomenclatura Funcional del Cliente

Define los términos propios del cliente que difieren del lenguaje genérico del framework.

### Alias de Roles

Los agentes de análisis deben mapear los nombres de roles del cliente a los IDs estándar del framework:

| Nombre en documentos del cliente | ID estándar en artefactos | Notas                          |
|----------------------------------|---------------------------|--------------------------------|
| [EJEMPLO: "Agente"]              | GESTOR                    | Usuario operativo básico       |
| [EJEMPLO: "Coordinador"]         | SUPERVISOR                | Usuario con permisos adicionales|
| [EJEMPLO: "Administrador"]       | ADMIN                     | Administrador del sistema      |
| [AÑADIR más roles del cliente]   | [ROL-ID estándar]         |                                |

### IDs y Códigos Propios del Cliente

Formatos de identificadores usados por el cliente en su documentación:

| Elemento          | Formato del cliente           | Ejemplo              |
|-------------------|-------------------------------|----------------------|
| [EJEMPLO: Contrato] | CTR-YYYY-NNNNN              | CTR-2026-00042       |
| [EJEMPLO: Cliente]  | CLI-NNNNN                   | CLI-00123            |
| [AÑADIR más]        | [formato]                   | [ejemplo]            |

### Terminología de Negocio

Glosario de términos específicos del cliente que los agentes deben reconocer:

| Término del cliente   | Equivalente funcional estándar | Notas                    |
|-----------------------|-------------------------------|--------------------------|
| [EJEMPLO: "Gestión"]  | Pantalla de administración    | Siempre se refiere a la interfaz de CRUD |
| [AÑADIR términos]     | [equivalente]                 |                          |

---

## Sección 2 — Reglas de Alcance

Define qué incluir y qué excluir del análisis funcional.

### Exclusiones Automáticas

El agente debe excluir automáticamente (sin preguntar al operador) los siguientes elementos
cuando los encuentre en la documentación o código:

| Indicador                           | Acción                                         |
|-------------------------------------|------------------------------------------------|
| [EJEMPLO: Etiqueta Jira "fase-2"]   | Excluir del análisis con nota "Fase 2 — fuera de alcance v1" |
| [EJEMPLO: Páginas Confluence "DEPRECATED"] | Marcar como código muerto funcional |
| [EJEMPLO: Feature flag desactivado en config] | Marcar como código muerto funcional |
| [AÑADIR criterios de exclusión del cliente] | [acción] |

### Indicadores de Inclusión Prioritaria

Elementos que deben analizarse con máxima prioridad:

| Indicador                           | Prioridad                                      |
|-------------------------------------|------------------------------------------------|
| [EJEMPLO: Etiqueta Jira "must-have"] | Máxima prioridad — FA-REQ con confianza CONFIRMED |
| [EJEMPLO: Sección BRD "Requisitos Core"] | Alta prioridad |
| [AÑADIR]                            |                |

---

## Sección 3 — Jerarquía de Confianza

Cuando dos fuentes dan información contradictoria, esta jerarquía determina cuál gana.
Las fuentes de mayor número tienen mayor autoridad.

```
(Mayor autoridad)
5. Especificación firmada / BRD aprobado por cliente  [EJEMPLO]
4. Figma v2+ (diseño validado con cliente)            [EJEMPLO]
3. Código fuente actual (comportamiento real)         [EJEMPLO: para migration/modification]
2. Historias de usuario aprobadas en sprint           [EJEMPLO]
1. Actas de reunión y emails                          [EJEMPLO - menor autoridad]
(Menor autoridad)
```

**Nota importante:** Esta jerarquía se usa solo cuando hay contradicción entre fuentes.
Si hay contradicción y ninguna fuente gana claramente → FA-GAP RULE-AMBIGUOUS siempre.

---

## Sección 4 — Restricciones de Privacidad

Datos que NUNCA deben aparecer en texto plano en los artefactos generados.

| Tipo de dato                      | Enmascaramiento en artefactos              |
|-----------------------------------|--------------------------------------------|
| [EJEMPLO: NIF/CIF]                | Reemplazar por "XXXXXXXXX"                 |
| [EJEMPLO: Número de cuenta]       | Reemplazar por "XXXX XXXX XXXX XXXX"       |
| [EJEMPLO: Email personal]         | Reemplazar por "usuario@[dominio-enmascarado]" |
| [EJEMPLO: Número de teléfono]     | Reemplazar por "+34 XXX XXX XXX"           |
| [AÑADIR datos sensibles del cliente] | [enmascaramiento] |

**Regulaciones aplicables:** [EJEMPLO: GDPR, LOPD-GDD, PCI-DSS si aplica, etc.]

---

## Sección 5 — Convenciones Target

Convenciones del stack tecnológico target para el que se desarrollará la aplicación.
Estas convenciones son utilizadas por `fa-target-context-enricher` en FASE 2.

### Frontend

- **Tecnología:** [EJEMPLO: Angular 17+]
- **Estructura de módulos:** [EJEMPLO: módulos por dominio, lazy-loading obligatorio]
- **Nomenclatura componentes:** [EJEMPLO: PascalCase, sufijo 'Component', kebab-case en selector]
- **Nomenclatura servicios:** [EJEMPLO: PascalCase, sufijo 'Service']
- **Formularios:** [EJEMPLO: Reactive Forms obligatorio para formularios con más de 3 campos]
- **Rutas:** [EJEMPLO: kebab-case en URLs, máximo 3 niveles de anidación]
- **Estado:** [EJEMPLO: NgRx para estado global; signals para estado local de componente]
- **i18n:** [EJEMPLO: ngx-translate, ficheros en src/assets/i18n/{locale}.json]
- **Estilos:** [EJEMPLO: SCSS, BEM para nomenclatura de clases CSS]

### Backend

- **Tecnología:** [EJEMPLO: .NET 8 + C#]
- **Arquitectura:** [EJEMPLO: Clean Architecture con 4 capas: Domain/Application/Infrastructure/API]
- **Patrón de diseño:** [EJEMPLO: CQRS con MediatR para commands y queries]
- **Nomenclatura endpoints:** [EJEMPLO: REST plural, kebab-case en URLs, /api/v1/ prefix]
- **Nomenclatura DTOs:** [EJEMPLO: PascalCase, sufijo 'Request' y 'Response']
- **Autenticación:** [EJEMPLO: JWT Bearer tokens, validación en middleware]
- **Base de datos:** [EJEMPLO: SQL Server 2022, Entity Framework Core]

### Formatos de Datos

- **Fechas:** [EJEMPLO: dd/MM/yyyy en UI; ISO 8601 en API]
- **Fechas con hora:** [EJEMPLO: dd/MM/yyyy HH:mm en UI; ISO 8601 con timezone en API]
- **Moneda:** [EJEMPLO: EUR, 2 decimales, separador decimal coma, separador miles punto: "1.234,56 €"]
- **Números:** [EJEMPLO: separador decimal = coma, separador miles = punto]
- **Booleanos en UI:** [EJEMPLO: "Sí"/"No" en español]

### Idioma y Localización

- **Idioma UI primario:** [EJEMPLO: es — Español]
- **Idioma UI secundario:** [EJEMPLO: en — Inglés (solo para usuarios internacionales)]
- **Zona horaria base:** [EJEMPLO: Europe/Madrid]
- **Primer día de semana:** [EJEMPLO: Lunes]

---

## Sección 6 — Reglas de Confianza por Herramienta

Ajustes específicos del cliente sobre la confianza por defecto de las fuentes.

| Fuente                              | Confianza por defecto | Ajuste cliente               |
|-------------------------------------|-----------------------|------------------------------|
| [EJEMPLO: Figma versión 1 o anterior] | INFERRED            | Reducir a ASSUMED — diseños desactualizados |
| [EJEMPLO: BRD firmado versión 2+]   | CONFIRMED             | Sin cambio                   |
| [EJEMPLO: Emails del arquitecto]    | ASSUMED               | Elevar a INFERRED si son del CTO |
| [AÑADIR ajustes específicos]        |                       |                              |

---

## Sección 7 — Módulos y Dominios del Proyecto

Estructura de módulos del cliente (útil para organizar FA-REQ por área).

| Módulo / Dominio                | Prefijo sugerido para FA-REQ | Notas                   |
|---------------------------------|------------------------------|-------------------------|
| [EJEMPLO: Módulo Contratos]     | FA-REQ-0XX (001-099)         | Funcionalidades de contratos |
| [EJEMPLO: Módulo Clientes]      | FA-REQ-1XX (100-199)         | Gestión de cartera      |
| [EJEMPLO: Módulo Reportes]      | FA-REQ-2XX (200-299)         | Informes y exportaciones|
| [AÑADIR módulos del cliente]    |                              |                         |

> **Nota:** El prefijo de rango es una sugerencia para la organización. Los IDs
> definitivos los asigna `fa-functional-synthesizer` secuencialmente.
