---
name: drawio-extractor
description: >
  Mapeo de diagramas draw.io/diagrams.net a pantallas SCR-NNN y transiciones
  de navegación NAV-NNN. Activo cuando existen ficheros .drawio o .xml de draw.io
  en input/specs/. Extrae nodos como pantallas y aristas como transiciones.
---

# drawio-extractor — Extracción de Diagramas Draw.io

> **Scope:** Extracción de flujos de navegación desde diagramas draw.io en WF1-FA
> **Cubre:** nodos-a-scr, aristas-a-nav, diagramas-de-flujo, mapas-de-navegacion
> **No cubre:** diagramas de arquitectura técnica — eso es WF2; diagramas UML de clases

## Activación

Se activa cuando existen ficheros con extensión `.drawio` o `.xml` (que sean diagramas
draw.io) en `input/specs/`. Los ficheros `.drawio` son XML con estructura específica.

## Estructura de un Fichero draw.io (XML)

```xml
<mxfile>
  <diagram name="Flujo de contratos">
    <mxGraphModel>
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>
        <!-- Nodos (pantallas) -->
        <mxCell id="2" value="Búsqueda de Contratos" 
                style="rounded=1;" vertex="1" parent="1">
          <mxGeometry x="100" y="100" width="160" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="3" value="Detalle de Contrato"
                style="rounded=1;" vertex="1" parent="1">
          <mxGeometry x="320" y="100" width="160" height="60" as="geometry"/>
        </mxCell>
        <!-- Aristas (transiciones) -->
        <mxCell id="4" value="Click en fila" 
                style="edgeStyle=orthogonalEdgeStyle;" 
                edge="1" source="2" target="3" parent="1">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
```

## Mapeo de Elementos draw.io → FA

### Nodos (vertex) → SCR-NNN

```
Por cada elemento con vertex="1" en el XML:
  - value = nombre del nodo → nombre funcional de la pantalla SCR-NNN
  - Normalizar nombre: eliminar prefijos numéricos, estandarizar capitalización
  - Si value contiene "[" y "]" → puede ser estado o tipo (no pantalla separada)
  - Si value contiene "START" o "END" → puntos de inicio/fin del flujo (no SCR)
  - Si el style indica "rhombus" (diamante) → punto de decisión (no SCR, añadir condición a la arista)
```

**Detección de código muerto en diagramas:**
- Nodo con color rojo/gris y label "DEPRECATED" o "DESACTIVADO" → código muerto funcional
- Nodo con doble borde o sombra → pantalla de admin/especial

### Aristas (edge) → NAV-NNN

```
Por cada elemento con edge="1" en el XML:
  - source = ID del nodo origen → SCR-NNN origen
  - target = ID del nodo destino → SCR-NNN destino
  - value = etiqueta de la arista → condición de la transición
  - Si value está vacío → condición = "No especificada" → FA-GAP FLOW-INCOMPLETE
```

## Tipos de Diagramas y Estrategia

| Tipo de diagrama draw.io       | Estrategia                                         |
|--------------------------------|----------------------------------------------------|
| Mapa de navegación             | Nodos = pantallas, aristas = transiciones          |
| Diagrama de flujo de proceso   | Nodos con "Process" = acciones, Nodos con "UI" = pantallas |
| Diagrama de flujo con decisiones | Diamantes = condiciones de bifurcación            |
| Arquitectura de sistema        | Ignorar (pasar a WF2) — identificar por ausencia de pantallas |
| Diagrama de casos de uso       | Óvalos = casos de uso → FA-REQ candidatos          |

## Extracción de Condiciones de Transición

Las etiquetas de las aristas son condiciones de navegación:
```
"Click en fila"         → condicion: Click en fila de tabla de resultados
"[guardar OK]"          → condicion: Guardado exitoso (notación UML)
"Al confirmar"          → condicion: Usuario confirma acción
"Volver"                → condicion: Usuario cancela / navega atrás
"Error de validación"   → condicion: Formulario con errores
"[N/A]" o ""            → condicion: No especificada → FA-GAP FLOW-INCOMPLETE
```

## Subdiagramas y Páginas

Un fichero draw.io puede tener múltiples páginas/diagramas:
- Cada página = un flujo o módulo
- Analizar todas las páginas
- Si hay referencias entre páginas → mantener referencias cruzadas entre SCR de distintos flujos

## Salida Esperada

```markdown
### Flujos de Navegación del Diagrama — {nombre-fichero}.drawio

| ID      | Origen               | Destino              | Condición                    | FA-REQ vinculado |
|---------|----------------------|----------------------|------------------------------|------------------|
| NAV-001 | SCR-001 (Búsqueda)   | SCR-002 (Detalle)    | Click en fila de resultado   | FA-REQ-001       |
| NAV-002 | SCR-001 (Búsqueda)   | SCR-008 (Alta)       | Click "Nueva solicitud"      | FA-REQ-004       |
| NAV-003 | SCR-002 (Detalle)    | SCR-001 (Búsqueda)   | Click "Volver"               | FA-REQ-001       |
| NAV-004 | SCR-003 (Alta)       | SCR-006 (Confirmación)| Condición no especificada   | FA-REQ-003       |

### Gaps detectados en el diagrama
- FA-GAP-FLOW-NNN: NAV-004 sin condición de transición definida
```
