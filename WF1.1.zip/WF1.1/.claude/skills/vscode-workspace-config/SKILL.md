---
name: vscode-workspace-config
description: >
  Crear o editar ficheros *.code-workspace para definir workspaces multi-root
  en VS Code. Cubre la sección folders (paths absolutos o relativos con names
  custom), settings que sobreescriben los user settings, recomendaciones de
  extensiones y launch/tasks centralizados. Activar cuando el usuario tiene
  varios repos relacionados, quiere abrirlos en una única ventana, o necesita
  settings compartidos entre múltiples carpetas.
---

# vscode-workspace-config — Workspaces Multi-Root de VS Code

> **Scope:** Creación y edición de ficheros `*.code-workspace`
> **Cubre:** folders multi-root, settings centralizados, extensions.recommendations, launch+tasks workspace-wide, jerarquía de overrides
> **No cubre:** single-folder workspaces (no requieren `.code-workspace`); workspace trust (UI de VS Code)

## Cuándo activar

- "Quiero abrir el repo de backend y frontend juntos en una sola ventana"
- "Tengo 3 microservicios y quiero un workspace común"
- "Configura settings que apliquen a varias carpetas"
- "Genera un .code-workspace para el equipo"

**No usar** para proyectos de una sola carpeta — basta con abrir la carpeta directamente.

## Schema canónico

```jsonc
{
  "folders": [
    {
      "name": "Web",                                  // display name (opcional)
      "path": "./packages/web"                        // relativo al .code-workspace
    },
    {
      "name": "API",
      "path": "./packages/api"
    },
    {
      "name": "Docs",
      "path": "../external-docs-repo"                 // fuera del repo
    }
  ],
  "settings": {
    "files.exclude": { "**/dist": true },
    "editor.formatOnSave": true,
    "typescript.tsdk": "node_modules/typescript/lib"
  },
  "extensions": {
    "recommendations": [
      "dbaeumer.vscode-eslint",
      "esbenp.prettier-vscode"
    ],
    "unwantedRecommendations": [
      "ms-vscode.vscode-typescript-tslint-plugin"
    ]
  },
  "launch": {
    "version": "0.2.0",
    "configurations": [],
    "compounds": []
  },
  "tasks": {
    "version": "2.0.0",
    "tasks": []
  }
}
```

## Cuándo usar paths relativos vs absolutos

| Path     | Cuándo                                                       |
|----------|--------------------------------------------------------------|
| Relativo | Carpetas del MISMO repo (preferible — commitable, portable)  |
| `../`    | Repos hermanos en la misma máquina del dev                   |
| Absoluto | EVITAR — rompe portabilidad entre máquinas                   |

Si necesitas paths absolutos compartibles → mejor un script de bootstrap que cree el workspace localmente.

## Jerarquía de configuración

VS Code aplica settings en este orden (mayor precedencia primero):

1. **Folder settings** (`{folder}/.vscode/settings.json`) — más específico
2. **Workspace settings** (sección `settings` del `.code-workspace`)
3. **User settings** (`~/.config/Code/User/settings.json`)
4. **Default settings** (built-in de VS Code)

Es decir: lo declarado en `.code-workspace > settings` sobreescribe los user settings pero PUEDE ser sobreescrito por settings de cada folder.

## Launch y tasks centralizados

Cuando `launch` y `tasks` se declaran en el `.code-workspace`, aplican a TODO el workspace (todos los folders). Útil para configurar debug compound:

```jsonc
{
  "folders": [
    { "name": "API", "path": "./api" },
    { "name": "Web", "path": "./web" }
  ],
  "launch": {
    "version": "0.2.0",
    "configurations": [
      { "name": "Debug API", "type": "node", "request": "launch", "program": "${workspaceFolder:API}/src/index.ts" },
      { "name": "Debug Web", "type": "chrome", "request": "launch", "url": "http://localhost:3000", "webRoot": "${workspaceFolder:Web}/src" }
    ],
    "compounds": [
      { "name": "Full Stack", "configurations": ["Debug API", "Debug Web"], "stopAll": true }
    ]
  }
}
```

Variable nueva en multi-root: `${workspaceFolder:NAME}` — apunta a la folder con ese `name`.

## Extensions recommendations

VS Code muestra una notificación al abrir el workspace si las extensiones de `recommendations` no están instaladas. Lista corta y enfocada:

```jsonc
"extensions": {
  "recommendations": [
    "dbaeumer.vscode-eslint",        // formato {publisher}.{name}
    "esbenp.prettier-vscode",
    "ms-azuretools.vscode-docker",
    "github.copilot",
    "github.copilot-chat"
  ]
}
```

`unwantedRecommendations` desincentiva extensiones que sabes que rompen el proyecto.

## Estructura sugerida del fichero

```
my-project.code-workspace
├── packages/
│   ├── api/                ← folder 1
│   └── web/                ← folder 2
└── docs/                   ← folder 3
```

Convención de naming:
- Nombre del fichero: `{project-name}.code-workspace` (kebab-case)
- Ubicarlo en la raíz del repo (no dentro de subcarpetas)

## Validaciones aplicables

- ✅ JSON válido (admite JSONC con comentarios)
- ✅ `folders[]` no vacío y cada entrada tiene `path` no vacío
- ✅ Paths no apuntan a directorios inexistentes (advertir al usuario, no abortar)
- ✅ `name` único entre folders
- ✅ Si `launch` o `tasks` están presentes → versión declarada (`0.2.0` / `2.0.0`)
- ✅ Extensions recommendations en formato `{publisher}.{name}` (regex `^[a-z0-9-]+\.[a-z0-9-]+$`)
- ⚠️  Settings que solo tienen sentido a nivel folder (ej: rutas específicas) → mejor en `{folder}/.vscode/settings.json`

## Cómo abrir un .code-workspace

- Doble click en el fichero → VS Code lo abre
- Desde terminal: `code my-project.code-workspace`
- Desde VS Code: `File → Open Workspace from File...`

## Procedimiento al crear desde cero

1. Preguntar al usuario:
   - Nombre del workspace
   - Folders a incluir (paths relativos o absolutos)
   - Names display (opcional)
   - Settings comunes (formatOnSave, exclude patterns, ...)
   - Recomendaciones de extensiones (lista publisher.name)
2. Generar el `.code-workspace` en la raíz del proyecto
3. Mostrar comando para abrir: `code {name}.code-workspace`
4. Sugerir añadir a `.gitignore` si contiene paths absolutos: `*.code-workspace.local`

## Procedimiento al editar uno existente

1. Leer el fichero, parsear JSONC
2. Identificar la sección (folders / settings / extensions / launch / tasks)
3. Aplicar la edición, preservando comentarios
4. Verificar paths siguen existiendo
5. Si se modificó `launch` o `tasks` → mostrar al usuario que afecta a TODOS los folders del workspace

## Anti-patterns

- ❌ Workspace con un único folder → usar single-folder mode
- ❌ Paths absolutos en `folders[].path` si el fichero va al repo
- ❌ Duplicar settings que ya están en cada `{folder}/.vscode/settings.json`
- ❌ Listas de `recommendations` con > 20 extensiones (ruido para el equipo)
- ❌ Mezclar launch/tasks en `.code-workspace` y en `{folder}/.vscode/` — eligir uno
