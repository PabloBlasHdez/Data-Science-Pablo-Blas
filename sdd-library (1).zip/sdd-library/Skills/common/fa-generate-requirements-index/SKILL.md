---
name: fa-generate-requirements-index
description: >
  Genera inventario de requisitos tras FASE 2 (síntesis). Produce dos artefactos:
  - output/requirements-registry.md (tabla estructura para WF2 y trazabilidad)
  - operator/requirements-index.html (vista interactiva amigable para operador)
  Ejecutado al final de FASE 2, antes de fa-gap-detector.
---

# fa-generate-requirements-index — Generación de Inventario de Requisitos

## Propósito

Tras consolidar todos los requisitos en `FA-SYNTHESIS-RESUMEN.md` (FASE 2), generar un inventario maestro accesible en dos formatos:
1. **Markdown estructurado** para WF2 (trazabilidad, importación)
2. **HTML interactivo** para el operador (búsqueda, filtros, referencias cruzadas)

Ejecutado **antes de `fa-gap-detector` en FASE 2**, permite:
- Al operador: referencia clara de todos los FA-REQ-NNN durante resolución de gaps
- A WF2: inventario finalizado incluso si workflow se detiene por gaps bloqueantes

## Inputs Requeridos

- `FA-SYNTHESIS-RESUMEN.md` — síntesis consolidada con todos los FA-REQ-NNN
- `fa-config.yml` — metadatos del proyecto (app-id, client-id, iteration)

## Outputs Generados

### 1. `output/requirements-registry.md`

**Frontmatter canónico:**
```yaml
---
app-id: {app-id}
client-id: {client-id}
artifact: requirements-registry
version: "1.0"
iteration: ITER-NNN
generated-at: {timestamp ISO 8601}
generated-by: fa-generate-requirements-index
status: in-progress | final
wf2-ready: false (en FASE 2; true cuando cierra WF1)
---
```

**Contenido — Tabla estructura:**

| FA-REQ-ID | Descripción | Tipo | Origen | Confianza | Componentes Vinculados | Estado | Gaps Vinculados |
|-----------|-------------|------|--------|-----------|------------------------|--------|-----------------|
| FA-REQ-001 | Búsqueda de contratos | Funcional | HU-023 (Jira) | CONFIRMED | SCR-001, BRN-007, ENT-001 | CONFIRMADO | — |
| FA-REQ-002 | Exportar a Excel | Funcional | BRD §3.1 | INFERRED | SCR-002, BRN-009 | BLOQUEADO | FA-GAP-015 |

**Secciones:**
1. **Tabla de requisitos** (orden: FA-REQ-NNN creciente)
   - Todos los requisitos detectados con estado actual
   - Componentes (SCR, BRN, ENT) vinculados
   - Gaps bloqueantes si los hay

2. **Índice por tipo** (opcional, para WF2):
   ```
   ## Por Tipo de Requisito
   - Funcionales: FA-REQ-001, FA-REQ-003, ...
   - No Funcionales: FA-REQ-N, ...
   ```

3. **Índice por origen**:
   ```
   ## Por Origen
   - Jira: HU-001 → FA-REQ-001, HU-023 → FA-REQ-005, ...
   - BRD: §3.1 → FA-REQ-002, ...
   - Figma: frame-main → FA-REQ-010, ...
   ```

4. **Requisitos sin componentes** (auditoría):
   ```
   ## ⚠️ Requisitos Huérfanos (sin SCR/BRN/ENT)
   - FA-REQ-NNN: {descripción} [origen]
   ```

---

### 2. `operator/requirements-index.html`

**Propósito:** Vista amigable e interactiva para el operador durante resolución de gaps.

**Estructura:**

```html
<!DOCTYPE html>
<html>
<head>
  <title>Inventario de Requisitos — {APP_ID} — ITER-{NNN}</title>
  <style>
    /* Dark theme (consistente con open-questions.html) */
    :root {
      --bg: #0f1117; --bg2: #161b22; --border: #30363d;
      --text: #e6edf3; --text2: #8b949e;
      --confirmed: #3fb950; --inferred: #e3b341; --assumed: #f85149;
      --bloqueante: #f85149; --recomendado: #e3b341;
    }
  </style>
</head>
<body>
  <header>
    <h1>📋 Inventario de Requisitos</h1>
    <div class="meta">
      <span>Proyecto: {APP_ID}</span>
      <span>Iteración: ITER-{NNN}</span>
      <span>Generado: {fecha}</span>
      <span>Total: {N} requisitos</span>
    </div>
  </header>

  <div class="toolbar">
    <input type="search" id="search" placeholder="Buscar FA-REQ-NNN, descripción...">
    <select id="filter-status">
      <option value="">Todos los estados</option>
      <option value="CONFIRMADO">CONFIRMADO</option>
      <option value="BLOQUEADO">BLOQUEADO</option>
      <option value="EXCLUIDO">EXCLUIDO</option>
    </select>
    <select id="filter-confianza">
      <option value="">Todas las confianzas</option>
      <option value="CONFIRMED">CONFIRMED</option>
      <option value="INFERRED">INFERRED</option>
      <option value="ASSUMED">ASSUMED</option>
    </select>
    <label><input type="checkbox" id="show-gaps-only"> Solo con gaps</label>
  </div>

  <table id="requirements-table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Descripción</th>
        <th>Tipo</th>
        <th>Confianza</th>
        <th>Componentes</th>
        <th>Estado</th>
        <th>Gaps</th>
      </tr>
    </thead>
    <tbody>
      <!-- Filas generadas -->
      <tr>
        <td class="id-cell"><strong>FA-REQ-001</strong></td>
        <td class="description-cell">Búsqueda de contratos por criterios múltiples</td>
        <td>Funcional</td>
        <td><span class="badge confirmed">CONFIRMED</span></td>
        <td class="components-cell">
          <span class="component scr">SCR-001</span>
          <span class="component brn">BRN-007</span>
          <span class="component ent">ENT-001</span>
        </td>
        <td><span class="status confirmado">CONFIRMADO</span></td>
        <td class="gaps-cell">—</td>
      </tr>
      <tr>
        <td class="id-cell"><strong>FA-REQ-002</strong></td>
        <td class="description-cell">Exportar resultados a Excel</td>
        <td>Funcional</td>
        <td><span class="badge inferred">INFERRED</span></td>
        <td class="components-cell">
          <span class="component scr">SCR-002</span>
          <span class="component brn">BRN-009</span>
        </td>
        <td><span class="status bloqueado">BLOQUEADO</span></td>
        <td class="gaps-cell">
          <a href="#" class="gap-link">FA-GAP-015</a>
        </td>
      </tr>
    </tbody>
  </table>

  <div class="summary">
    <h3>📊 Resumen</h3>
    <ul>
      <li>Total requisitos: {N}</li>
      <li>Confirmados: {N} ({%})</li>
      <li>Inferidos: {N} ({%})</li>
      <li>Asumidos: {N} ({%})</li>
      <li>Con gaps bloqueantes: {N}</li>
      <li>Huérfanos (sin componentes): {N}</li>
    </ul>
  </div>

  <script>
    // Búsqueda y filtros en vivo
    document.getElementById('search').addEventListener('input', filterTable);
    document.getElementById('filter-status').addEventListener('change', filterTable);
    document.getElementById('filter-confianza').addEventListener('change', filterTable);
    document.getElementById('show-gaps-only').addEventListener('change', filterTable);
    
    function filterTable() {
      const searchText = document.getElementById('search').value.toLowerCase();
      const statusFilter = document.getElementById('filter-status').value;
      const confianzaFilter = document.getElementById('filter-confianza').value;
      const gapsOnly = document.getElementById('show-gaps-only').checked;
      
      document.querySelectorAll('#requirements-table tbody tr').forEach(row => {
        const id = row.querySelector('.id-cell').textContent.toLowerCase();
        const desc = row.querySelector('.description-cell').textContent.toLowerCase();
        const status = row.querySelector('.status')?.textContent || '';
        const confianza = row.querySelector('.badge')?.textContent || '';
        const hasGaps = row.querySelector('.gap-link') !== null;
        
        const matchSearch = id.includes(searchText) || desc.includes(searchText);
        const matchStatus = !statusFilter || status.includes(statusFilter);
        const matchConfianza = !confianzaFilter || confianza.includes(confianzaFilter);
        const matchGaps = !gapsOnly || hasGaps;
        
        row.style.display = matchSearch && matchStatus && matchConfianza && matchGaps ? '' : 'none';
      });
    }
  </script>

  <style>
    body { background: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    header { padding: 2rem; border-bottom: 1px solid var(--border); }
    h1 { margin: 0; font-size: 1.8rem; }
    .meta { margin-top: 0.5rem; font-size: 0.9rem; color: var(--text2); display: flex; gap: 2rem; }
    
    .toolbar { padding: 1.5rem; background: var(--bg2); border-bottom: 1px solid var(--border); display: flex; gap: 1rem; }
    input, select { padding: 0.5rem; background: var(--bg); border: 1px solid var(--border); color: var(--text); border-radius: 4px; }
    
    table { width: 100%; border-collapse: collapse; margin: 1rem 0; }
    th { background: var(--bg2); padding: 0.8rem; text-align: left; font-weight: 600; border-bottom: 1px solid var(--border); }
    td { padding: 0.8rem; border-bottom: 1px solid var(--border); }
    tr:hover { background: var(--bg2); }
    
    .badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 0.85rem; font-weight: 600; }
    .badge.confirmed { background: rgba(63, 185, 80, 0.2); color: var(--confirmed); }
    .badge.inferred { background: rgba(227, 179, 65, 0.2); color: var(--inferred); }
    .badge.assumed { background: rgba(248, 81, 73, 0.2); color: var(--assumed); }
    
    .component { display: inline-block; padding: 2px 6px; margin-right: 0.3rem; border-radius: 3px; font-size: 0.85rem; }
    .component.scr { background: rgba(88, 166, 255, 0.15); color: #58a6ff; }
    .component.brn { background: rgba(193, 132, 252, 0.15); color: #c184fc; }
    .component.ent { background: rgba(63, 185, 80, 0.15); color: #3fb950; }
    
    .status { display: inline-block; padding: 3px 8px; border-radius: 3px; font-weight: 600; }
    .status.confirmado { background: rgba(63, 185, 80, 0.2); color: var(--confirmed); }
    .status.bloqueado { background: rgba(248, 81, 73, 0.2); color: var(--bloqueante); }
    
    .gap-link { color: var(--bloqueante); text-decoration: none; font-weight: 600; }
    .gap-link:hover { text-decoration: underline; }
    
    .summary { padding: 1.5rem; background: var(--bg2); border-top: 1px solid var(--border); }
    .summary h3 { margin-top: 0; }
    .summary ul { list-style: none; padding-left: 0; }
    .summary li { padding: 0.3rem 0; color: var(--text2); }
  </style>
</body>
</html>
```

---

## Reglas de Generación

### Para `requirements-registry.md`

1. **Orden:** FA-REQ-NNN creciente (FA-REQ-001, FA-REQ-002, ...)
2. **Campos obligatorios:**
   - ID, Descripción, Tipo (Funcional/No Funcional), Origen (HU-NNN / sección BRD / nombre Figma), Confianza (CONFIRMED/INFERRED/ASSUMED)
   - Componentes vinculados (SCR-NNN, BRN-NNN, ENT-NNN, ROL-NNN, INT-NNN)
   - Estado (CONFIRMADO / BLOQUEADO / EXCLUIDO)
   - Gaps vinculados (FA-GAP-NNN o "—" si ninguno)

3. **Secciones de auditoría:**
   - Requisitos huérfanos (sin componentes)
   - Requisitos solo ASSUMED (sin confirmación)

### Para `requirements-index.html`

1. **Búsqueda en vivo:** por ID, descripción, componentes
2. **Filtros:**
   - Por estado (CONFIRMADO, BLOQUEADO, EXCLUIDO)
   - Por confianza (CONFIRMED, INFERRED, ASSUMED)
   - Checkbox "solo con gaps"
3. **Colores consistentes** con open-questions.html (tema oscuro SDD)
4. **Componentes como badges de color:**
   - SCR → azul (#58a6ff)
   - BRN → púrpura (#c184fc)
   - ENT → verde (#3fb950)
5. **Resumen estadístico** al pie

---

## Frontmatter para ambos artefactos

```yaml
---
app-id: {app-id de fa-config.yml}
client-id: {client-id de fa-config.yml}
artifact: requirements-registry | requirements-index (HTML no tiene frontmatter, solo metadatos en <head>)
version: "1.0"
iteration: {iteration de fa-config.yml}
generated-at: {timestamp actual ISO 8601}
generated-by: fa-generate-requirements-index
status: in-progress (en FASE 2) | final (tras cierre WF1)
wf2-ready: false (en FASE 2) | true (tras fa-closure-gate)
---
```

---

## Validación

Antes de emitir los artefactos, verificar:

1. ✅ Todos los FA-REQ-NNN de `FA-SYNTHESIS-RESUMEN.md` están en el registry
2. ✅ Cada FA-REQ tiene al menos un componente vinculado (o está marcado como HUÉRFANO)
3. ✅ Sin duplicados de FA-REQ
4. ✅ HTML carga correctamente con búsqueda/filtros funcionales
5. ✅ Resumen estadístico coincide con conteos reales
