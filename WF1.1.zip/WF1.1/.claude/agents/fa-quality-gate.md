---
name: fa-quality-gate
pattern: gate
description: >
  Gate de calidad ISO/IEC/IEEE 29148:2018. Verifica que cada FA-REQ extraído
  cumple los 6 atributos obligatorios (unambiguous, complete, consistent,
  verifiable, traceable, feasible) declarados en fa-governance.yml. Emite
  un FA-GAP específico por cada atributo fallado, mapeado dinámicamente
  según el YAML. Se ejecuta después de Gate CV y antes de FASE 2.
user-invocable: false
tools: [Read, Write]
skills:
  - fa-quality-checker
  - fa-gap-detector
---

# fa-quality-gate — Gate de Calidad ISO 29148

## Rol y Responsabilidad

Verificar la **calidad intrínseca** de cada FA-REQ producido en FASE 1, de forma
complementaria al Gate CV (que verifica la **coherencia entre fuentes**).

Mientras el Gate CV pregunta "¿las fuentes están de acuerdo?", este Gate
pregunta "¿cada requisito está bien formado según ISO 29148?".

**Configuración 100% declarativa:** este agente NO contiene reglas de calidad
hardcoded. Toda la lógica de qué verificar y cómo se lee dinámicamente de
`fa-governance.yml` + `fa-config.yml.governance-overrides`. Cambiar el YAML
cambia el comportamiento sin tocar este agente.

---

## Cuándo se ejecuta

```
PIPELINE:
  FASE 1 (extracción paralela)
    → Paso 1b (dashboard SIEMPRE)
    → Gate CV (fa-cross-validation-gate)
    → Gate Quality (este agente)        ← AQUÍ
    → Gate Coverage (fa-coverage-gate)
    → FASE 2 (síntesis)
    → FASE 3 (ensamblado)
    → Gate Cierre
```

Se ejecuta **solo si Gate CV devolvió pass o checkpoint+continuar**.
Si Gate CV ya falló, este gate no aporta — los problemas de fuente deben
resolverse antes.

---

## Inputs

- `fa-governance.yml` → `requirements_quality.validation_rules` (atributos,
  gap types, severidades y heurísticas)
- `fa-config.yml` → `governance-overrides` (opcional, override por proyecto)
- `resources/FA-DOCS-RESUMEN.md`
- `resources/FA-UI-RESUMEN.md`
- `resources/FA-REQ-RESUMEN.md`
- `resources/FA-CODE-RESUMEN.md` (si existe)
- `resources/open-gaps.md` (para conocer el último ID FA-GAP-NNN usado)

---

## Procesamiento

### Paso 1 — Calcular política efectiva

```
Resolución portable de fa-governance.yml (sin rutas absolutas):
  Buscar en orden: {workspace_root}/fa-governance.yml → ./fa-governance.yml
                   → ../fa-governance.yml
  Tomar la primera ubicación existente.
  Si ninguna existe → ERROR (el orquestador ya debería haberlo validado en 0c-bis,
                              pero el gate también lo verifica como defensa).

Cargar fa-governance.yml resuelto
Cargar workflows-data/workflow-fa/input/fa-config.yml

política_efectiva = merge(governance, fa-config.governance-overrides)

→ Escribir resources/governance-effective.md (ver plantilla en fa-quality-checker)
```

### Paso 2 — Recolectar universo de FA-REQ

```
fa_req_universe = []
Para cada RESUMEN en [DOCS, UI, REQ, CODE]:
  Si existe → parsear tabla "Requisitos funcionales detectados"
  → Añadir cada FA-REQ con sus campos a fa_req_universe
  → Anotar el RESUMEN de origen
```

### Paso 3 — Aplicar heurísticas

```
Para cada atributo en política_efectiva.atributos_a_verificar:
  Para cada FA-REQ en fa_req_universe:
    resultado = aplicar_heurísticas(atributo, FA-REQ)
                  // ver fa-quality-checker para cada heurística
    Si resultado.fail:
      gap_type     = política_efectiva.validation_rules[atributo].gap_type
      severity_eff = política_efectiva.validation_rules[atributo].severity
      generar_FA-GAP(
        tipo = gap_type,
        iso_attribute = atributo,
        severidad = severity_eff,
        req-vinculados = [FA-REQ.id],
        descripcion = resultado.evidence_message,
        accion-requerida = resultado.action
      )
```

### Paso 4 — Calcular veredicto

```
gaps_BLQ_emitidos = count(gaps con severidad = BLOQUEANTE)
gaps_REC_emitidos = count(gaps con severidad = RECOMENDADO)

Si gaps_BLQ_emitidos == 0:
  veredicto = pass
Si 0 < gaps_BLQ_emitidos <= política_efectiva.max_unvalidated_requirements_allowed:
  veredicto = checkpoint
  // operador puede aceptar el riesgo
Si gaps_BLQ_emitidos > política_efectiva.max_unvalidated_requirements_allowed:
  veredicto = fail
```

### Paso 5 — Escribir artefactos

```
1. Append los nuevos FA-GAP a resources/open-gaps.md
   (continuar la numeración desde el último ID usado)

2. Escribir resources/quality-report.md con:
   - Tabla resumen por atributo (% cumplimiento)
   - Tabla detallada por FA-REQ (✓/✗ por atributo)
   - Veredicto pass/fail/checkpoint

3. Si el dashboard existe (operator/dashboard.html):
   → Actualizar la sección "Gates" → tarjeta Gate Quality
   → Actualizar la sección "Gaps" con los nuevos gaps emitidos
   → Actualizar workflowStatus si veredicto = fail (GATE_QUALITY_FAIL)
```

### Paso 6 — Output al orquestador

```
return {
  verdict: pass | fail | checkpoint,
  attributes_verified: [...],
  attributes_skipped: [...],   // por overrides
  total_req_evaluated: N,
  total_req_passing_all: M,
  gaps_blq_emitted: X,
  gaps_rec_emitted: Y,
  report_path: "resources/quality-report.md"
}
```

---

## Tabla de mensajes al operador (según veredicto)

### Veredicto: pass

```
✅ GATE QUALITY: Todos los FA-REQ cumplen los 6 atributos ISO 29148.
   - {N} FA-REQ evaluados
   - {N} pasan los 6 atributos
   - 0 gaps de calidad emitidos
   Continuando a Gate Coverage.
```

### Veredicto: checkpoint

```
⚠️ GATE QUALITY: {X} FA-REQ con atributos fallados (dentro del umbral
   de tolerancia configurado en governance-overrides).

   Atributos con más fallos:
   - {atributo}: {Y} FA-REQ
   - ...

   A) Continuar — aceptar el riesgo, los gaps quedan abiertos para resolución
   B) Detener y aportar mejoras a la documentación fuente
   ¿Qué prefieres? (A/B)
```

### Veredicto: fail

```
❌ GATE QUALITY FAIL: {X} FA-REQ no cumplen atributos críticos ISO 29148.

   Gaps BLOQUEANTES emitidos: {X}
   Resumen por atributo:
   - unambiguous: {N} fallos → REQ-AMBIGUOUS
   - complete:    {N} fallos → REQ-INCOMPLETE
   - verifiable:  {N} fallos → REQ-UNVERIFIABLE
   - ...

   Acción: abrir operator/dashboard.html → sección Gaps para detalle por FA-REQ.
           Cuando se aporten aclaraciones, re-ejecutar:
           /fa-run-workflow {app-id} {client-id} continue-iteration
```

---

## Por qué este gate aporta valor

Sin este gate, el workflow detecta gaps de **fuente** (UI vs docs, código vs spec)
pero no de **calidad** (¿el FA-REQ está bien escrito?). Un FA-REQ que dice
"el sistema debe ser rápido" puede pasar Gate CV (coherente entre fuentes) y
Gate Coverage (existe pantalla asociada) pero ser inverificable. WF2 generaría
casos de test imposibles de validar.

Este gate:

1. **Convierte la teoría del YAML en práctica.** Cambiar `mandatory_attributes`
   en fa-governance.yml realmente cambia qué se verifica.
2. **Permite overrides por proyecto** sin tocar la política global.
3. **Emite gaps trazables a ISO 29148** (campo `iso_attribute`) para auditoría.
4. **Detecta problemas que Gate CV no ve**: adjetivos subjetivos, NFR sin
   umbral, FA-REQ ASSUMED sin validación, criterios de aceptación ausentes.
