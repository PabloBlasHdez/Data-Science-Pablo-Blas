---
name: cilantrum-context
description: >
  Contexto de referencia sobre qué es Cilantrum: el framework de pruebas automáticas de Santander
  basado en Cucumber + Selenium + Java/Maven. Usa este skill cuando necesites saber qué es
  Cilantrum, cómo funciona, cómo está estructurado, cómo configurarlo en Gluon, qué archivos
  genera, o cómo ejecutarlo. También aplica si alguien pregunta "qué tecnologías usa Cilantrum",
  "dónde está la documentación de Cilantrum", "cómo creo un componente Cilantrum en Gluon",
  o "qué es un .feature". Este skill es de solo lectura — no ejecuta ni genera nada.
  Para ejecutar tests usa la skill 3A `run-cilantrum-tests`.
  Para generar archivos .feature y Steps.java usa la skill 2B `generate-front-test-scripts`.
metadata:
  author: "GitHub Copilot"
  version: "1.0"
  category: "testing"
  source: "https://sanes.atlassian.net/wiki/spaces/ESPNRSDATA/pages/26431258847/Cilantrum"
  last-sync: "2025-06-20"
---

# Cilantrum — Contexto del framework

Referencia de conocimiento sobre **Cilantrum**, el framework de pruebas automáticas de Santander.

> **Para ejecutar tests Cilantrum** usa la skill 3A `run-cilantrum-tests`.
> **Para generar archivos `.feature` + `Steps.java`** usa la skill 2B `generate-front-test-scripts`.

---

## ¿Qué es Cilantrum?

Cilantrum es un **framework de pruebas desarrollado para Santander** que unifica todo el proceso
de desarrollo de pruebas automáticas bajo una única estructura de trabajo.

Se utiliza para **pruebas funcionales** tanto **Web** como **API (backend)** utilizando:
- **Java** (11 o 17)
- **Maven**
- **Selenium**

---

## Tecnologías internas

| Componente | Rol |
|---|---|
| **Cucumber** | Motor BDD que interpreta `.feature` (Gherkin) y los conecta con step definitions Java |
| **Selenium** | Automatización de navegadores (Chrome, Firefox, Edge) |
| **Maven** | Gestión de dependencias y ejecución |
| **Java 11/17** | Lenguaje de los step definitions y hooks |

---

## Requisitos

- Java 11 o Java 17
- Un excel para manipular las pruebas (estructura propia de Cilantrum)
- Drivers de navegador:
  - **Chrome**: https://googlechromelabs.github.io/chrome-for-testing/
  - **Firefox**: https://github.com/mozilla/geckodriver/releases
  - **Edge**: https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/

---

## Versionado

Para consultar qué versión de Cilantrum usar:
https://gluon.gs.corp/community/docs/latest/application/testing/workflows/utilities/check-version/

---

## Configuración en Gluon

Para crear un componente Cilantrum en Gluon:

1. Ir a https://gluon.gs.corp/gluon/
2. Seleccionar el proyecto
3. Menú izquierdo → **Componentes** → **Nuevo componente**
4. Buscar "cilantrum" en el buscador de templates
5. Seleccionar la tarjeta y rellenar los datos

Esto genera automáticamente el repositorio con la estructura base del proyecto Cilantrum.

---

## Documentación oficial

- **Framework**: https://gluon.gs.corp/community/docs/latest/components/configuration/testing/cilantrum/framework/
- **Configuración**: https://sanes.atlassian.net/wiki/spaces/ESPNRSDATA/pages/26431259105/Configurar+Cilantrum
- **Referencia Confluence**: https://sanes.atlassian.net/wiki/spaces/ESPNRSDATA/pages/26431258847/Cilantrum

---

## Ejecución (remota vía Gluon Testing OnDemand)

Cilantrum **no se ejecuta localmente** — siempre a través de **Gluon Testing OnDemand**.

| Operación | Herramienta MCP |
|---|---|
| Buscar proyecto | `mcp_gluon_search_gtesting_ondemand_functional_testprojects` |
| Nueva ejecución | `mcp_gluon_execute_gtesting_ondemand_functional_test` |
| Re-ejecución | `mcp_gluon_reexecute_gtesting_ondemand_functional_test` |
| Ver resultados | `mcp_gluon_get_gtesting_functional_execution_details` |
| Ver logs | `mcp_gluon_get_gtesting_functional_execution_log` |
| Descargar reporte | `mcp_gluon_download_gtesting_functional_execution_report` |

---

## Estructura de archivos generada

Un proyecto Cilantrum sigue esta estructura dentro del repo:

```
[repo-destino]/
└── src/test/
    ├── resources/features/
    │   ├── [flujo-1].feature        # Gherkin — escenarios BDD
    │   └── [flujo-2].feature
    └── java/steps/
        ├── [Flujo1]Steps.java       # Step definitions (Selenium)
        ├── [Flujo2]Steps.java
        └── hooks/WebDriverHooks.java # Setup/teardown del WebDriver
```

---

## Gotchas

- **Ejecución siempre remota**: Cilantrum no tiene runner local. Cualquier intento de ejecutar `mvn test` localmente requiere configuración especial de drivers. Para ejecuciones del día a día, usar siempre Gluon Testing OnDemand.
- **Versión de Java**: usar Java 11 o 17. Java 8 no es compatible con las versiones actuales de Cilantrum.
- **BDD con Cucumber**: los `.feature` usan sintaxis Gherkin (`Given`, `When`, `Then`, `And`). Cada step del `.feature` debe tener su correspondiente anotación en el `Steps.java` (`@Given`, `@When`, `@Then`).
- **Drivers de navegador**: los drivers (chromedriver, geckodriver) deben coincidir con la versión del navegador instalada. Para ejecución remota en Gluon Testing, los drivers están gestionados por la plataforma.
- **Excel de gestión**: Cilantrum usa un fichero Excel con estructura propia para gestionar los casos de test. Sin él, no se puede operar la batería de pruebas en el portal de Gluon.

---

## Comandos de ejemplo para el usuario

> "¿qué es Cilantrum?"
> "¿qué tecnologías usa Cilantrum?"
> "¿cómo creo un componente Cilantrum en Gluon?"
> "¿qué es un archivo .feature?"
> "¿cómo se estructura un proyecto Cilantrum?"
> "¿dónde está la documentación de Cilantrum?"
> "¿qué versión de Java necesita Cilantrum?"
