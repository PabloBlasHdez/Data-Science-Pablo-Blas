# SKILL: Diseño de Casos de Test a partir de Historias de Usuario (BDD/Gherkin)

## Propósito

Esta skill define la **metodología y formato** para generar documentos de casos de test a partir de Historias de Usuario (HUs / PBIs), con independencia del dominio o proyecto.

El input son HUs con su descripción y criterios de aceptación. La skill responde a la pregunta **"¿cómo se diseña y estructura el documento?"**. El agente que la usa es quien accede a las HUs, toma las decisiones y escribe el fichero.

---

## Estructura del Documento

El documento tiene cuatro partes fijas, en este orden:

1. **Cabecera** — metadatos de la release y las HUs analizadas
2. **Tabla de flujo** — mapa visual del recorrido del usuario (si la operativa tiene canales o pasos diferenciados)
3. **Features** — un bloque `Feature` por HU o grupo funcional coherente, con sus `Scenario`s en Gherkin
4. **Notas funcionales** — textos verbatim extraídos literalmente de las HUs

---

## Parte 1 — Cabecera

```markdown
# Casos de Test — {Nombre de la funcionalidad}

## Información del Documento

| Campo | Valor |
|---|---|
| **Release / Epic** | {KEY} |
| **Funcionalidad** | {Nombre} |
| **Fecha de generación** | {FECHA} |
| **Historias de usuario analizadas** | {KEY — Resumen}, {KEY — Resumen}, … |
| **Total de escenarios** | {N} |
```

---

## Parte 2 — Tabla de Flujo (opcional)

Incluir solo cuando la funcionalidad tiene un flujo multipaso o varía por canal/rol. Construirla a partir del contenido real de las HUs, no de una plantilla fija.

```markdown
## Flujo por {Canal / Rol / Perfil}

| {Variable} | Paso 1 | Paso 2 | Paso 3 | … |
|---|---|---|---|---|
| {Valor 1} | … | … | … | … |
| {Valor 2} | … | … | … | … |
```

---

## Parte 3 — Features y Escenarios (Gherkin)

### Un Feature por HU o grupo funcional

Cada HU —o grupo de HUs cohesionadas— genera un bloque `Feature`. El título del `Feature` refleja el comportamiento funcional que se está probando, no el nombre técnico de la HU.

```markdown
## Feature: {Comportamiento funcional a probar}

> HU de referencia: {KEY} — {Resumen}
```

---

### Formato de un Scenario

```gherkin
@CT-{PREFIJO}-{NNN} @{tipo}
Scenario: {Descripción del comportamiento en lenguaje de negocio}
  Given {estado previo del sistema o del usuario}
  When {acción que realiza el usuario o el sistema}
  Then {resultado observable esperado}
  And {condición adicional, si aplica}
```

**Reglas de escritura**:
- `Given` — contexto: quién es el usuario, en qué estado está el sistema
- `When` — acción única y concreta (una sola acción por `When`)
- `Then` — resultado observable desde el punto de vista del usuario
- `And` / `But` — extensión del paso anterior, no acción nueva
- Usar lenguaje de negocio, no de implementación: «el usuario ve», no «el componente renderiza»
- Los textos de UI (modales, errores, etiquetas) van **literales** entre comillas: `«texto exacto»`

---

### Nomenclatura de IDs

```
CT-{PREFIJO}-{NNN}
```

- `PREFIJO`: 2-4 letras mayúsculas derivadas del nombre de la Feature o HU. El agente elige el prefijo según el contenido — no hay prefijos predefinidos.
- `NNN`: número secuencial de tres dígitos empezando en `001`, reiniciado en cada Feature.
- Los IDs se asignan como **tags** Gherkin: `@CT-ACC-001`

---

### Tags de tipo

Añadir siempre un segundo tag que clasifique el escenario:

| Tag | Cuándo usarlo |
|---|---|
| `@positivo` | Flujo correcto, camino feliz, entrada válida |
| `@negativo` | Error esperado, dato inválido, permiso denegado |
| `@borde` | Condición límite, valor extremo, caso atípico |

---

### Casos paramétricos con Scenario Outline

Cuando un mismo comportamiento aplica a múltiples combinaciones de datos, usar `Scenario Outline` en lugar de repetir scenarios:

```gherkin
@CT-{PREFIJO}-{NNN} @positivo
Scenario Outline: {Descripción con variantes}
  Given {contexto con <variable>}
  When {acción con <variable>}
  Then {resultado esperado es <resultado>}

  Examples:
    | variable | resultado |
    | valor_1  | esperado_1 |
    | valor_2  | esperado_2 |
```

Usar `Scenario Outline` cuando hay 3 o más combinaciones. Para 2 o menos, preferir scenarios independientes.

---

### Cobertura esperada por HU

**No hay un número fijo de escenarios por HU.** La cobertura se deriva directamente del contenido de cada HU:

- Por cada **criterio de aceptación** → al menos un scenario `@positivo`
- Por cada **regla de negocio con condición** (si X entonces Y) → un scenario `@positivo` y uno `@negativo`
- Por cada **mensaje de error** descrito en la HU → un scenario `@negativo`
- Por cada **valor límite** explícito en la HU → un scenario `@borde`
- Por cada **variación de canal, rol o perfil** que cambie el comportamiento → un scenario por variante (o un `Scenario Outline`)

> Una HU con 3 criterios de aceptación simples puede generar 4-6 escenarios. Una HU con matrices de comportamiento por canal puede generar 15+. El volumen lo dicta el contenido, no la sección.

---

### Escenarios transversales

Al final del documento, incluir una Feature para los comportamientos transversales que aplican a toda la funcionalidad independientemente de las HUs específicas:

```gherkin
## Feature: Comportamiento transversal

@CT-TRV-001 @negativo
Scenario: Sesión expirada durante el flujo
  Given el usuario lleva más de {tiempo de timeout} sin interacción
  When intenta continuar con cualquier acción
  Then se le redirige a la pantalla de login
  And se muestra el mensaje de sesión expirada

@CT-TRV-002 @negativo
Scenario: Error técnico en cualquier llamada al servidor
  Given el servidor devuelve un error 500
  When el usuario realiza cualquier acción que requiera llamada al backend
  Then se muestra un mensaje de error genérico
  And el usuario tiene la opción de reintentar

@CT-TRV-003 @borde
Scenario: Navegación con el botón «Atrás» del navegador
  ...

@CT-TRV-004 @borde
Scenario: Recarga de página en un paso intermedio del flujo
  ...

@CT-TRV-005 @positivo
Scenario: Navegación completa accesible por teclado
  Given un usuario que navega únicamente con teclado
  When recorre todos los elementos interactivos de la pantalla
  Then el orden del foco es lógico y todos los elementos son alcanzables
  And se cumplen los criterios WCAG AA de accesibilidad
```

---

## Parte 4 — Notas Funcionales

Al final del documento, una subsección por HU con los textos exactos extraídos de su descripción. Estos textos son la fuente de verdad para los valores literales usados en los scenarios.

```markdown
## Notas Funcionales

### {KEY} — {Resumen de la HU}
- **Textos de UI** (modales, títulos, botones): «{texto exacto}»
- **Mensajes de error**: «{texto exacto}»
- **Cuadros informativos**: «{texto exacto}»
- **Reglas de negocio**: {descripción tal como aparece en la HU}
- **Variaciones por canal / rol / perfil**: {tabla o lista}
```

---

## Reglas de Redacción

### Lenguaje de negocio
Los escenarios deben ser comprensibles por alguien de negocio sin conocimientos técnicos. Evitar referencias a componentes, APIs, clases o IDs de HTML.

### Textos verbatim
Cualquier texto que aparezca en la UI debe copiarse **exactamente** de la HU, entre «comillas angulares». Nunca parafrasear.

### Una acción por When
Cada `When` describe una sola acción del usuario. Si el escenario requiere varios pasos previos de setup, añadirlos como `And` en el bloque `Given`.

### Independencia de escenarios
Cada `Scenario` debe poder ejecutarse de forma independiente. El `Given` debe establecer todo el contexto necesario sin asumir el estado de un scenario anterior.

---

## Checklist de Calidad

- [ ] Cada HU tiene al menos un `Feature` que la cubre
- [ ] Todos los criterios de aceptación del HU tienen un `Scenario` correspondiente
- [ ] Los IDs `CT-XXX-NNN` son secuenciales dentro de cada Feature (sin huecos ni duplicados)
- [ ] Los textos verbatim de UI están entre «comillas angulares» y son exactos
- [ ] Cada `Scenario` tiene exactamente un `When`
- [ ] Los `Scenario Outline` tienen tabla `Examples` con al menos 2 filas
- [ ] La Feature transversal está presente y tiene al menos 5 scenarios
- [ ] El lenguaje es de negocio, no técnico
- [ ] Todos los scenarios tienen tag de ID (`@CT-XXX-NNN`) y tag de tipo (`@positivo` / `@negativo` / `@borde`)

---

## Workflow de Ejecución

Esta sección define el flujo paso a paso que debe seguir el agente para aplicar esta skill. Es la guía operativa que complementa la metodología anterior.

**Tools necesarias**: `mcp_atlassian_get_jira_issue`, `mcp_atlassian_search_issues_with_jql`, `mcp_atlassian_bulk_fetch_issues`, `mcp_atlassian_check_atlassian_config`, `read_file`, `create_file`, `manage_todo_list`, `vscode_askQuestions`

---

### Fase 0 — Recoger inputs

Preguntar al usuario:

1. **Release key o Epic key** en Jira (ej. `ESPREGINVC-20449`)
2. **Nombre de la funcionalidad** (ej. `Cambio de cuenta de comisiones`)
3. **Carpeta de salida** (por defecto: `c:\Users\x698186\Projectos\Casos de test`)
4. **Nombre del fichero** (por defecto: `casos_test_{slug_funcionalidad}.md`)

---

### Fase 1 — Obtener las HUs desde Jira

**Dominio**: `sanes.atlassian.net` | **Auth**: configurado vía MCP de VS Code

1. Ejecutar JQL: `issue in linkedIssues({RELEASE_KEY})`

   > Si `linkedIssues` no devuelve resultados, intentar: `project = {PROJECT} AND fixVersion = "{RELEASE_KEY}"`
   > Si hay problemas de conexión: ejecutar `mcp_atlassian_check_atlassian_config`

2. Filtrar resultados:
   - **Procesar**: `Story`, `Historia de Usuario`, `PBI`, `Sub-task`
   - **Descartar**: `Epic`, `Workpackage`, `Initiative`, `Release`

3. Para cada HU, obtener con `mcp_atlassian_get_jira_issue`:
   - `summary`
   - `description` completa (incluye tablas, listas, condiciones)
   - Criterios de aceptación (campo custom o embebido en description)

4. Mostrar al usuario la lista de HUs encontradas y pedir confirmación antes de continuar.

---

### Fase 2 — Analizar y clasificar cada HU

Para cada HU, determinar:

1. **¿Qué comportamiento funcional describe?** → Será el título del `Feature`
2. **¿Qué prefijo de ID le corresponde?** → Derivar 2-4 letras del nombre de la Feature (el agente decide según el contenido)
3. **¿Qué textos de UI aparecen literales?** → Extraer: modales, errores, cuadros informativos, etiquetas
4. **¿Hay variaciones por canal, rol o perfil?** → Identificar si aplica `Scenario Outline`
5. **¿Cuántos escenarios genera esta HU?** → Uno por criterio de aceptación + uno negativo por cada regla condicional + uno borde por cada límite explícito

---

### Fase 3 — Generar el documento

Construir el documento siguiendo la estructura de las Partes 1 a 4 definidas en esta skill:

1. **Cabecera** con los metadatos de la release y las HUs analizadas
2. **Tabla de flujo** si la funcionalidad tiene pasos o canales diferenciados
3. **Un bloque `Feature` por HU** con todos sus `Scenario`s en Gherkin
4. **Feature transversal** al final con los escenarios de sesión, error 500, accesibilidad, etc.
5. **Notas funcionales** con los textos verbatim extraídos por HU

Reglas obligatorias durante la generación:
- Nunca parafrasear textos de UI: copiar literal entre `«»`
- Un solo `When` por `Scenario`
- Cada `Scenario` es independiente (el `Given` establece todo el contexto)
- Usar `Scenario Outline` cuando hay 3 o más combinaciones del mismo comportamiento
- Tags obligatorios: `@CT-XXX-NNN` y `@positivo` / `@negativo` / `@borde`

---

### Fase 4 — Escribir el fichero y validar

1. Crear el fichero `.md` en la carpeta indicada con `create_file`
2. Pasar el **Checklist de Calidad** definido en esta skill
3. Reportar al usuario:
   - Número de Features generadas
   - Número de Scenarios totales y por Feature
   - Cualquier incidencia detectada en el checklist

