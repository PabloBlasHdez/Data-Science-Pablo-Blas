# Plantilla de reporte de análisis — Skill 2A (Back / Newman)

Usa esta plantilla al finalizar el análisis para presentar el plan al usuario.
Adapta cada sección según lo encontrado.

---

## Análisis completado — [Nombre del proyecto]

> **Fecha**: [fecha]  
> **Repo back**: [ruta/nombre]  
> **Colección Newman existente**: [nombre del .json]

---

### 📦 Colección Newman existente

| Elemento | Detalle |
|---|---|
| Carpetas existentes | [lista] |
| Requests existentes | [N] |
| Variables de colección | `{{baseUrl}}`, `{{token}}`, [otras...] |
| Auth configurado | [sí/no — tipo: OAuth2 client_credentials / otro] |

---

### 🔌 API Backend

| Elemento | Detalle |
|---|---|
| Framework | [Spring Boot / Gluon / otro] |
| Base URL (DEV) | [si está en config] |
| Autenticación | [OAuth2 / Basic / ninguna] |
| Swagger/OpenAPI | [sí/no — path si existe] |

**Endpoints identificados:**

| Método | Path | Descripción |
|---|---|---|
| GET | `/api/v1/...` | [descripción] |
| POST | `/api/v1/...` | [descripción] |
| ...  | ...           | ... |

---

### 📋 Plan — Carpeta nueva a añadir

| Request a generar | Endpoint | Caso de test |
|---|---|---|
| CT-API-001 | GET /api/v1/... | Happy path (200) |
| CT-API-002 | POST /api/v1/... | Creación (201) |
| CT-API-003 | GET /api/v1/.../999 | No encontrado (404) |
| CT-API-004 | POST /api/v1/... | Validación fallida (400) |

**Variables reutilizadas**: `{{baseUrl}}`, `{{token}}`, [...]  
**Variables nuevas necesarias**: `{{portfolioId}}`, `{{customerId}}`, [...]

---

### ⚠️ Advertencias / lagunas

- [ ] [Advertencia 1 — ej: "{{customerId}} requiere un ID real del entorno DEV"]
- [ ] [Advertencia 2 — ej: "el caso CT-ACC-003 es de front (modal UI), no tiene endpoint API"]
- [ ] [Advertencia 3 — ej: "endpoint PUT /api/v1/... no tiene caso de test en el .md"]

---

**¿Procedo con la generación de la carpeta de tests dentro de la colección?**
