---
name: openapi-extractor
description: >
  Mapeo de contratos OpenAPI/Swagger/RAML a integraciones externas INT-NNN y
  entidades de datos ENT-NNN. Activo cuando existen ficheros .yaml, .json, .raml
  en input/specs/. Extrae endpoints, schemas y operaciones como contexto funcional.
---

# openapi-extractor — Extracción de Contratos API

> **Scope:** Extracción funcional de contratos de API en WF1-FA
> **Cubre:** mapeo-endpoints-int, schemas-a-entidades, operaciones-a-funciones, yaml-json-raml
> **No cubre:** implementación del cliente API — eso es WF2/WF3

## Activación

Se activa cuando existen ficheros en `input/specs/` con extensión:
- `.yaml` o `.json` que contienen `openapi:` o `swagger:` en el contenido
- `.raml` (contratos RAML)

También activo si `input/remote/confluence.yml` apunta a una página con API docs.

## Mapeo OpenAPI → FA

### Endpoints → Integraciones INT-NNN

Cada API externa que la aplicación consume se registra como `INT-NNN`:

```
Por cada servidor/base-URL en el contrato:
  → Crear INT-NNN: "Integración con {nombre del servicio}"

Por cada path/operación del contrato:
  → Vincular operación a INT-NNN
  → Extraer: método HTTP, path, descripción de la operación
  → Si hay FA-REQ o SCR que usa esta operación → vincular
```

**Ejemplo:**
```yaml
# clientes-api.yaml
openapi: 3.0.0
info:
  title: Clientes API
  description: API de consulta de clientes del sistema CRM
paths:
  /clientes/{id}:
    get:
      summary: Obtener cliente por ID
      description: Devuelve los datos del cliente para visualización en pantalla
```

```markdown
→ INT-001 — Clientes API
   - tipo: Consulta (GET)
   - endpoint: GET /clientes/{id}
   - descripcion: Obtener datos de cliente para SCR-001 (Búsqueda)
   - fa-req-vinculados: FA-REQ-001 (deducido del contexto)
   - detalles: contrato disponible en input/specs/clientes-api.yaml
   - confianza: CONFIRMED (contrato formal)
```

### Schemas → Entidades ENT-NNN

Los schemas de request/response del contrato revelan las entidades funcionales:

```
Por cada schema en components/schemas:
  → Crear o enriquecer ENT-NNN con los campos del schema
  → Los campos con descripción → usar como descripción funcional del campo
  → Los campos required → marcar como obligatorios
  → Los campos con enum → documentar los valores posibles
  → Los campos con format → documentar formato funcional (date, email, etc.)
```

**Ejemplo:**
```yaml
components:
  schemas:
    Cliente:
      properties:
        id:
          type: integer
          description: Identificador único del cliente
        nombre:
          type: string
          description: Nombre completo o razón social
        nif:
          type: string
          description: NIF o CIF del cliente
          pattern: "^[0-9]{8}[A-Z]$"
```

```markdown
→ ENT-002 — Cliente (enriquecida con campos del contrato)
   - id: integer (obligatorio) — Identificador único
   - nombre: string (obligatorio) — Nombre completo o razón social
   - nif: string (obligatorio) — NIF/CIF, formato: 8 dígitos + letra
```

## Extracción de RAML

RAML tiene estructura similar a OpenAPI pero con sintaxis distinta:

```raml
#%RAML 1.0
title: Contratos API
/contratos:
  /{id}:
    get:
      description: Obtener contrato por ID
      responses:
        200:
          body:
            application/json:
              type: Contrato
types:
  Contrato:
    properties:
      id: integer
      cliente: string
```

→ Aplicar misma lógica de mapeo que OpenAPI.

## Casos Especiales

### API interna vs. API externa
- Si el contrato describe la API que la propia aplicación expone → pasar a WF2 (no es una integración FA)
- Si el contrato describe una API que la aplicación CONSUME → INT-NNN

### Contratos parciales o sin descripción
Si el contrato tiene endpoints pero sin descripciones funcionales:
→ Extraer la información técnica disponible
→ Marcar la INT-NNN con confianza INFERRED
→ Si hay FA-REQ que depende de esta API → verificar que el contrato cubre las operaciones necesarias

### Autenticación en el contrato
Si el contrato especifica `securitySchemes` → información para NFR de seguridad:
→ `type: oauth2` → NFR: autenticación OAuth2 requerida
→ `type: apiKey` → NFR: API Key management
→ Añadir al extracto de `fa-nfr-extractor`
