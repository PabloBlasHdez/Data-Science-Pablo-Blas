---
name: fa-run-workflow
description: >
  Orquestador principal del WF1 Functional Analysis. Ejecuta el pipeline completo:
  PRE-CONDICIÓN (config, validación, sizing) → FASE 1 (extracción paralela de 4
  agentes) → Gates CV+Coverage → FASE 2 (síntesis, enriquecimiento, gaps, NFR) →
  FASE 3 (ensamblado) → Gate de cierre → Paquete fa-prerequisites.md para WF2.
  Gestiona el ciclo iterativo bajo control del operador.
argument-hint: <app-id> <client-id> <full|update-sources|reassemble|continue-iteration>
---

# fa-run-workflow — Orquestador WF1 Functional Analysis

## Invocación

```
/fa-run-workflow $0 $1 $2
```

| Parámetro | Descripción        | Ejemplos                                              |
|-----------|--------------------|-------------------------------------------------------|
| `$0`      | App ID del proyecto | `MYAPP`, `PORTAL`, `PRU1`                            |
| `$1`      | Client ID del cliente | `acme`, `bbva`, `demo`, `prueba`                  |
| `$2`      | Modo de ejecución  | `full`, `update-sources`, `reassemble`, `continue-iteration` |

**Ejemplos completos:**
```bash
# Análisis completo — cualquier tipo de proyecto
/fa-run-workflow MYAPP acme full

# Continuar tras resolver gaps del operador
/fa-run-workflow MYAPP acme continue-iteration

# Solo re-ensamblar output (RESUMENes ya están en resources/)
/fa-run-workflow MYAPP acme reassemble
```

> Las rutas al código fuente y contratos se declaran en `fa-config.yml` bajo `sources.code.path`
> y `sources.contracts.path`. El workflow las resuelve automáticamente desde la configuración —
> no se pasan como parámetros.

---

## PRE-CONDICIÓN — Paso 0

### 0. Resolver modo de ejecución

```
Leer $4 → modo = full | update-sources | reassemble | continue-iteration

Si $4 no se proporciona → asumir modo = full
```

### 0b. Verificar o crear fa-config.yml

```
Buscar workflows-data/workflow-fa/input/fa-config.yml

Si NO existe → MODO INTERACTIVO (solo en modo full):
  Mostrar formulario de configuración:

  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  No se encontró fa-config.yml.
  Vamos a configurar el proyecto WF1-FA.
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  App ID (ej: MYAPP): {$0 si se proporcionó, si no preguntar}
  Client ID (ej: acme): {$1 si se proporcionó, si no preguntar}
  Tipo de proyecto [new | migration | modification | incident]: _
  Descripción breve del proyecto: _
  Tecnología de salida — frontend (ej: angular, react, vue): _
  Tecnología de salida — backend (ej: dotnet, java, python, o "-" si no aplica): _
  ¿Hay código fuente disponible? Ruta (o Enter para usar input/source-app/ por defecto): _
  ¿Fuentes remotas? Indicar herramientas separadas por coma [Jira / Figma / Confluence / ninguna]: _

  → Si la respuesta NO es "ninguna" (o vacío), abrir el SUB-DIÁLOGO de configuración
    remota POR CADA herramienta indicada (Jira, Figma, Confluence, ADO, Notion,
    SharePoint), uno detrás de otro:

    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Configurar fuente remota: {tool}
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Por seguridad, NO se solicita el valor del token.
    Solo el NOMBRE de la variable de entorno donde lo tienes guardado.

    URL del sistema (ej: https://empresa.atlassian.net): _
    Identificador del proyecto/espacio/file-key: _
    ¿MCP nativo configurado para esta herramienta? (s/n): _
       Si s → Nombre del MCP server (ej: jira-mcp): _

    Esquema de autenticación:
       [a] Token único (PAT, API key)
       [b] Basic (usuario + clave/PAT)
       [c] OAuth client credentials (client_id + client_secret)
       Respuesta: _

       Si a → Nombre de la variable con el token
              (ej: JIRA_TOKEN — solo el NOMBRE, NUNCA el valor): _
       Si b → Nombre de la variable con el usuario  (ej: FIGMA_USER):     _
              Nombre de la variable con la clave/PAT (ej: FIGMA_PASSWORD): _
       Si c → Nombre de la variable con el client_id     (ej: SP_CLIENT_ID):     _
              Nombre de la variable con el client_secret (ej: SP_CLIENT_SECRET): _

       ⚠️ TODAS las credenciales se piden por NOMBRE de variable de entorno.
          El valor real vive en tu shell o gestor de secretos y NUNCA se escribe
          en ningún fichero del repositorio.

    Descripción breve (opcional): _

    Si {tool} = jira → continuar con el SUB-DIÁLOGO DE ALCANCE DE JIRA:

      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Alcance del análisis Jira ({project})
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Tipo de elemento de entrada:
        [a] Épica  — se extraerán todas las HDU vinculadas a la(s) épica(s)
        [b] HDU    — se extraerán solo las HDU indicadas
      Respuesta: _

      ¿Es una o varias?
        [a] Una sola
        [b] Varias
      Respuesta: _

      Identificador(es):
        - Si "Una sola"  → una clave (ej: MYAPP-EP-001 o MYAPP-123)
        - Si "Varias"    → lista separada por coma
                           (ej: MYAPP-EP-001, MYAPP-EP-002
                            o MYAPP-1, MYAPP-2, MYAPP-15)
      Valor: _

      → Estos tres campos se persisten en input/remote/jira.yml como:
           scope:
             kind: epic | story         # según el tipo elegido
             keys: [<lista de claves>]  # siempre array
         (ver fa-source-scanner § "Sub-diálogo específico de Jira" para
          el detalle de validaciones).

    Validaciones aplicadas (ver fa-source-scanner § "Validaciones aplicadas
    tras el diálogo" para la lista completa):
      • URL debe empezar por https://
      • Esquema de autenticación debe ser a, b o c
      • TODOS los nombres de variable (token, user, password, client_id,
        client_secret según esquema) deben cumplir ^[A-Z][A-Z0-9_]*$
      • Detección de secretos accidentales — aplicada a TODOS los campos
        de credenciales: rechazar entradas con ':', '/', '@', espacios o
        cadenas mixtas largas (probable valor literal)
      • scheme=basic exige nombres distintos para user y password
      • scheme=oauth exige nombres distintos para client_id y client_secret
      • Verificar que cada variable está definida en el entorno actual
        (solo advertencia, no bloquea)
      • Solo Jira: claves deben cumplir ^[A-Z][A-Z0-9]*-[A-Z0-9-]+$
        y el prefijo de proyecto debe coincidir con el campo "Identificador
        del proyecto"; coincidencia simple advertencia, no bloquea

    → Por cada herramienta configurada, escribir:
         workflows-data/workflow-fa/input/remote/{tool}.yml
       con el formato canónico (api-token: ${VAR_NAME}, NUNCA el valor literal).

    Si el operador cancela el sub-diálogo de una herramienta concreta:
      → No escribir su .yml
      → Excluir esa herramienta de sources.* en fa-config.yml
      → Mostrar aviso: "{tool} no configurada — se omitirá del análisis"

  → Generar fa-config.yml con los valores proporcionados
  → Crear estructura de directorios con ficheros .gitkeep para garantizar visibilidad:
      workflows-data/workflow-fa/input/docs/.gitkeep
      workflows-data/workflow-fa/input/screens/.gitkeep
      workflows-data/workflow-fa/input/specs/.gitkeep
      workflows-data/workflow-fa/input/remote/.gitkeep
      workflows-data/workflow-fa/output/.gitkeep
      workflows-data/workflow-fa/resources/.gitkeep
      workflows-data/workflow-fa/operator/.gitkeep

  ── DECISIÓN: ¿abortar el bootstrap o continuar a FASE 1? ────────────────
  → Inventariar input/docs/, input/screens/ e input/specs/ (excluyendo .gitkeep):
       N_docs    = nº de ficheros relevantes en input/docs/
       N_screens = nº de ficheros relevantes en input/screens/
       N_specs   = nº de ficheros relevantes en input/specs/

  Caso A — input/ VACÍO (N_docs + N_screens + N_specs == 0):

    ⚠️ OBLIGATORIO antes de salir del bootstrap — escribir los artefactos
       de cierre de ITER-001 para que el operador tenga trazabilidad:

    → Escribir resources/iteration-tracker.md con la entrada ITER-001:
         | ITER-001 | {fecha} | full | ABORTED — Sin fuentes | Bootstrap inicial:
           se generaron fa-config.yml, estructura input/ y Client Skill.
           FASE 1 no se ejecutó porque input/{docs,screens,specs}/ están vacíos.
           Próxima iteración: depositar fuentes y re-ejecutar en modo
           `continue-iteration` (NO en `full` — `full` borraría esta entrada
           del dashboard y reiniciaría el contador ITER-NNN). |

    → Escribir resources/source-fingerprint.md con fingerprint vacío
       (referencia base para futuros modos continue-iteration / update-sources;
        sirve para que la próxima iteración detecte como NUEVOS todos los ficheros)

    → Escribir resources/complexity-assessment.md con APP_SIZE=indeterminado
       (sin contenido que medir; se recalculará en la siguiente iteración)

    → Escribir operator/dashboard.html con ITER-001 en estado ABORTED:
         - workflowStatus: "ABORTED"
         - statusLabel:    "Bootstrap completado — sin fuentes de entrada"
         - metrics:        todas a 0
         - gates:          null para los 4 (CV / Quality / Coverage / Cierre)
         - gaps:           todas las listas vacías
         - timeline:       Paso 0b/0c-bis/0d/0e con status=done;
                           FASE 1+ con status=pending y resultado
                           "NO EJECUTADA — input/ vacío"
         - nota:           explicación legible del motivo + acción concreta
                           para el operador (depositar fuentes + re-ejecutar
                           en modo `continue-iteration`)

    → Mostrar instrucciones al operador:
         "Deposita tus fuentes en los directorios input/ y ejecuta:
          /fa-run-workflow {app-id} {client-id} continue-iteration
          (NO uses modo full: borraría el dashboard de ITER-001 y reiniciaría
           el contador de iteraciones)."
    → Mostrar enlace al dashboard recién creado (file://...operator/dashboard.html)
    → DETENER ejecución — ITER-001 cerrada como ABORTED.

  Caso B — input/ TIENE fuentes (al menos uno de los tres N_* > 0):

    → NO escribir aún resources/iteration-tracker.md ni los demás artefactos
       de cierre. ITER-001 NO se aborta — será una iteración completa cuyo
       estado final se determinará tras FASE 1 y los gates.

    → Mostrar al operador:
       "✅ fa-config.yml generado. Detectadas fuentes en input/:
            docs:    {N_docs} ficheros
            screens: {N_screens} ficheros
            specs:   {N_specs} ficheros
        Continuando con FASE 1 — ITER-001 será una iteración completa."

    → Continuar la ejecución desde Paso 0c (leer y validar fa-config.yml).
       El resto del pipeline (gobernanza, sizing, FASE 1, gates, FASE 2/3,
       cierre) se ejecuta exactamente igual que si fa-config.yml ya hubiera
       existido al inicio. Los artefactos resources/iteration-tracker.md,
       source-fingerprint.md, complexity-assessment.md y operator/dashboard.html
       se escribirán en sus puntos habituales (Paso 0e, Paso 1b, etc.).

Si existe → leer y continuar

En AMBOS casos (config nueva o existente), verificar y crear si no existen los directorios:
  workflows-data/workflow-fa/input/docs/
  workflows-data/workflow-fa/input/screens/
  workflows-data/workflow-fa/input/specs/
  workflows-data/workflow-fa/input/remote/
  workflows-data/workflow-fa/output/
  workflows-data/workflow-fa/resources/
  workflows-data/workflow-fa/operator/
→ Si algún directorio falta, crear con .gitkeep (idempotente — no falla si ya existe)

Si NO existe Y modo ≠ full → ERROR: "fa-config.yml no encontrado. Ejecuta primero en modo full."
```

### 0c. Leer y validar fa-config.yml

```
Leer fa-config.yml
Verificar campos obligatorios:
  - app-id (no vacío)
  - client-id (no vacío)
  - project.type (new | migration | modification | incident)
  - project.target.frontend (no vacío)
  - sources (al menos un source con enabled: true)

Si faltan campos obligatorios → ERROR con lista de campos faltantes
```

### 0c-bis. Cargar el Common Skill common/requirements-governance (BABOK v3 + ISO/IEC/IEEE 29148:2018)

```
Resolución (v2.0): la gobernanza ya NO es el fichero fa-governance.yml en ruta fija.
Es el Common Skill common/requirements-governance (Skills/common/requirements-governance/SKILL.md),
que se resuelve como cualquier otro skill — sin búsqueda por path ni ERROR BLOQUEANTE
de ruta. Los gates que lo necesitan (quality, security, closure) lo declaran en su
frontmatter `skills: [common/requirements-governance]`.

Cargar el skill common/requirements-governance y aplicar como POLÍTICAS GLOBALES durante toda la ejecución:

  → principles: validar que cada FA-REQ aporta business_value y referencia
    al menos un stakeholder (BABOK principle: stakeholder_centricity)

  → requirements_classification.confidence_level: aplicar mapeo estricto
    en la síntesis (FASE 2 fa-functional-synthesizer):
      • CONFIRMED  → ≥2 fuentes O fuente primaria (no requiere validación)
      • INFERRED   → 1 fuente única (requires_validation: true → genera gap)
      • ASSUMED    → sin evidencia (requires_validation: mandatory → genera gap BLQ)

  → requirements_quality.mandatory_attributes: el sintetizador y los gates
    deben verificar cada FA-REQ contra los 6 atributos:
      unambiguous, complete, consistent, verifiable, traceable, feasible
    Cualquier FA-REQ que falle un atributo → emite FA-GAP correspondiente.

  → traceability: política de trazabilidad bidireccional obligatoria.
    Cada FA-REQ debe enlazar a (a) origen — stakeholder_need /
    business_requirement — y (b) downstream — system_component / test_case.
    fa-closure-gate verifica trazabilidad bidireccional completa.

  → gap_management.rules:
      • blocking_gaps_prevent_progress: true → Gate CV/Coverage/Cierre
        emiten FAIL automáticamente si hay gaps BLOQUEANTES sin resolver.
      • assumed_requirements_generate_gap: true → cada FA-REQ ASSUMED genera
        automáticamente un FA-GAP de tipo ASSUMPTION-UNVALIDATED.

  → validation.required_for: los siguientes elementos requieren validación
    explícita del PO/business_owner antes del cierre:
      inferred_requirements, assumed_requirements, critical_flows, business_rules
    fa-closure-gate solicita firma del operador con checklist por categoría.

  → completion_criteria: usados por fa-closure-gate como criterios automáticos:
      • all_requirements_classified (CONFIRMED/INFERRED/ASSUMED)
      • all_requirements_have_traceability (bidireccional)
      • no_blocking_gaps (severidad BLOQUEANTE = 0)
      • all_requirements_meet_quality_attributes (6 atributos ISO 29148)
      • deliverables_complete (requirements_registry + business_rules + navigation)

  → governance.iteration_control.max_unvalidated_requirements_allowed: 0
    → Al cierre, no puede quedar ningún INFERRED/ASSUMED sin validación
      explícita del operador. fa-closure-gate bloquea hasta resolución.

Mostrar al operador:
  "📜 Gobernanza cargada: skill common/requirements-governance v{version}
     Estándares: BABOK v3 + ISO/IEC/IEEE 29148:2018
     Políticas activas: trazabilidad bidireccional, 6 atributos de calidad,
     clasificación CONFIRMED/INFERRED/ASSUMED, gaps bloqueantes paran progreso."
```

### 0c-ter. Resolver rutas de código fuente y contratos

```
Resolver SOURCE_APP_PATH:
  1. Leer sources.code.path de fa-config.yml
  2. Si está informado → usar ese valor como SOURCE_APP_PATH
  3. Si está vacío → comprobar si existe input/source-app/
     - Si existe → SOURCE_APP_PATH = input/source-app/
     - Si no existe → SOURCE_APP_PATH = "" (sin código fuente)
  4. Si sources.code.enabled = true pero SOURCE_APP_PATH = "" →
       Advertir: "sources.code habilitado pero no se encontró código fuente."
       Desactivar automáticamente sources.code para esta ejecución.

Resolver CONTRACTS_PATH:
  → CONTRACTS_PATH = input/specs/  (siempre — es el directorio estándar)
  → No necesita configuración explícita

Mostrar resolución al operador:
  "📂 Fuentes resueltas:
     docs:      input/docs/       [{N} ficheros]
     screens:   input/screens/    [{N} imágenes]
     specs:     input/specs/      [{N} ficheros]
     code:      {SOURCE_APP_PATH} [{N} ficheros UI] | no disponible"
```

```
Aplicar fa-source-scanner:

Para cada sources.{tool} con enabled: true:
  1. Verificar si existe MCP nativo en plataforma
  2. Verificar si existe input/remote/{tool}.yml

  Caso 1 (ambos) → registrar "MCP gana en runtime"
  Caso 2 (solo MCP) → autogenerar stub input/remote/{tool}.yml
  Caso 3 (solo .yml) → usar export estático
  Caso 4 (ninguno) → ACTIVAR DIÁLOGO INTERACTIVO REACTIVO
                     (ver fa-source-scanner § "Diálogo Interactivo de
                      Configuración Remota"):
                     • Preguntar al operador URL, proyecto, MCP (opcional)
                       y nombre de variable de entorno para la credencial
                     • Si el operador completa el diálogo → escribir
                       input/remote/{tool}.yml y reevaluar (pasa a Caso 1 o 3)
                     • Si el operador cancela → emitir FA-GAP
                       REMOTE-CHANNEL-MISSING (BLOQUEANTE) y ABORTAR

Si tras el diálogo reactivo aún queda algún Caso 4 sin resolver:
   → Mostrar error con la lista de herramientas no configuradas
   → NO continuar — instrucciones para volver a ejecutar el modo full o
     editar manualmente input/remote/{tool}.yml
```

### 0d. Verificar agentes y Client Skill

```
Verificar existencia de los agentes en Agents/ (extensión .agent.md):
  Agents/analyzers/
    - fa-docs-analyzer.agent.md
    - fa-ui-analyzer.agent.md
    - fa-requirements-analyzer.agent.md
    - fa-code-analyzer.agent.md      (solo si project.type ≠ new)
  Agents/gates/
    - fa-cross-validation-gate.agent.md
    - fa-quality-gate.agent.md
    - fa-coverage-gate.agent.md
    - fa-security-gate.agent.md
    - fa-closure-gate.agent.md
  Agents/generators/
    - fa-generate-output.agent.md

Si falta CUALQUIER agente → ERROR (no se puede auto-crear):
  "Falta el agente: {nombre}
   Los agentes deben estar en Agents/{analyzers,gates,generators}/
   Verifica la instalación del framework WF1."

Verificar existencia de Client Skill:
  Skills/clients/{client-id}/{client-id}-fa-rules/SKILL.md
  (donde {client-id} viene de fa-config.yml; el nombre de carpeta del cliente = CLIENT_ID exacto)

Si el Client Skill NO existe → AUTO-CREAR desde la plantilla:
  1. Leer Templates/demo-fa-rules.template.md
  2. Sustituir en el contenido:
       - name: "demo-fa-rules"  →  name: "{client-id}-fa-rules"
       - client: demo           →  client: {client-id}
       - scope: "... DEMO ..."  →  scope: "... {client-id} ..."
       - Título "# DEMO FA Rules" → "# {CLIENT-ID} FA Rules"
       - Eliminar el bloque de INSTRUCCIONES (primeras líneas con > **)
  3. VACIAR las secciones que contienen ejemplos inventados que podrían
     confundirse con datos reales del cliente. Sustituir por placeholders:

       Sección "Alias de Roles" → reemplazar TODA la tabla por:
         | Nombre en documentos del cliente | ID estándar en artefactos | Notas |
         |----------------------------------|---------------------------|-------|
         | (sin datos — poblar tras análisis funcional) | | |

       Sección "Terminología de Negocio" → reemplazar TODA la tabla por:
         | Término del cliente | Equivalente funcional estándar | Notas |
         |---------------------|-------------------------------|-------|
         | (sin datos — poblar tras análisis funcional) | | |

       Sección "Módulos y Dominios" → reemplazar TODA la tabla por:
         | Módulo / Dominio | Prefijo sugerido para FA-REQ | Notas |
         |-----------------|------------------------------|-------|
         | (sin datos — poblar tras análisis funcional) | | |

     El resto de secciones (Jerarquía de Confianza, Restricciones de Privacidad,
     Convenciones Target, Exclusiones) se mantienen con los valores genéricos
     del template ya que no generan falsos positivos.

  4. Escribir en Skills/clients/{client-id}/{client-id}-fa-rules/SKILL.md
  5. Mostrar aviso:
     "⚠️  Client Skill '{client-id}-fa-rules' creado automáticamente.
      Las secciones de roles, terminología y módulos están vacías a propósito:
      se poblarán con los términos exactos encontrados en el análisis funcional.
      No se asumen nombres de roles ni terminología que no esté en las fuentes."
  6. Continuar — no detener el workflow
```

### 0e. Clasificar complejidad (fa-complexity-sizer)

```
Aplicar fa-complexity-sizer:
  - Contar sources.*.enabled = true → criterio fuentes
  - Estimar páginas en input/docs/
  - Contar imágenes en input/screens/
  - Si sources.code.enabled: contar ficheros UI en source-app/

→ APP_SIZE = small | medium | large
→ Guardar en resources/complexity-assessment.md
→ Mostrar: "Complejidad estimada: {APP_SIZE}"
```

### 0f. Ajustar coverage-threshold si incident

```
Si project.type = incident:
  → coverage-threshold = 0.50
  → Mostrar: "Modo incidencia: coverage-threshold reducido a 50%"
```

### 0g. Limpieza de artefactos previos (solo modo full)

```
Si modo = full:
  → Eliminar todos los ficheros no-.gitkeep de operator/:
      operator/*.html, operator/*.md, operator/**/*.html, operator/**/*.md
  → Eliminar todos los ficheros no-.gitkeep de output/:
      output/**  (mantener .gitkeep si existe)
  → Eliminar RESUMENes de la iteración anterior en resources/:
      resources/FA-DOCS-RESUMEN.md
      resources/FA-UI-RESUMEN.md
      resources/FA-REQ-RESUMEN.md
      resources/FA-CODE-RESUMEN.md
      resources/FA-SYNTHESIS-RESUMEN.md
      resources/cross-validation-report.md
      resources/coverage-report.md
      resources/open-gaps.md
      resources/complexity-assessment.md
  → Mantener intactos:
      resources/iteration-tracker.md   (historial de iteraciones)
      resources/source-fingerprint.md  (comparación de cambios)
      input/                           (fuentes del usuario — nunca tocar)
  → Mostrar: "🧹 Limpieza completada: operator/, output/ y RESUMENes anteriores eliminados"

Si modo ≠ full:
  → No limpiar — continuar sobre artefactos existentes
```

### 0h. Gestión de reanudación

```
CONCEPTO DE ITERACIÓN: cada ejecución del workflow — sea cual sea el modo —
es una nueva iteración. Esto permite al operador ver la traza completa de
todo lo que ha ocurrido en el proyecto:
  ITER-001 · full             → configuración inicial
  ITER-002 · continue-iter   → análisis + gates
  ITER-003 · reassemble       → artefactos regenerados
  ITER-004 · continue-iter   → tras resolver gaps del PO

Por tanto, TODOS los modos (excepto full, que ya inicializa ITER-001):
  → Incrementar ITER-NNN en fa-config.yml
  → Añadir nueva entrada en resources/iteration-tracker.md

  ⚠️ OBLIGATORIO tras completar FASE 1 (o FASE 3 en reassemble):
  → Ejecutar Paso 1b para añadir la entrada ITER-NNN al dashboard.
     Paso 1b es quien materializa la nueva iteración en el HTML.
     El orquestador NO debe omitir Paso 1b en ningún modo de ejecución.

Si modo = continue-iteration:
  → Calcular fingerprint actual de input/
  → Comparar con resources/source-fingerprint.md
  → Identificar fuentes nuevas/modificadas
  → Incrementar ITER-NNN en fa-config.yml
  → Crear entrada en iteration-tracker.md: modo=continue-iteration
  → La nueva entrada del dashboard tendrá las métricas del análisis que se ejecutará

Si modo = reassemble:
  → Verificar que resources/FA-SYNTHESIS-RESUMEN.md existe
  → Si no existe → ERROR: "No hay síntesis disponible. Usa modo full o continue-iteration."
  → Incrementar ITER-NNN en fa-config.yml
  → Crear entrada en iteration-tracker.md: modo=reassemble
  → La nueva entrada del dashboard tendrá:
      - mode: "reassemble"
      - metrics: heredadas de FA-SYNTHESIS-RESUMEN (FA-REQ, SCR, BRN, etc.)
      - gates: null para todos (no se ejecutan gates en reassemble)
      - timeline: solo pasos de FASE 3
      - nota: "Reassemble — artefactos regenerados desde síntesis de ITER-{anterior}"
  → Saltar directamente a FASE 3

Si modo = update-sources:
  → Calcular diff de fingerprint
  → Mapear ficheros modificados → agentes afectados
  → Incrementar ITER-NNN en fa-config.yml
  → Crear entrada en iteration-tracker.md: modo=update-sources
  → Solo re-ejecutar agentes afectados
  → Continuar desde gates
```

---

## FASE 1 — Extracción y Análisis (Paralela)

```
Mostrar: "=== FASE 1: Extracción paralela ==="
Mostrar: "Lanzando agentes de análisis..."
```

**Lanzar en paralelo** (máximo paralelismo según APP_SIZE):

```
SIEMPRE lanzar:
  → Agente fa-docs-analyzer
     Context: "Analiza input/docs/ del proyecto {APP_ID}. Carga Client Skill {client-id}-fa-rules."
     Output esperado: resources/FA-DOCS-RESUMEN.md

  → Agente fa-ui-analyzer
     Context: "Analiza input/screens/ y fuentes Figma del proyecto {APP_ID}. 
               APP_SIZE={APP_SIZE}. Carga Client Skill {client-id}-fa-rules."
     Output esperado: resources/FA-UI-RESUMEN.md

  → Agente fa-requirements-analyzer
     Context: "Analiza input/specs/ y fuentes Jira del proyecto {APP_ID}. 
               Carga Client Skill {client-id}-fa-rules."
     Output esperado: resources/FA-REQ-RESUMEN.md

SOLO si project.type ∈ {migration, modification, incident}:
  → Agente fa-code-analyzer
     Context: "Analiza source-app/ del proyecto {APP_ID}. 
               project.type={project.type}. Carga Client Skill {client-id}-fa-rules."
     Output esperado: resources/FA-CODE-RESUMEN.md
```

**Esperar** que todos los agentes completen.

**Verificar** que se generaron todos los RESUMENes esperados.
Si falta algún RESUMEN → ERROR: indicar qué agente falló y cómo re-ejecutar.

---

## Paso 1b — Crear/actualizar operator/dashboard.html (SIEMPRE)

```
Este paso se ejecuta SIEMPRE, independientemente del resultado posterior de los gates.
Objetivo: crear o actualizar el dashboard del operador preservando el historial completo
de iteraciones anteriores.

Leer resources/FA-DOCS-RESUMEN.md (fuente principal de FA-REQ)
Si FA-REQ-RESUMEN no está vacío → incluir también esos FA-REQ (con indicación de origen)

── SCHEMA DEL OBJETO ITERACIÓN ──────────────────────────────────────────
Cada entrada del array `iterations` tiene estos campos:

  {
    id: "ITER-NNN",
    date: "YYYY-MM-DD",
    mode: "full | continue-iteration | update-sources | reassemble | abortado",
    status: "FASE1_DONE | GATE_CV_FAIL | GATE_CV_CHECKPOINT |
             GATE_QUALITY_FAIL | GATE_QUALITY_CHECKPOINT |
             GATE_COV_CHECKPOINT | FASE2_DONE | FASE3_DONE | CLOSED | ABORTED",
    statusLabel: "Texto legible del estado para mostrar en el badge",
    metrics: { faReq: N, scr: N, brn: N, ent: N, nav: N, rol: N, int: N },
    sources: [{ name, channel, status, result, gaps }],
    gates: { cv: null|"PASS"|"FAIL"|"CHECKPOINT",
             quality: null|"PASS"|"FAIL"|"CHECKPOINT",
             coverage: null|"PASS"|"FAIL"|"CHECKPOINT",
             closure: null|"PASS"|"FAIL" },
    requirements: [{ id, desc, scr, confidence, role }],
    screens:      [{ id, name, reqs, confidence, sources }],
    entities:     [{ id, name, reqs, fields, confidence }],
    gaps: {
      bloqueantes: [],        ← [{ id, tipo, origen, desc, accion }]
      recomendados: [],       ← ídem
      informativos: [],       ← ídem
      resolvibles: [],        ← [{ id, tipo, origen, desc, accion }] — estado RESOLVIBLE_OPERADOR
      descartadosLista: []    ← [{ id, motivo: "ERROR_PROCESO"|"FALSO_POSITIVO", justificacion }]
    },
    timeline: [{ step, status: "done|pending|fail", result }],
    nota: "Explicación legible del estado de la iteración para el operador."
  }

── LÓGICA DE ACUMULACIÓN ────────────────────────────────────────────────
Al escribir operator/dashboard.html:

  Cada ejecución del workflow crea una nueva entrada ITER-NNN en el array.
  Como el ITER-NNN ya se incrementó en el Paso 0h, siempre habrá que AÑADIR.

  1. Si el fichero YA EXISTE:
       a. Extraer el array `iterations` del bloque `const DASHBOARD_DATA = {...}`.
       b. AÑADIR la nueva entrada ITER-NNN al final del array.
          (No debería existir ya, porque es un ID nuevo. Si por algún error
           existiera → ACTUALIZAR en lugar de duplicar.)
       c. Reescribir el fichero completo con el array acumulado.

  2. Si el fichero NO EXISTE (primera ejecución):
       Crear desde cero con el array que solo contiene la iteración actual.

  Contenido de la nueva entrada según el modo de ejecución:

    full / continue-iteration / update-sources:
      → metrics: se rellenan tras FASE 1
      → gates: null inicialmente, se actualizan tras cada gate
      → timeline: se construye paso a paso durante la ejecución

    reassemble:
      → metrics: heredar de FA-SYNTHESIS-RESUMEN (FA-REQ, SCR, BRN, ENT, NAV, ROL, INT)
      → gates: null para todos (no se ejecutan gates en reassemble)
      → timeline: solo el paso de FASE 3
      → nota: "Reassemble — artefactos regenerados desde síntesis de ITER-{N-1}"

  El renderer JS ordena de más reciente a más antigua — el array de datos mantiene
  orden cronológico ascendente (ITER-001, ITER-002, ITER-003, ...).

── DASHBOARD_DATA (nivel raíz) ──────────────────────────────────────────
  {
    project: { appId, clientId, description, type, targetFrontend },
    currentIter: "ITER-NNN",
    workflowStatus: "<status de la iteración actual>",
    iterations: [ ...todas las iteraciones acumuladas en orden cronológico... ]
  }

── REGLAS DE PRESENTACIÓN EN EL HTML ────────────────────────────────────
Todos los textos visibles al usuario usan lenguaje natural, SIN acrónimos técnicos:

  • Cards de métricas (sección Estado):
      faReq → "Requisitos Func."   scr → "Pantallas"
      brn   → "Reglas Negocio"    ent → "Entidades"
      nav   → "Flujos Nav."       rol → "Roles"
      int   → "Integraciones"

  • Texto del timeline para FASE 1:
      "{N} requisitos candidatos, {N} pantallas, {N} reglas de negocio,
       {N} entidades, {N} flujos de navegación, {N} roles"

  • Subtítulo sección Requisitos:
      "Requisitos funcionales candidatos detectados en FASE 1 —
       pendientes de síntesis y asignación de IDs definitivos"

  • Cabeceras tabla Pantallas:  "ID Pantalla" | "Nombre" | "Requisitos" | "Fuentes" | "Confianza"
  • Cabeceras tabla Entidades:  "ID Entidad"  | "Nombre" | "Campos" | "Requisitos" | "Confianza"

  • Labels en cards de iteraciones:
      faReq → "Requisitos"   scr → "Pantallas"
      brn   → "Reglas"       ent → "Entidades"
      int   → "Integraciones" rol → "Roles"

  Excepción: los IDs internos (FA-REQ-D-001, SCR-001, ENT-001...) se muestran
  tal cual — son identificadores del sistema, no etiquetas de UI.

── SECCIÓN ITERACIONES — DISEÑO ─────────────────────────────────────────
  • Una card colapsable por ITER-NNN, ordenadas de más reciente a más antigua.
  • La iteración más reciente aparece expandida por defecto; las anteriores, colapsadas.
  • Cada card muestra en su cabecera: id · fecha · modo · badge de estado.
  • Al expandir: nota explicativa (si existe), panel de métricas 2×3, panel de gates
    (los 4: CV / Quality / Coverage / Cierre), panel de recuento de gaps por severidad.
  • Iteraciones ABORTED o sin análisis ejecutado muestran "Sin análisis ejecutado"
    en el panel de métricas en lugar de ceros.

── SECCIÓN GAPS — CUATRO TABLAS SIEMPRE PRESENTES ──────────────────────
  La sección "Gaps" del dashboard muestra CUATRO tablas, en este orden:

  1. ⛔ BLOQUEANTES — de gaps.bloqueantes[]
  2. ⚠️ RECOMENDADOS — de gaps.recomendados[]
  3. 🔧 RESOLVIBLES POR OPERADOR — de gaps.resolvibles[]
     (gaps con estado RESOLVIBLE_OPERADOR — el operador puede cerrarlos
      sin PO referenciando fuentes ya existentes en el análisis)
  4. 🗑️ DESCARTADOS POR DEPURACIÓN — de gaps.descartadosLista[]
     Columnas: ID | Motivo (badge "Error de proceso" / "Falso positivo") | Justificación
     El motivo se muestra como badge coloreado:
       ERROR_PROCESO   → badge gris claro  ("Error de proceso")
       FALSO_POSITIVO  → badge amarillo    ("Falso positivo")

  Las tarjetas de métricas de gaps muestran contadores para las 4 categorías:
    Bloqueantes | Recomendados | Resolvibles operador | Descartados
  El contador "Descartados" se calcula como gaps.descartadosLista.length.

── JAVASCRIPT CLAVE ─────────────────────────────────────────────────────
  // Seleccionar iteración activa por currentIter, nunca por posición fija:
  const iter = D.iterations.find(i => i.id === D.currentIter)
               || D.iterations[D.iterations.length - 1];

  // Contador de descartados en las cards de iteraciones — usar SIEMPRE descartadosLista.length:
  //   const gD = (it.gaps && it.gaps.descartadosLista)
  //              ? it.gaps.descartadosLista.length
  //              : (it.gaps && it.gaps.descartados) || 0;
  // NUNCA usar it.gaps.descartados directamente — es el campo entero antiguo,
  // que puede no existir o estar a 0 aunque haya descartadosLista con elementos.

  // statusMap completo:
  const statusMap = {
    FASE1_DONE:              ['status-pending', 'FASE 1 completada'],
    GATE_CV_FAIL:            ['status-fail',    'Gate CV — FAIL'],
    GATE_CV_CHECKPOINT:      ['status-pending', 'Gate CV — Checkpoint'],
    GATE_QUALITY_FAIL:       ['status-fail',    'Gate Quality — FAIL'],
    GATE_QUALITY_CHECKPOINT: ['status-pending', 'Gate Quality — Checkpoint'],
    GATE_COV_CHECKPOINT:     ['status-pending', 'Gate Coverage — Checkpoint'],
    FASE2_DONE:              ['status-pending', 'FASE 2 completada'],
    FASE3_DONE:              ['status-pending', 'FASE 3 completada'],
    CLOSURE_FAIL:            ['status-fail',    'Gate Cierre — FAIL'],
    CLOSED:                  ['status-done',    'WF1 Cerrado'],
    ABORTED:                 ['status-fail',    'Abortado']
  };

  // No existen estados intermedios de espera (no hay CHECKPOINT_CLOSURE
  // ni OVERRIDE_DRAFT). Toda iteración termina en estado final.

→ Escribir operator/dashboard.html
→ Mostrar: "📊 Dashboard creado/actualizado: operator/dashboard.html"
```

---

## Paso 1c — Depuración de gaps (inline, tras cada escritura en open-gaps.md)

```
Este paso se ejecuta INLINE cada vez que un agente o gate escribe nuevos gaps
en resources/open-gaps.md. NO es un agente separado: lo ejecuta el orquestador
directamente antes de evaluar cualquier veredicto de gate.

Objetivo: garantizar que open-gaps.md solo contiene gaps genuinos o
resolvibles por el operador. Falsos positivos y errores de proceso se eliminan
ANTES de que los gates los contabilicen, evitando stops o escaladas innecesarias.

── CUÁNDO SE EJECUTA ────────────────────────────────────────────────────
  • Después de que FASE 1 complete y los analizadores hayan escrito sus gaps
  • Después de que Gate CV escriba sus gaps en open-gaps.md
  • Después de que Gate Quality escriba sus gaps en open-gaps.md
  • Después de que FASE 2 (fa-gap-detector) escriba sus gaps en open-gaps.md

── CLASIFICACIÓN DE CADA GAP ────────────────────────────────────────────
Leer cada gap de open-gaps.md y clasificarlo en una de estas categorías:

  GENUINO → permanece en open-gaps.md como ABIERTO. Es un gap real que
            necesita respuesta del PO, arquitecto u operador con nueva
            información funcional.

  RESOLVIBLE_OPERADOR → permanece en open-gaps.md pero con estado
            RESOLVIBLE_OPERADOR (no ABIERTO). El operador puede cerrarlo
            sin consultar al PO porque la información ya existe en las
            fuentes analizadas.

  FALSO_POSITIVO → se mueve a resources/dismissed-gaps.md con motivo
            FALSO_POSITIVO. No aparece en open-gaps.md ni en el recuento
            de gaps bloqueantes de los gates.

  ERROR_PROCESO → se mueve a resources/dismissed-gaps.md con motivo
            ERROR_PROCESO. No aparece en open-gaps.md ni en el recuento
            de gaps bloqueantes de los gates.

── CRITERIOS DE CLASIFICACIÓN ───────────────────────────────────────────

  ERROR_PROCESO — se aplica cuando el gap NO describe un problema del
  sistema analizado sino una inconsistencia interna del propio análisis:

    • La descripción menciona "desalineación de IDs entre RESUMENes",
      "colisión de ID entre agentes" o "error de numeración interna" →
      el gap es un artefacto de que dos agentes numeraron los mismos
      elementos de forma distinta; se corrige en FASE 2 (síntesis).

    • La descripción contiene explícitamente "DUPLICADO de FA-GAP-NNN" →
      el gap ya está recogido bajo otro ID; eliminar el duplicado.

    • La descripción contiene "gap transitorio" Y el campo impacto dice
      "Ninguno" → el gap se generó por el orden de ejecución de los
      agentes, no por una carencia real.

  FALSO_POSITIVO — se aplica cuando el gap cuestiona algo que no procede
  de ninguna fuente funcional analizada sino de datos del propio framework:

    • tipo = ROLE-UNCLEAR Y el nombre del rol que cuestiona NO aparece en
      ningún texto de FA-DOCS-RESUMEN, FA-UI-RESUMEN, FA-REQ-RESUMEN ni
      FA-CODE-RESUMEN → el rol fue heredado del template del client skill,
      no de la documentación real. Descartar.

    • tipo = SCOPE-UNCLEAR O tipo = NFR-MISSING Y la descripción indica
      "comportamiento esperado para project.type=X" Y el campo impacto
      dice "Ninguno en ITER-NNN" → observación estructural, no gap real.

  RESOLVIBLE_OPERADOR — se aplica cuando la información que resuelve el
  gap ya existe en las fuentes analizadas en esta misma iteración:

    • La descripción menciona explícitamente que otra fuente ya documenta
      la respuesta, con referencia concreta (ej: "FA-DOCS NAV-001 indica
      claramente que…", "BRN-002 define el trigger", "FA-REQ-D-NNN ya
      cubre esto") → el operador solo necesita validar formalmente, no
      obtener información nueva.

    • El campo responsable-sugerido = "Operador" Y la descripción contiene
      "puede marcarse RESUELTO referenciando" → el gap es de trazabilidad
      formal, no de información faltante.

    • Regla: marcar como RESOLVIBLE_OPERADOR, añadir en el campo
      accion-requerida la referencia exacta a la fuente que lo resuelve,
      y NO contabilizar como BLOQUEANTE en los veredictos de gate.

  GENUINO — todo lo que no cumpla ningún criterio anterior.

── EFECTO SOBRE VEREDICTOS DE GATE ──────────────────────────────────────
Tras la depuración, recalcular el conteo de gaps BLOQUEANTES:

  bloqueantes_reales = gaps en open-gaps.md con severidad=BLOQUEANTE
                       Y estado=ABIERTO (excluye RESOLVIBLE_OPERADOR)

  Si bloqueantes_reales = 0 Y el gate había emitido veredicto FAIL:
    → Revisar si corresponde promover a CHECKPOINT o PASS
    → Mostrar al operador: "ℹ️ Tras depuración: {N} gaps descartados
      ({N} errores de proceso, {N} falsos positivos). Los gaps bloqueantes
      restantes son resolvibles por el operador sin consultar al PO."

── ARTEFACTOS GENERADOS ─────────────────────────────────────────────────
  resources/open-gaps.md     → solo gaps GENUINO y RESOLVIBLE_OPERADOR
  resources/dismissed-gaps.md → gaps descartados con motivo y justificación

  Formato de cada entrada en dismissed-gaps.md:
    ## {FA-GAP-ID}
    - motivo-descarte: FALSO_POSITIVO | ERROR_PROCESO
    - justificacion: "Texto explicando por qué se descarta"
    - gap-original: {contenido completo del gap original}

→ Mostrar resumen tras cada ejecución del paso:
  "🔍 Depuración de gaps: {N_total} gaps revisados →
     {N_genuinos} genuinos | {N_operador} resolvibles por operador |
     {N_fp} falsos positivos descartados | {N_ep} errores de proceso descartados"
```

---

## Principio: el dashboard se actualiza en TODOS los puntos de salida

```
El dashboard (operator/dashboard.html) es el artefacto de comunicación principal
con el operador. DEBE estar actualizado cada vez que la ejecución del workflow
termine — sea por éxito, por parada en un gate, por checkpoint o por cierre.

REGLA UNIVERSAL: antes de mostrar cualquier mensaje final al operador y antes
de detener la ejecución, actualizar SIEMPRE el dashboard con:
  - workflowStatus: estado actual de la iteración
  - gates: resultado de cada gate ejecutado hasta ese momento
  - gaps: estado actualizado de los gaps (incluyendo los resueltos)
  - timeline: añadir el paso que acaba de ejecutarse
  - nota: resumen legible del estado actual

Esta regla se aplica en TODOS los puntos donde la ejecución puede terminar:
  0. Tras Paso 0b (Caso A) — bootstrap con input/ VACÍO: fa-config.yml
     recién creado y NO hay fuentes en input/docs|screens|specs. ITER-001
     se cierra con status=ABORTED y nota explicativa.
     (En Caso B — bootstrap con fuentes ya presentes — NO se aplica este
      punto: la ejecución continúa a Paso 0c y los artefactos se escriben
      en los puntos 1+ como en una iteración normal.)
  1. Tras Paso 1b (siempre, con datos de FASE 1)
  2. Gate CV → fail o checkpoint-B
  3. Gate Quality → fail o checkpoint-B
  4. Gate Coverage → checkpoint-B
  5. Tras FASE 3 (fa-generate-output)
  6. Gate Cierre → fail (BLOQUEANTES > 0) → status CLOSURE_FAIL
  7. Gate Cierre → pass (BLOQUEANTES = 0 + firma del operador) → status CLOSED

No existe veredicto `checkpoint-operator` ni status `CHECKPOINT_CLOSURE`.
Toda iteración termina siempre en estado final. La única vía de progreso
ante un BLOQUEANTE es aportar documentación funcional en `input/` y
lanzar una nueva iteración con `continue-iteration`.
```

---

## Gates post-FASE 1 (Secuencial)

### Gate 1: fa-cross-validation-gate

```
Mostrar: "=== GATE: Validación cruzada ==="
Lanzar fa-cross-validation-gate

Leer veredicto de resources/cross-validation-report.md:

Si veredicto = pass:
  → Continuar con fa-coverage-gate

Si veredicto = fail:
  → Actualizar operator/dashboard.html ANTES de detener:
      - workflowStatus: "GATE_CV_FAIL"
      - gates.cv: { verdict: "FAIL", checks: [...resultados CV-01..CV-06...] }
      - gaps: { bloqueantes: [...], recomendados: [...], informativos: [...] }  ← de open-gaps.md
      - timeline: añadir paso "Gate CV — FAIL" con lista de gaps BLOQUEANTES
      - nextSteps: instrucciones para resolver y re-ejecutar
  → Mostrar lista de gaps BLOQUEANTES emitidos
  → Mostrar:
    "❌ GATE FALLIDO: Coherencia entre fuentes insuficiente.
     
     Gaps bloqueantes a resolver:
     [lista de FA-GAP con tipo, pantalla/req afectado y acción requerida]
     
     Próximos pasos:
     1. Abre el dashboard del operador (enlace al final)
     2. Obtén aclaraciones del cliente/PO para los gaps BLOQUEANTES
     3. Actualiza o añade fuentes en input/
     4. Ejecuta: /fa-run-workflow {$0} {$1} continue-iteration"
  → DETENER — no ejecutar fa-coverage-gate ni FASE 2

Si veredicto = checkpoint:
  → Actualizar operator/dashboard.html:
      - workflowStatus: "GATE_CV_CHECKPOINT"
      - gates.cv: { verdict: "CHECKPOINT", detail: "CV-03 — sin FA-REQ formales" }
      - timeline: añadir paso "Gate CV — CHECKPOINT"
  → Mostrar pantallas sin cobertura suficiente
  → Presentar opciones al operador:
    "⚠️ CHECKPOINT: {N}% de requisitos sin pantalla asignada.
     
     A) Continuar hacia FASE 2 (aceptar el riesgo)
     B) Detener y añadir más fuentes de diseño/documentación
     
     ¿Qué prefieres hacer? (A/B)"
  → Esperar decisión del operador
  → Si A: continuar con fa-quality-gate
  → Si B: detener y mostrar instrucciones
```

### Gate 2: fa-quality-gate (ISO/IEC/IEEE 29148:2018)

```
Mostrar: "=== GATE: Calidad ISO 29148 ==="
Lanzar fa-quality-gate

Este gate aplica las heurísticas de calidad declaradas en el skill common/requirements-governance
sobre cada FA-REQ producido en FASE 1. Verifica los 6 atributos obligatorios:
  unambiguous, complete, consistent, verifiable, traceable, feasible
(o subconjunto si fa-config.yml.governance-overrides.skip_quality_attributes
está declarado).

Por cada atributo fallado emite un FA-GAP del tipo declarado en el YAML:
  - unambiguous fallado → REQ-AMBIGUOUS
  - complete fallado    → REQ-INCOMPLETE
  - consistent fallado  → REQ-INCONSISTENT
  - verifiable fallado  → REQ-UNVERIFIABLE
  - traceable fallado   → REQ-UNTRACEABLE
  - feasible fallado    → REQ-INFEASIBLE

Outputs producidos:
  - resources/governance-effective.md (política aplicada tras merge override)
  - resources/quality-report.md (% cumplimiento por atributo, detalle por FA-REQ)
  - Nuevos FA-GAP añadidos a resources/open-gaps.md

Leer veredicto:

Si veredicto = pass:
  → Mostrar: "✅ Gate Quality: todos los FA-REQ cumplen los 6 atributos ISO 29148"
  → Continuar a fa-coverage-gate

Si veredicto = checkpoint:
  → Mostrar lista de FA-REQ con atributos fallados
  → Actualizar dashboard (workflowStatus: GATE_QUALITY_CHECKPOINT)
  → Presentar opciones A/B al operador (igual que Gate CV checkpoint)

Si veredicto = fail:
  → Actualizar dashboard (workflowStatus: GATE_QUALITY_FAIL)
  → Mostrar gaps de calidad BLOQUEANTES emitidos, agrupados por atributo
  → DETENER — no ejecutar fa-coverage-gate ni FASE 2
  → Mostrar instrucciones de re-ejecución:
    "Resolver los FA-REQ con atributos críticos fallados y ejecutar:
     /fa-run-workflow {app-id} {client-id} continue-iteration"
```

### Gate 3: fa-coverage-gate

```
Mostrar: "=== GATE: Cobertura funcional ==="
Lanzar fa-coverage-gate

Leer veredicto de resources/coverage-report.md:

Si veredicto = pass:
  → Mostrar: "✅ Cobertura: {N}% ≥ {threshold}%"
  → Continuar a FASE 2

Si veredicto = checkpoint:
  → Actualizar operator/dashboard.html:
      - workflowStatus: "GATE_COV_CHECKPOINT"
      - gates.coverage: { verdict: "CHECKPOINT", coverage: N%, threshold: N% }
      - gaps: actualizar con gaps de coverage-report.md
      - timeline: añadir paso "Gate Coverage — CHECKPOINT"
  → Mostrar reporte de cobertura con pantallas sin confirmar
  → Presentar opciones A/B al operador
  → Si A: continuar a FASE 2
  → Si B: detener y mostrar instrucciones de qué fuentes añadir
```

---

## FASE 2 — Síntesis Funcional (Secuencial, Inline)

```
Mostrar: "=== FASE 2: Síntesis funcional ==="
```

### 2a. fa-functional-synthesizer

```
Cargar y aplicar fa-functional-synthesizer:
  - Leer los 4 RESUMENes de resources/
  - Cargar {client-id}-fa-rules
  - Consolidar FA-REQ, SCR, BRN, ENT, NAV, ROL, INT
  - Resolver conflictos según política
  - Asignar IDs definitivos
  - Calcular confianza y cobertura
  → Escribir resources/FA-SYNTHESIS-RESUMEN.md
```

### 2b. fa-target-context-enricher

```
Cargar y aplicar fa-target-context-enricher:
  - Leer resources/FA-SYNTHESIS-RESUMEN.md
  - Cargar sección "Convenciones target" de {client-id}-fa-rules
  - Añadir sección "## Target Context" al FA-SYNTHESIS-RESUMEN
```

### 2c. fa-generate-requirements-index (FASE 2 — enriquecimiento)

```
Cargar y aplicar fa-generate-requirements-index:
  - Leer resources/FA-SYNTHESIS-RESUMEN.md (ya consolidado y enriquecido)
  - Generar output/requirements-registry.md (tabla estructurada para WF2 + trazabilidad)
  - Actualizar sección Requisitos del dashboard (operator/dashboard.html) con datos
    de síntesis: IDs definitivos, confianza confirmada, gaps resueltos por fuente
  → requirements-registry.md es para WF2; el dashboard ya existe desde paso 1b
```

### 2d. fa-gap-detector (FASE 2)

```
Cargar y aplicar fa-gap-detector para gaps emergentes de la síntesis:
  - Verificar trazabilidad bidireccional FA-REQ → SCR → BRN
  - Detectar: REQ-ORPHAN, REQ-WITHOUT-SCREEN, REQ-WITHOUT-RULE, DATA-UNDEFINED
  - Actualizar resources/open-gaps.md con nuevos gaps
```

### 2e. fa-nfr-extractor

```
Cargar y aplicar fa-nfr-extractor:
  - Buscar NFR en todos los RESUMENes
  - Detectar dominios críticos sin especificación → NFR-MISSING gaps
  - Añadir sección "## Requisitos No Funcionales" al FA-SYNTHESIS-RESUMEN
```

---

## FASE 3 — Ensamblado de Artefactos

```
Mostrar: "=== FASE 3: Ensamblado de artefactos ==="

Lanzar agente fa-generate-output:
  (fa-generate-output coordina a su vez sub-agentes fa-req-output en paralelo,
   uno por FA-REQ — ver fa-generate-output.md para el detalle de coordinación)
  → Leer FA-SYNTHESIS-RESUMEN.md y open-gaps.md
  → Enriquecer output/requirements-registry.md (ya generado en FASE 2) con gaps resueltos
  → Generar output/ globales:
       screen-inventory.md, navigation-map.md, business-rules.md,
       data-model.md, roles-permissions.md, integrations-catalog.md, gaps.md
  → Generar por cada FA-REQ elegible (sin gaps BLOQUEANTES):
       output/FA-REQ-NNN/functional-definition.md  ← definición narrativa con gaps resueltos
       output/FA-REQ-NNN/business-rules.md         ← BRN vinculadas a este FA-REQ
       output/FA-REQ-NNN/gaps.md                   ← gaps vinculados (si los hay)
     Para FA-REQ con gaps BLOQUEANTES: solo output/FA-REQ-NNN/gaps.md
     NUNCA recortar a una muestra — generar todos los elegibles sin excepción.
  → Generar Especificación Funcional Consolidada (FSD):
       output/functional-specification.md → FSD global por módulo/pantalla → WF2/WF3
       operator/functional-specification.html → versión HTML navegable para el operador
  → Generar tests funcionales (global, no por requisito):
       output/functional-test-cases.md → casos FT organizados por pantalla → WF5
     NO se generan tests unitarios.
     NO se generan functional-test-cases por FA-REQ individual.
  → Actualizar operator/dashboard.html: añadir enlace a functional-specification.html

Mostrar al operador:
  "📦 Artefactos generados:
   Globales:
   - output/functional-specification.md       → especificación funcional del sistema → WF2/WF3
   - output/functional-test-cases.md          → casos de prueba funcionales → WF5
   - output/{screen-inventory,navigation-map,business-rules,data-model,...}.md
   Por requisito (output/FA-REQ-NNN/):
   - functional-definition.md                 → definición funcional definitiva
   - business-rules.md                        → reglas de negocio del requisito
   - gaps.md                                  → gaps vinculados (si los hay)
   Operador:
   - operator/functional-specification.html   → documento de referencia navegable"
```

---

## Gate de Cierre: fa-closure-gate

```
Mostrar: "=== GATE: Verificación de cierre ==="

Lanzar fa-closure-gate

Leer veredicto de resources/closure-decision.md:

Modelo simplificado: una iteración SIEMPRE termina en estado final
(`CLOSED` o `CLOSURE_FAIL`). No existen estados intermedios de espera
ni mecanismo de override imperativo del operador.

Si C-01 (bloqueantes_reales) > 0 → veredicto = fail:
  → Actualizar operator/dashboard.html:
      - workflowStatus: "CLOSURE_FAIL"
      - gates.closure: "FAIL"
      - timeline: añadir paso "Gate Cierre — FAIL" con checks fallidos
      - nota: "Iteración cerrada sin firma. N gaps BLOQUEANTES pendientes."
  → Actualizar iteration-tracker.md con status: closure-fail
  → Mostrar checks fallidos y gaps BLOQUEANTES
  → Mostrar instrucciones de progreso al operador:
    "❌ La iteración termina sin cerrar — hay N gaps BLOQUEANTES.

     No existe forma de firmar pasando por encima de un BLOQUEANTE.
     Para que la próxima iteración pueda cerrarse, debes aportar
     documentación funcional en input/ que responda a cada gap:

       1. Revisar cada FA-GAP BLOQUEANTE con su responsable sugerido
          (PO / Arquitecto / Cliente)
       2. Obtener un documento de respuesta (decisión, especificación,
          email, acta, nota) que aborde el gap
       3. Depositar el documento en input/docs/
       4. Lanzar: /fa-run-workflow {app-id} {client-id} continue-iteration

     En la nueva iteración, los analizadores leerán el documento y
     decidirán automáticamente según su contenido:

       · Si RESUELVE la pregunta funcional → gap pasa a RESUELTO
       · Si ACEPTA explícitamente diferir o declara no-bloqueante →
         severidad se reduce a RECOMENDADO/INFORMATIVO
         (el gap sigue visible pero ya no impide el cierre)

     Cuando una iteración llegue a 0 BLOQUEANTES, se presentará la
     firma. Mientras tanto, la iteración queda cerrada como CLOSURE_FAIL."

Si C-01..C-06 todos pasan (bloqueantes = 0 Y resto de criterios OK):
  → Mostrar checklist automático completado
  → Mostrar gaps RECOMENDADO/INFORMATIVO aceptados (visibles en WF2)
  → Presentar formulario de firma al operador:
    "✅ Criterios automáticos verificados. Listo para cerrar WF1.

     Resumen:
     - {N} requisitos funcionales confirmados
     - {N} pantallas inventariadas
     - Cobertura: {N}%
     - {N} gaps menores aceptados (visibles en WF2, sin bloqueo)

     Para cerrar WF1 e iniciar WF2, confirma:
     Nombre y rol: _
     Confirmación: Certifico que el análisis funcional es suficientemente completo."

  → Si operador firma → veredicto = pass:
       - Actualizar iteration-tracker.md con status: closed + nombre/rol/fecha
       - Actualizar operator/dashboard.html:
           workflowStatus: "CLOSED"
           gates.closure: "PASS"
           timeline: añadir "WF1 Cerrado — firmado por {nombre} ({rol})"
           nota: "WF1 cerrado. Firmado por {nombre} — {rol} — {fecha}."
       - Mostrar:
         "🎉 WF1 CERRADO. El paquete funcional está disponible en output/

          Para iniciar WF2:
          /ta-run-workflow output/ {APP_ID} {CLIENT_ID} full"

  → Si operador rechaza la firma → veredicto = fail:
       - Status: CLOSURE_FAIL (la iteración cierra sin firma)
       - Nota explicativa en dashboard
       - Para reintentar: re-lanzar continue-iteration cuando esté listo
```

---

## Gestión de Gaps e Iteraciones

### Cuando el workflow se detiene por gaps

Mostrar siempre el resumen de situación:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WF1-FA ITER-{NNN} — {APP_ID}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 Estado actual:
   Cobertura: {N}%
   FA-REQ confirmados: {N}
   Pantallas inventariadas: {N}

❌ Gaps BLOQUEANTES ({N}):
   [lista con FA-GAP-ID, tipo, pantalla/req, acción requerida]

⚠️ Gaps RECOMENDADOS ({N}):
   [lista con FA-GAP-ID, tipo, descripción breve]

📋 Próximos pasos:
   1. Abre el dashboard (enlace abajo) y navega a la sección Gaps
   2. Obtén aclaraciones del cliente/PO para los gaps BLOQUEANTES
   3. Actualiza o añade ficheros en:
      input/docs/    → documentos BRD, actas, especificaciones
      input/screens/ → capturas de pantalla, wireframes, exports Figma
      input/specs/   → contratos API, Gherkin, schemas
   4. Cuando estés listo:
      /fa-run-workflow {$0} {$1} continue-iteration
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Fingerprint y detección de cambios

```
En modo continue-iteration o update-sources:
  Antes de ejecutar FASE 1, calcular fingerprint de input/ (según fa-iteration-manager)
  Comparar con resources/source-fingerprint.md

  Si NO hay cambios Y modo = continue-iteration:
    → ADVERTIR: "No se detectaron cambios en las fuentes desde la última iteración.
                  ¿Estás seguro de continuar? (s/n)"
  
  Si hay cambios → proceder normalmente
  → Actualizar resources/source-fingerprint.md al final de FASE 1
```

---

## Mensajes de Estado

Durante la ejecución, mantener al operador informado con mensajes claros:

```
✅ [OK] PRE-CONDICIÓN completada: {APP_SIZE} complejidad, {N} fuentes habilitadas
🔄 [RUNNING] FASE 1: Lanzando fa-docs-analyzer, fa-ui-analyzer, fa-requirements-analyzer...
✅ [OK] FASE 1 completada: {N} pantallas detectadas, {N} FA-REQ candidatos
🔄 [RUNNING] Gate CV: Validando coherencia entre fuentes...
✅ [OK] Gate CV: PASS — sin discrepancias bloqueantes
🔄 [RUNNING] Gate Coverage: Calculando cobertura funcional...
✅ [OK] Gate Coverage: PASS — {N}% cobertura
🔄 [RUNNING] FASE 2: Sintetizando y consolidando...
✅ [OK] FASE 2 completada: {N} FA-REQ confirmados, {N} gaps detectados
🔄 [RUNNING] FASE 3: Generando artefactos...
✅ [OK] FASE 3 completada: output/ y operator/ generados
🔄 [RUNNING] Gate Cierre: Verificando criterios...
```

---

## Verificación de Prerrequisitos de Herramientas

Al inicio, verificar que las herramientas necesarias están disponibles:
- `Read` — para leer ficheros
- `Write` — para generar artefactos
- `Glob` — para inventariar ficheros
- `Agent` — para lanzar subagentes

Si alguna herramienta no está disponible → ERROR con instrucciones.

---

## Enlace al Dashboard — Mostrar SIEMPRE al final de cada ejecución

Al finalizar cualquier ejecución (pass, fail, checkpoint, error o cierre), mostrar
como ÚLTIMO mensaje antes de detener:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Dashboard del operador:
   {DASHBOARD_LINK}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Donde {DASHBOARD_LINK} se construye así:
  1. Obtener la ruta absoluta del workspace (directorio raíz de WF1)
  2. Combinar con la ruta relativa del dashboard:
       {workspace_root}/workflows-data/workflow-fa/operator/dashboard.html
  3. Convertir a URL file://:
       - Windows: reemplazar \ por / y prefijo file:///
         ej: file:///C:/WF1/workflows-data/workflow-fa/operator/dashboard.html
       - Linux/Mac: prefijo file://
         ej: file:///home/user/WF1/workflows-data/workflow-fa/operator/dashboard.html

El enlace debe ser clickeable en la terminal — formatear como markdown si el entorno
lo soporta: [📊 Abrir Dashboard](file:///...) — o como texto plano si no.
