---
name: fa-source-scanner
description: >
  Inventaría las fuentes locales disponibles y valida los canales de acceso a
  fuentes remotas (MCP nativo y/o ficheros input/remote/*.yml). Detecta gaps
  REMOTE-CHANNEL-MISSING. Autogenera stubs .yml cuando solo existe canal MCP.
---

# fa-source-scanner — Validación de Fuentes y Canales

> **Scope:** Validación de fuentes y canales de acceso en PRE-CONDICIÓN WF1-FA
> **Cubre:** validacion-canales, matriz-resolucion-mcp-yml, stubs, seguridad-credenciales, dialogo-interactivo
> **No cubre:** extracción del contenido de las fuentes — eso es fa-*-extractor

## Matriz de Resolución de Canales

Para cada fuente con `enabled: true` en `fa-config.yml`, se evalúan dos canales:
- **Canal MCP nativo:** `mcp-server` registrado en la plataforma (acceso en tiempo real)
- **Canal fichero:** `input/remote/{tool}.yml` con export descargado o declaración

| Caso | MCP Nativo | `input/remote/*.yml` | Comportamiento en runtime                                      |
|------|-----------|----------------------|----------------------------------------------------------------|
| **1** | ✅ Existe | ✅ Existe           | MCP gana en runtime · `.yml` es documentación auditable y fallback offline |
| **2** | ✅ Existe | ❌ No existe        | MCP único · autogenerar stub `.yml` con `# autogenerado`       |
| **3** | ❌ No existe | ✅ Existe         | Solo `.yml` · usar export estático (modo offline)              |
| **4** | ❌ No existe | ❌ No existe       | **Diálogo interactivo** · solicitar al operador URL + nombre de variable de entorno para credencial (ver "Diálogo Interactivo de Configuración Remota"). Si el operador cancela → emitir FA-GAP `REMOTE-CHANNEL-MISSING` → abortar |

## Procedimiento de Validación

```
Para cada sources.{tool} con enabled: true en fa-config.yml:
  1. ¿Existe mcp-server en configuración de plataforma? → canal_mcp = true/false
  2. ¿Existe input/remote/{tool}.yml?                   → canal_yml = true/false
  3. Aplicar matriz → determinar caso (1/2/3/4)
  4. Caso 4 → ACTIVAR DIÁLOGO INTERACTIVO (ver sección dedicada):
              - Si el operador completa el diálogo → generar input/remote/{tool}.yml
                con los datos proporcionados y reevaluar (pasa a Caso 1 o 3)
              - Si el operador cancela → registrar FA-GAP REMOTE-CHANNEL-MISSING
                y abortar workflow
  5. Caso 2 → autogenerar stub input/remote/{tool}.yml
  6. Caso 1 → registrar precedencia: MCP gana en runtime
  7. Documentar resultado en log de pre-condición
```

## Diálogo Interactivo de Configuración Remota

Activado en **Caso 4** (ni MCP nativo ni `.yml` declarado) para evitar abortar el
workflow cuando el operador puede aportar los datos en ese momento. También se
invoca desde `fa-run-workflow` paso 0b al definir nuevas fuentes remotas (ver
ese skill para el flujo proactivo).

### Reglas básicas

- **Una herramienta por vez** — secuencial, no batch. El operador ve un diálogo por cada `{tool}` sin canal.
- **NUNCA solicitar el valor de la credencial.** Solo se pregunta el **nombre** de la variable de entorno que la contendrá (ej: `JIRA_TOKEN`). El valor real lo configura el operador fuera del workflow (perfil de shell, gestor de secretos, etc.).
- **Validación de la variable de entorno** — tras recibir el nombre, comprobar si está definida en el entorno actual. Si no lo está, emitir advertencia pero NO bloquear (el operador puede configurarla antes de la siguiente fase).
- **Cancelación segura** — si el operador cancela el diálogo, no escribir nada y devolver control al procedimiento (que registrará el FA-GAP).

### Especificación del diálogo (por herramienta)

Usar el mecanismo nativo de preguntas interactivas del agente (en Claude Code:
herramienta `AskUserQuestion` o equivalente). El diálogo presenta los siguientes
campos en orden, agrupados en una única ventana cuando el mecanismo lo permita:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Configurar canal para fuente remota: {tool}  ({type})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Por seguridad, NO se solicita el valor del token.
Solo el NOMBRE de la variable de entorno donde lo tienes guardado.

Campo 1 — URL del sistema:
  Ejemplo: https://empresa.atlassian.net  (Jira)
           https://www.figma.com         (Figma)
           https://empresa.atlassian.net/wiki  (Confluence)
  Valor: _

Campo 2 — Identificador del proyecto/espacio:
  Para Jira/ADO  → código del proyecto (ej: MYAPP)
  Para Figma     → file-key del proyecto (ej: AbCdEf123456)
  Para Confluence→ space-key (ej: PROJSPACE)
  Valor: _

Campo 3 — ¿Existe MCP nativo configurado para esta herramienta? (s/n):
  Si responde "s" →
    Campo 3a — Nombre del MCP server (ej: jira-mcp):
      Valor: _
  Si responde "n" → omitir 3a

Campo 4 — Nombre de la variable de entorno con la credencial:
  Convención sugerida: {TOOL}_TOKEN o {TOOL}_API_KEY (en mayúsculas)
  Ejemplos: JIRA_TOKEN, FIGMA_PAT, CONFLUENCE_API_KEY
  ⚠️ NO escribir aquí el valor del token — solo el NOMBRE de la variable.
  Valor: _

Campo 5 — Descripción breve del propósito (opcional):
  Ejemplo: "Backlog e HU del proyecto MYAPP"
  Valor: _ (puede dejarse vacío)

[Aceptar] [Cancelar]
```

### Validaciones aplicadas tras el diálogo

```
1. URL — debe empezar por https:// (rechazar http:// con aviso de seguridad)
2. Variable de entorno — verificar que el nombre cumple regex ^[A-Z][A-Z0-9_]*$
   (mayúsculas, dígitos y guiones bajos; empieza por letra).
   Si NO cumple → reabrir el diálogo solo con ese campo y mensaje correctivo.
3. Detección de secretos accidentales — si en cualquier campo se detecta una
   cadena que parece un token (longitud > 20 y mezcla de letras/dígitos/símbolos
   sin estructura de URL), REHUSAR el valor con mensaje:
   "Detectado posible token en el campo {N}. Por seguridad solo se admite el
    NOMBRE de la variable de entorno, no su valor. Configura la variable en tu
    shell (ej: $env:{VAR_NAME} = '...') y reintroduce solo el nombre."
4. Verificación de existencia de la variable en el entorno actual:
   - En Windows: comprobar $env:{VAR_NAME}
   - En Linux/Mac: comprobar $VAR_NAME
   - Si NO existe → advertencia (no bloquea):
     "⚠️  La variable {VAR_NAME} no está definida en el entorno actual.
      Configúrala antes de que el workflow intente consumir esta fuente:
        Windows (PowerShell): $env:{VAR_NAME} = '<valor>'
        Linux/Mac (bash):     export {VAR_NAME}='<valor>'"
```

### Escritura del `.yml` tras diálogo exitoso

Generar `input/remote/{tool}.yml` con frontmatter `# generado por diálogo interactivo`:

```yaml
# input/remote/{tool}.yml
# Generado por diálogo interactivo de fa-source-scanner — {YYYY-MM-DD}
# Editable: puedes modificar URL, proyecto o nombre de variable de entorno.
# NUNCA escribas el valor del token aquí — solo la referencia ${VAR_NAME}.
type: {jira|figma|confluence|ado|notion|sharepoint}
url: {URL del campo 1}
project: {identificador del campo 2}
enabled: true

# Canales de acceso:
{si campo 3 = s:}
mcp-server: {nombre del campo 3a}
{fin si}
# export-path: input/remote/exports/{tool}-export.json  # descomenta si dispones de export

# Credencial — referencia a variable de entorno (NUNCA el valor literal):
api-token: ${{NOMBRE del campo 4}}

description: "{campo 5 o cadena por defecto si vacío}"
```

Tras escribir el fichero, **reevaluar la matriz** para esa `{tool}`:
- Si el operador declaró MCP → ahora es Caso 1
- Si no → ahora es Caso 3

Continuar el procedimiento normal.

## Reglas de Seguridad — Credenciales

**NUNCA incluir tokens o credenciales en ficheros del repositorio.**

Las credenciales siempre van en variables de entorno:
```yaml
# Correcto — referencia a variable de entorno:
api-token: ${JIRA_TOKEN}
api-token: ${FIGMA_PAT}
api-token: ${CONFLUENCE_API_KEY}

# INCORRECTO — nunca así:
api-token: "eyJhbGciOiJIUzI1NiJ9..."
password: "mi-contraseña-secreta"
```

El operador define las variables en el entorno del sistema o en el gestor de secretos de la plataforma.

Si se detecta un valor que parece un token real (cadena larga aleatoria) en un fichero `.yml`:
→ Emitir advertencia al operador antes de continuar
→ No registrar el valor en ningún artefacto generado

El **diálogo interactivo** (ver sección dedicada más abajo) refuerza esta regla:
nunca solicita el valor del token, solo el nombre de la variable de entorno. Si el
operador pega por error un valor que parece un secreto, el diálogo lo rechaza y
pide reintroducir solo el nombre.

## Formato del Stub Autogenerado (Caso 2)

```yaml
# input/remote/{tool}.yml
# autogenerado por fa-source-scanner — editable
# Generado porque se detectó mcp-server pero no existía fichero de declaración
type: {jira|figma|confluence|ado|notion|sharepoint}
url: {url-extraída-de-configuración-MCP-si-disponible}
enabled: true
mcp-server: {nombre-del-mcp-registrado}
# api-token: ${JIRA_TOKEN}  # descomenta y configura si necesario
description: "Stub autogenerado — completar con URL y descripción del proyecto"
```

## Schema Completo de `input/remote/{tool}.yml`

```yaml
type: jira                          # jira | figma | confluence | ado | notion | sharepoint
url: https://empresa.atlassian.net
project: MYAPP                      # código de proyecto (Jira/ADO) o espacio (Confluence)
enabled: true

# Canales de acceso — al menos uno debe existir:
mcp-server: jira-mcp                # nombre del MCP nativo en la plataforma
export-path: input/remote/exports/jira-export.json  # export descargado (fallback)

# Credenciales — SIEMPRE vía variables de entorno:
# api-token: ${JIRA_TOKEN}

description: "Backlog e HU del proyecto MYAPP"
```

## Inventario de Fuentes Locales

Además de validar canales remotos, `fa-source-scanner` inventaría las fuentes locales:

```
Directorios a inventariar:
  input/docs/    → documentos de texto (PDF, DOCX, TXT, MD)
  input/screens/ → imágenes (PNG, JPG, GIF, SVG, PDF de diseño)
  input/specs/   → specs técnicas (YAML, JSON, RAML, SQL, .feature, .drawio)
```

**Inferencia de tipo por extensión:**

| Extensión             | Tipo inferido       | Agente que la procesa      |
|-----------------------|---------------------|----------------------------|
| .pdf, .docx, .txt, .md | Documentación      | fa-docs-analyzer           |
| .png, .jpg, .gif, .svg | Captura/Wireframe  | fa-ui-analyzer             |
| .pdf (en screens/)    | Exportación Figma   | fa-ui-analyzer             |
| .yaml, .json (OpenAPI)| Contrato API        | fa-requirements-analyzer   |
| .raml                 | Contrato API RAML   | fa-requirements-analyzer   |
| .sql                  | Schema BD           | fa-requirements-analyzer   |
| .feature              | Gherkin             | fa-requirements-analyzer   |
| .drawio, .xml (draw)  | Diagrama navegación | fa-ui-analyzer             |

## Salida: Log de Pre-condición

El fa-source-scanner produce un resumen en el log del orquestador con:
- Lista de todas las fuentes habilitadas y su canal resuelto
- Stubs generados (si aplica)
- Gaps REMOTE-CHANNEL-MISSING emitidos (si aplica)
- Inventario de ficheros locales por directorio
