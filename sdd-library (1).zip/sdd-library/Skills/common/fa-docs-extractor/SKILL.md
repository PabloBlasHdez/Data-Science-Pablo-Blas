---
name: fa-docs-extractor
description: >
  Patrones y reglas para extraer información funcional de documentación escrita:
  BRD, historias de usuario, emails, actas de reunión, manuales de usuario y
  especificaciones de texto. Define cómo clasificar lo encontrado en FA-REQ-NNN.
---

# fa-docs-extractor — Extracción de Documentación Escrita

> **Scope:** Extracción funcional de documentos de texto en WF1-FA
> **Cubre:** patrones-extraccion, clasificacion-tipos-req, confianza, formatos-doc
> **No cubre:** imágenes y wireframes — ver fa-ui-extractor; código fuente — ver fa-code-extractor

## Tipos de Documentos y Estrategia

| Tipo de documento          | Extensiones típicas      | Tipo FA-REQ producido | Prioridad |
|----------------------------|--------------------------|-----------------------|-----------|
| BRD (Business Requirements)| .pdf, .docx              | DIRECTO               | ALTA      |
| Historias de usuario       | .docx, .xlsx, .txt, .md  | DIRECTO               | ALTA      |
| Especificaciones funcionales | .pdf, .docx            | DIRECTO               | ALTA      |
| Manuales de usuario        | .pdf, .docx              | INFERIDO              | MEDIA     |
| Actas de reunión           | .docx, .txt, .md         | ASUMIDO               | MEDIA     |
| Emails y comunicaciones    | .txt, .eml, .md          | ASUMIDO               | MEDIA-BAJA|
| Entrevistas / notas        | .txt, .md                | ASUMIDO               | MEDIA-BAJA|

## Tipos de FA-REQ según Origen

| Tipo     | Criterio                                                               | Nivel de confianza |
|----------|------------------------------------------------------------------------|--------------------|
| DIRECTO  | El documento declara explícitamente un requisito o HU                  | CONFIRMED          |
| INFERIDO | El documento describe un flujo o pantalla sin declarar el req. explícitamente | INFERRED  |
| ASUMIDO  | La información se deduce de contexto (emails, notas) sin fuente formal | ASSUMED            |

## Patrones de Extracción de Pantallas

Buscar sustantivos compuestos que indiquen una vista o formulario. Indicadores:

```
Patrones textuales que señalan una pantalla:
- "pantalla de X", "formulario de X", "vista de X", "página de X"
- "en la pantalla", "al abrir", "al entrar en"
- "el usuario ve", "se muestra", "se visualiza"
- Nombres propios con mayúscula que se repiten + contexto de interfaz

Campos a extraer por pantalla mencionada:
- Nombre funcional (normalizar: "Pantalla de Búsqueda de Contratos" → "Búsqueda de Contratos")
- Fuente exacta (nombre fichero + sección/página si aplica)
- FA-REQ-NNN que origina esta pantalla
- Roles mencionados con acceso
- Acciones disponibles mencionadas
```

## Patrones de Extracción de Reglas de Negocio

```
Indicadores lingüísticos de reglas:
- "si ... entonces", "cuando ... debe", "en caso de que"
- "obligatorio", "requerido", "no puede", "solo puede", "debe ser"
- "mínimo X", "máximo X", "entre X e Y", "mayor que", "menor que"
- "validar que", "verificar que", "comprobar que"
- "el sistema debe", "la aplicación debe"
- Tablas con condiciones/acciones (tablas de decisión)

Por cada regla encontrada:
- Descripción precisa (copiar o parafrasear fielmente — no interpretar)
- Pantalla donde aplica (si se menciona)
- FA-REQ vinculado
- Fuente exacta con cita textual si hay riesgo de ambigüedad
- ¿Contradicción con otra fuente conocida? → FA-GAP RULE-AMBIGUOUS
```

## Patrones de Extracción de Entidades

```
Indicadores de entidades funcionales:
- Sustantivos que se repiten en el documento con atributos asociados
- Tablas con campos y tipos
- Listas de "información de X": nombre, fecha, estado...
- "El/La {X} tiene: ..."
- Referencias a base de datos: "tabla de X", "registro de X"

Por cada entidad encontrada:
- Nombre normalizado (singular)
- Campos mencionados con tipo funcional si se especifica
- Validaciones por campo mencionadas
- FA-REQ vinculados donde se usa esta entidad
```

## Patrones de Extracción de Roles

```
Indicadores de roles y permisos:
- "el {rol} puede", "solo {rol}", "el {rol} no puede"
- "perfil de X", "usuario tipo X", "acceso de X"
- Tablas de perfiles o permisos
- Secciones tituladas "roles", "permisos", "accesos", "usuarios del sistema"

Por cada rol encontrado:
- Nombre del rol: usar el término EXACTO del documento, sin traducir ni mapear
  a nombres estándar (ADMIN, GESTOR, SUPERVISOR...). Si el documento dice
  "Usuario con permiso MODIFICA_PGC", registrar eso literalmente.
  NUNCA inferir un nombre de rol que no aparezca en las fuentes analizadas.
  Los alias del client-rules solo se aplican si el documento usa el término
  del cliente Y el client-rules tiene una entrada explícita para ese término.
- Acciones o pantallas mencionadas
- Restricciones mencionadas
- Si el acceso se define por permiso (no por nombre de rol), registrar el
  permiso como identificador: ej. ROL = "con permiso MODIFICA_PGC"
```

## Patrones de Extracción de Flujos de Navegación

```
Indicadores de flujo entre pantallas:
- "desde X ir a Y", "al hacer clic en X se navega a"
- "el flujo empieza en X", "el proceso finaliza en Y"
- Diagramas de flujo describir en texto
- Secciones "flujo del proceso", "paso a paso", "workflow"
- Secuencias numeradas (1. Abrir pantalla X → 2. Rellenar → 3. Guardar → ...)

Por cada transición:
- Pantalla origen
- Pantalla destino
- Condición o acción desencadenante
- Roles que pueden hacer esa transición
```

## Confianza Scoring

```
CONFIRMED → el documento proviene de una fuente primaria formal (BRD firmado, HU aprobada)
            Y coincide con al menos otra fuente
INFERRED  → el documento es formal pero no declara explícitamente el requisito,
            o es la única fuente para este dato
ASSUMED   → el documento es informal (email, nota, acta) y no tiene confirmación
            de una fuente formal
```

**Regla de privacidad:** Al transcribir ejemplos o valores del cliente:
- NIF/CIF → reemplazar por "XXXXXXXXX"
- Números de cuenta → reemplazar por "XXXX XXXX XXXX XXXX"
- Otros datos personales identificables → reemplazar por "[dato enmascarado]"
(Las reglas específicas de privacidad del cliente van en `{client}-fa-rules`)

## Manejo de Documentos Multi-idioma

Si el documento está en otro idioma (inglés, portugués, etc.):
- Extraer los datos en el idioma original
- Añadir traducción en el campo descripción: "Customer Search (traducido de inglés — fuente: HU-023)"
- Los IDs siempre en inglés (FA-REQ, SCR, BRN, ENT...)
- El idioma de los artefactos generados es el especificado en `fa-config.yml → primary-language`
