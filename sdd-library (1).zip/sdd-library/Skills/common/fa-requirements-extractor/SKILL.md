---
name: fa-requirements-extractor
description: >
  Patrones y reglas para extraer historias de usuario estructuradas, criterios
  de aceptación y escenarios de test de fuentes estructuradas: Jira exports,
  Azure DevOps exports, ficheros Gherkin y contratos OpenAPI/RAML.
---

# fa-requirements-extractor — Extracción de Requisitos Estructurados

> **Scope:** Extracción de requisitos estructurados en WF1-FA
> **Cubre:** formato-fa-req, mapeo-jira-hU, gherkin-a-criterios, mapeo-tipos-ticket
> **No cubre:** documentos de texto no estructurados — ver fa-docs-extractor

## Formato Canónico FA-REQ-NNN

Todo requisito funcional detectado se convierte a este formato:

```markdown
## FA-REQ-{NNN}
- **descripcion:** Descripción concisa del requisito funcional
- **origen:** {ID-origen} ({fuente}: {URL o referencia})
- **tipo:** funcional | no-funcional | incidencia
- **tipo-req:** DIRECTO | INFERIDO | ASUMIDO
- **confianza:** CONFIRMED | INFERRED | ASSUMED
- **criterios-aceptacion:**
  - Criterio 1 (expresado en lenguaje de negocio, no técnico)
  - Criterio 2
  - ...
- **pantallas-mencionadas:** [SCR candidatas deducidas de los criterios]
- **reglas-mencionadas:** [BRN candidatas deducidas de los criterios]
- **roles:** [roles que aparecen en los criterios]
- **prioridad-origen:** Alta | Media | Baja (del sistema de origen si disponible)
- **estado-origen:** To Do | In Progress | Done | Closed (del sistema de origen)
```

## Tipos de FA-REQ

| tipo         | Cuándo usar                                                           |
|--------------|-----------------------------------------------------------------------|
| `funcional`  | Requisito de comportamiento de la aplicación (qué hace)              |
| `no-funcional` | Rendimiento, seguridad, accesibilidad, i18n, disponibilidad         |
| `incidencia` | Bug o error a corregir (solo para `project.type = incident`)         |

## Mapeo Jira → FA-REQ

| Campo Jira         | Campo FA-REQ                 | Notas                                      |
|--------------------|------------------------------|--------------------------------------------|
| summary            | descripcion                  | Normalizar a español si primary-language=es|
| issuetype.name     | tipo-req / tipo              | Story→DIRECTO/funcional; Bug→DIRECTO/incidencia; Epic→agrupar sus Stories |
| description (As a… I want… So that…) | criterios-aceptacion | Extraer los 3 campos del formato HU |
| acceptanceCriteria | criterios-aceptacion         | Añadir a los anteriores                    |
| labels             | notas de alcance             | "fase-2" → excluir; "deprecated" → revisar |
| priority.name      | prioridad-origen             | Blocker/Critical/Major/Minor/Trivial       |
| status.name        | estado-origen                | To Do/In Progress/Done/Closed/Won't Fix    |
| components         | área funcional               | Puede ayudar a agrupar FA-REQ por módulo   |

**Reglas de filtrado de tickets Jira:**
- `status = "Won't Fix"` → excluir con justificación registrada
- `status = "Closed"` → incluir si `resolution = "Done"`, excluir si `resolution = "Won't Fix"`
- `labels includes "fase-2"` → registrar exclusión (según reglas del `{client}-fa-rules`)
- `issuetype = "Epic"` → NO crear FA-REQ, usar para agrupar Stories bajo él

## Mapeo Azure DevOps → FA-REQ

| Campo ADO              | Campo FA-REQ          | Notas                                  |
|------------------------|-----------------------|----------------------------------------|
| Title                  | descripcion           |                                        |
| Work Item Type         | tipo-req              | User Story → funcional; Bug → incidencia |
| Description            | criterios-aceptacion  |                                        |
| Acceptance Criteria    | criterios-aceptacion  | Añadir a los anteriores                |
| Priority               | prioridad-origen      | 1=Crítica, 2=Alta, 3=Media, 4=Baja    |
| State                  | estado-origen         | New/Active/Resolved/Closed             |
| Tags                   | notas de alcance      | Aplicar reglas del {client}-fa-rules   |

## Mapeo Gherkin → FA-REQ con Criterios

Cada `Feature` en un `.feature` puede corresponder a uno o más FA-REQ.
Cada `Scenario` es un criterio de aceptación.

```gherkin
Feature: Búsqueda de contratos            ← FA-REQ-001 (o más si hay múltiples scenarios de tipos distintos)
  Background:
    Given el usuario está autenticado como GESTOR

  Scenario: Buscar con cliente seleccionado   ← Criterio de aceptación 1
    Given el usuario abre la pantalla de búsqueda
    When selecciona el cliente "ACME Corp"
    And pulsa "Buscar"
    Then ve los contratos de "ACME Corp"
    And los resultados muestran id, fecha, estado, tipo

  Scenario: Buscar sin ningún filtro          ← Criterio de aceptación 2
    Given el usuario abre la pantalla de búsqueda
    When pulsa "Buscar" sin seleccionar ningún filtro
    Then ve el mensaje "Debe indicar al menos un criterio de búsqueda"
```

**Extracción:**
- `Feature` → nombre del FA-REQ (o agrupación)
- `Scenario` / `Scenario Outline` → criterio de aceptación individual
- `Given` → precondición del criterio
- `When` → acción del usuario
- `Then` → resultado esperado (verificable)
- `Background` → precondición común a todos los criterios de la feature

## Requisitos Especiales: `project.type = incident`

Para proyectos de tipo incidencia:
- El FA-REQ tiene `tipo: incidencia`
- Los criterios de aceptación describen cómo reproducir el bug y cuál es el comportamiento correcto
- El `origen` incluye el ID del ticket de incidencia
- `coverage-threshold` se reduce automáticamente a 0.50

**Formato especial para incidencias:**
```markdown
## FA-REQ-{NNN}
- tipo: incidencia
- descripcion: Bug: {descripción del problema}
- origen: INC-{NNN} ({sistema de tracking})
- tipo-req: DIRECTO
- criterios-aceptacion:
  - Reproducción: {pasos para reproducir}
  - Comportamiento actual (incorrecto): {qué hace ahora}
  - Comportamiento esperado (correcto): {qué debería hacer}
- area-afectada: {pantalla/módulo afectado}
- severidad-origen: {Critical/High/Medium/Low}
```

## Asignación Automática de SCR Candidatas

Al extraer criterios de aceptación, buscar referencias implícitas a pantallas:
- "abre la pantalla de X" → SCR candidata "X"
- "ve los resultados" → la pantalla donde se muestran (deducir de contexto)
- "en el formulario de X" → SCR candidata "Formulario de X"

Si no se puede deducir la pantalla → `FA-GAP REQ-WITHOUT-SCREEN`
