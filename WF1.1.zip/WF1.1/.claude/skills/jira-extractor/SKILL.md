---
name: jira-extractor
description: >
  Mapeo detallado de campos Jira a FA-REQ-NNN. Cubre exports JSON de Jira Cloud
  y Jira Server. Activo cuando input/remote/jira.yml tiene enabled: true.
---

# jira-extractor — Extracción de Tickets Jira

> **Scope:** Extracción de tickets Jira a requisitos funcionales FA-REQ
> **Cubre:** mapeo-campos-jira, filtrado-tickets, epics-stories-bugs, criterios-aceptacion
> **No cubre:** Jira Automation, Jira Workflows — solo extracción de contenido de tickets

## Activación

Se activa cuando `sources.remote.enabled = true` y existe `input/remote/jira.yml`.
Usa MCP nativo (`mcp-server: jira-mcp`) si disponible, o procesa el export JSON local.

## Estructura del Export Jira (JSON)

```json
{
  "issues": [
    {
      "key": "MYAPP-001",
      "fields": {
        "summary": "Búsqueda de contratos por cliente",
        "issuetype": { "name": "Story" },
        "status": { "name": "Done" },
        "priority": { "name": "High" },
        "description": "Como gestor quiero buscar contratos...",
        "customfield_10016": "5",
        "customfield_10014": "Como gestor...\n*Criterios de aceptación:*\n...",
        "labels": ["v1", "modulo-contratos"],
        "components": [{ "name": "Búsqueda" }],
        "parent": { "key": "MYAPP-EP-001", "fields": { "summary": "Módulo Contratos" } }
      }
    }
  ]
}
```

## Mapeo de Campos

| Campo Jira (JSON path)          | Campo FA-REQ              | Transformación                               |
|---------------------------------|---------------------------|----------------------------------------------|
| `fields.summary`                | descripcion               | Normalizar idioma si primary-language ≠ idioma del campo |
| `fields.issuetype.name`         | tipo / tipo-req           | Ver tabla de tipos abajo                     |
| `fields.description`            | criterios-aceptacion      | Parsear formato "Como X quiero Y para Z"     |
| `fields.customfield_* (acceptance criteria)` | criterios-aceptacion | Añadir a los anteriores        |
| `fields.priority.name`          | prioridad-origen          | Blocker→Crítica, Critical→Alta, Major→Media  |
| `fields.status.name`            | estado-origen             | Mapeo directo                                |
| `fields.labels`                 | notas de alcance          | Aplicar reglas de {client}-fa-rules          |
| `fields.components[].name`      | area-funcional            | Contexto para agrupar FA-REQ por módulo      |
| `key`                           | origen                    | "HU-NNN (Jira MYAPP-NNN)"                   |

## Mapeo de Tipos de Issue

| issuetype.name    | tipo FA-REQ    | tipo-req  | Tratamiento especial                     |
|-------------------|----------------|-----------|------------------------------------------|
| `Story`           | funcional      | DIRECTO   | Crear FA-REQ con criterios de aceptación |
| `Bug`             | incidencia     | DIRECTO   | Solo si project.type = incident          |
| `Epic`            | —              | —         | NO crear FA-REQ — agrupar sus Stories    |
| `Task`            | funcional      | DIRECTO   | Si tiene criterios de aceptación         |
| `Sub-task`        | —              | —         | Vincular al FA-REQ de la Story padre     |
| `Improvement`     | funcional      | DIRECTO   | Tratar como Story                        |

## Filtrado de Tickets

**Incluir:**
- `status.name ∈ {To Do, In Progress, Done}` Y `resolution ∈ {null, Done, Fixed}`

**Excluir con justificación registrada:**
- `status.name = "Won't Fix"` → anotar exclusión en requirements-registry
- `resolution = "Won't Fix"` → ídem
- Labels que el {client}-fa-rules marque como "excluir" (ej: "fase-2", "parked")
- Epics → no crear FA-REQ (solo usar para agrupar)

## Extracción de Criterios de Aceptación

### Formato 1 — Historia de Usuario Clásica
```
Como {rol} quiero {acción} para {objetivo}.

Criterios de aceptación:
- Dado {precondición}, cuando {acción}, entonces {resultado}
- ...
```
→ Extraer los "Dado/Cuando/Entonces" como criterios individuales.

### Formato 2 — Lista en el campo Description
```
**Acceptance Criteria:**
1. El usuario puede filtrar por cliente
2. Si no hay resultados, se muestra mensaje
```
→ Extraer cada ítem como criterio individual.

### Formato 3 — Campo customfield separado
Algunos Jira usan `customfield_10016` u otros para acceptance criteria.
→ Intentar los campos custom más comunes; si no se encuentra, usar `description`.

## Uso con MCP Nativo (Jira MCP)

Si `mcp-server: jira-mcp` está disponible:
```
Consultas típicas con MCP Jira:
- Listar todos los issues del proyecto: project = {project-key} ORDER BY created ASC
- Filtrar por tipo: issuetype = Story AND status != "Won't Fix"
- Obtener epic links: "Epic Link" = {epic-key}
- Buscar por sprint: sprint in openSprints() AND project = {project-key}
```

El MCP permite consultas en tiempo real sin necesidad de export descargado.
